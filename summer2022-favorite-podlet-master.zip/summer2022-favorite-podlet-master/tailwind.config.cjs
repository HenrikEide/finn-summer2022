const preset = require('@fabric-ds/tailwind-config');

module.exports = {
    presets: [preset],
};
