import prometheus from "prom-client";
import Podlet from "@podium/podlet";
import ExpressPodlet from "@finn-no/express-podlet";
import fiaasLogger from "@finn-no/fiaas-logger";
import express from "express";
import Eik from "@eik/node-client";
import cors from "cors";
import { encode } from "@finn-no/safe-props";
import bodyParser from "body-parser";
import config from "./config/index.js";
import favoriteClient from "./client/favoriteClient.js";

fiaasLogger.setLogLevel(config.get("logLevel"));

async function createServer({
  name = config.get("name"),
  version = config.get("version"),
  port = config.get("port"),
  development = config.get("development"),
  logger = fiaasLogger,
  metrics = config.get("metrics"),
  grace = config.get("shutdownGracePeriod"),
  useEik = config.get("useEik"),
  devToolPort,
} = {}) {
  const podlet = new Podlet({
    name,
    version,
    pathname: "/",
    development,
    logger,
  });

  const server = new ExpressPodlet(podlet, {
    port,
    metrics,
    prometheus,
    devToolPort,
    grace,
    assets: false,
    eik: true,
  });

  const { app } = server;

  app.use(bodyParser.json());

  podlet.proxy({ target: "/api", name: "api" });

  const eik = new Eik({ development: !useEik, base: "/static" });
  await eik.load();

  const favoriteApis = favoriteClient(logger);

  if (!useEik) {
    app.use(cors({ origin: "http://local.finn.no:3030", credentials: true }));
    app.use("/static", express.static("./dist/"));
  }

  podlet.js({ ...eik.file("/index.js"), type: "module" });

  // Creating a style link to use isolated inside the web component
  const url = new URL(
    eik.file("/styles.css").value,
    development ? `http://local.finn.no:${port}` : undefined
  );

  app.post("/api/createFolder", favoriteApis.newList);

  app.get("/api/fetchFolders", favoriteApis.fetchFolders);
  app.put("/api/addAdToAdList/:adListId/:adId", favoriteApis.addToFolder);
  app.delete(
    "/api/removeAdFromAdList/:adListId/:adId",
    favoriteApis.removeFromFolder
  );

  app.get(podlet.content(), async (req, res) => {
    const { finnToken } = res.locals.podium.context;

    if (!finnToken) {
      res.podiumSend("");
      return;
    }

    const { publicPathname } = res.locals.podium.context;

    const props = {
      adId: Number(req.query.adId),
      isMobile: Boolean(req.query.isMobile === "true"),
      endpoint: publicPathname,
      stylelink: url.href,
      finnToken,
    };

    res.podiumSend(
      `<div id="summer2022-favorite-podlet-root" 
                data-props="${encode(props)}">
            </div>
            `
    );
  });

  return server;
}

export default createServer;
