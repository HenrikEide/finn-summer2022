import { join } from "path";
import { readFileSync } from "fs";
import convict from "convict";
import convictFormatWithValidator from "convict-format-with-validator";
import dirname from "./dirname.cjs";

const pack = JSON.parse(readFileSync(join(dirname, "../../../package.json")));

convict.addFormats(convictFormatWithValidator);

const conf = convict({
  name: {
    doc: "Name of the application",
    default: pack.name,
    format: String,
  },
  version: {
    doc: "Version number",
    format: String,
    default: `${Date.now()}`,
    env: "VERSION",
  },
  env: {
    doc: "Applicaton environments",
    format: ["local", "dev", "prod"],
    default: "local",
    env: "FIAAS_ENVIRONMENT",
    arg: "env",
  },
  metrics: {
    default: true,
    format: Boolean,
  },
  shutdownGracePeriod: {
    doc: "Grace period to allow connections to finish before shutdown",
    default: 5000,
    format: "nat",
  },
  port: {
    doc: "The port to expose the application on",
    format: "port",
    default: 8080,
    env: "PORT",
    arg: "port",
  },
  logLevel: {
    format: ["TRACE", "DEBUG", "INFO", "WARN", "ERROR", "FATAL"],
    default: "INFO",
    env: "LOG_LEVEL",
    arg: "log-level",
  },
  useEik: {
    default: true,
    format: Boolean,
  },
  development: {
    default: false,
    format: Boolean,
  },
  summer2022Backend: {
    doc: "Api endpoint for Summer 2022 team",
    format: "url",
    default: "http://summer-fav-backend",
  },
  unleashUrl: {
    format: "url",
    default: "http://unleash/api",
  },
});

const env = conf.get("env");
conf.loadFile(`${dirname}/config.${env}.json`);
conf.validate();

export default conf;
