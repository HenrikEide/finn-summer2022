import axios from "axios";
import conf from "../config/index.js";

const config = conf.getProperties();

const axiosInstance = axios.create({
  baseURL: config.summer2022Backend,
});

const addToFolder = (logger) => (req, res) => {
  const { adListId, adId } = req.params;
  logger.info(`Adding ${adId} to shared list ${adListId}`);
  axiosInstance
    .put(
      `/api/addAdToList/${adListId}/${adId}`,
      {},
      {
        headers: {...req.headers},
      }
    )
    .then((response) => res.send(response.data))
    .catch((error) => {
      logger.warn(error);
      res.status(error.response.status).send({});
    });
};

const removeFromFolder = (logger) => (req, res) => {
  const { adListId, adId } = req.params;
  logger.info(`Removing ${adId} from shared list ${adListId}`);
  axiosInstance
    .delete(`/api/deleteAdFromList/${adListId}/${adId}`, {
      headers: {...req.headers},
    })
    .then((response) => res.send(response.data))
    .catch((error) => {
      logger.warn(error);
      res.status(error.response.status).send({});
    });
};

const fetchFolders = (logger) => (req, res) => {
  logger.info(`Fetching shared list`);
  axiosInstance
    .get("/api/ownWriteAccessLists", {
      headers: {...req.headers},
    })
    .then((response) => {
      res.send(response.data);
    })

    .catch((error) => {
      logger.warn(error);
      res.status(error.response.status).send({});
    });
};

const newList = (logger) => (req, res) => {
  const { listName, adId } = req.body;
  axiosInstance
    .post(
      `/api/addAdToNewList`,
      { listName, adId },
      {
        headers: {...req.headers},
      }
    )
    .then((response) => res.send(response.data))
    .catch((error) => {
      logger.warn(error);
      res.status(error.response.status).send({});
    });
};

const favoriteClient = (logger) => ({
  addToFolder: addToFolder(logger),
  removeFromFolder: removeFromFolder(logger),
  fetchFolders: fetchFolders(logger),
  newList: newList(logger),
});

export default favoriteClient;
