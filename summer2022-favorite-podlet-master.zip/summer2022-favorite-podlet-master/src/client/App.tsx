import { useState } from "react";
import ShareButton from "./components/ShareButton";
import SaveAdModal from "./components/SaveAdModal";
import { Dataset } from "./utils/dataProps";

type Props = {
  adId: Dataset["adId"];
  isMobile: Dataset["isMobile"];
};

const App = (props: Props) => {
  const { adId, isMobile } = props;
  const [toggled, setToggled] = useState(false);

  const handleClick = () => {
    setToggled(!toggled);
  };

  return (
    <>
      <ShareButton isMobile={isMobile} onClick={handleClick} />
      <SaveAdModal
        itemType={""}
        itemId={adId}
        setOpen={handleClick}
        isOpen={toggled}
        restoreFocus={() => {}}
        toggled={toggled}
        userId={2}
      />
    </>
  );
};

export default App;
