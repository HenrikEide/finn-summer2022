import { decode } from "@finn-no/safe-props";

export type Dataset = {
  adId: number;
  isMobile: boolean;
  stylelink: string;
  endpoint: string;
  finnToken: string
};

export const getDataProps = () => {
  const rootElement = document.getElementById(
    "summer2022-favorite-podlet-root"
  );
  const encodedProps = rootElement?.dataset.props;

  if (!encodedProps)
    return { adId: -1, isMobile: false, stylelink: "", endpoint: "", finnToken:"" };

  const props: Dataset = decode(encodedProps);

  return props;
};
