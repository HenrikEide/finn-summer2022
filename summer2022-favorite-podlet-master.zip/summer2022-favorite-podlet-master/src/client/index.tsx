import ReactDOM from "react-dom";
import App from "./App";
import WebComponentPortal from "./WebComponentPortal";
import { getDataProps, Dataset } from "./utils/dataProps";

const root = document.getElementById("summer2022-favorite-podlet-root");

if (root) {
  const props: Dataset = getDataProps();

  ReactDOM.render(
    <WebComponentPortal containerElement={root}>
      <link
        href={props.stylelink}
        media="all"
        type="text/css"
        rel="stylesheet"
      />
      <App adId={props.adId} isMobile={props.isMobile} />
    </WebComponentPortal>,
    root
  );
}
