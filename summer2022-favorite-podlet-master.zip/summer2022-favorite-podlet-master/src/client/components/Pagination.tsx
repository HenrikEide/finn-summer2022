import React from "react";
import {
  PaginationContainer,
  PrevPage,
  Pages,
  Page,
  CurrentPage,
  NextPage,
} from "@finn-no/fabric-react-pagination-experiment";

type PaginationProps = {
  currentPage: number;
  setCurrentPage: (page: number) => void;
  totalPages: number;
};

const Pagination: React.FC<PaginationProps> = (props) => {
  const { currentPage, totalPages = 0, setCurrentPage } = props;

  if (!totalPages || totalPages <= 1) {
    return null;
  }

  return (
    <PaginationContainer
      currentPage={currentPage}
      lastPage={totalPages}
      className="pt-8 pb-4"
    >
      <PrevPage
        href="#"
        onClick={(event) => {
          event.preventDefault();
          setCurrentPage(currentPage - 1);
        }}
      />
      <Pages>
        {(page) => (
          <Page
            href="#"
            onClick={(event) => {
              event.preventDefault();
              setCurrentPage(page);
            }}
          />
        )}
      </Pages>
      <CurrentPage />
      <NextPage
        href="#"
        onClick={(event) => {
          event.preventDefault();
          setCurrentPage(currentPage + 1);
        }}
      />
    </PaginationContainer>
  );
};

export default Pagination;
