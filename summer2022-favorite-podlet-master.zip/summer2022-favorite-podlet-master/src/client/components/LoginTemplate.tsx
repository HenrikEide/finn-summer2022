import { Button } from "@fabric-ds/react";
import React from "react";

type LoginTemplateProps = {
  closeCallback: () => void;
  redirectUrl?: string;
};

const LoginTemplate: (
  props: LoginTemplateProps
) => [JSX.Element, JSX.Element, JSX.Element] = ({
  closeCallback,
  redirectUrl = window.location.href,
}: LoginTemplateProps) => {
  const footer: JSX.Element = (
    <>
      <Button link className="mr-8" onClick={closeCallback}>
        Ikke nå
      </Button>
      <a
        id={"loginButton"}
        className="button button--primary"
        href={`/loginForm.html?redirectTo=${encodeURIComponent(redirectUrl)}`}
      >
        Logg inn
      </a>
    </>
  );
  const body: JSX.Element = (
    <div className={"login"}>
      <p>
        Logg inn for å legge annonsen i dine favorittlister. Da kan du lett
        finne de igjen senere, uansett hvor du er.
      </p>
    </div>
  );
  return [body, footer, <h3 key="logginn">Logg inn</h3>];
};

export default LoginTemplate;
