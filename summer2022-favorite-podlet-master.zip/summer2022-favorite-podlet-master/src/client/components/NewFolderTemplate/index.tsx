import { TextField } from "@fabric-ds/react";
import React, { forwardRef, useImperativeHandle, useState } from "react";
import useCreateList from "../hooks/useCreateList";

export type NewFolderTemplateRef = {
  submit: () => void;
};
type NewFolderTemplateProps = {
  itemId: number;
  closeCallback: () => void;
  initialFocusRef: React.RefObject<HTMLInputElement>;
  ref: React.Ref<NewFolderTemplateRef>;
};
const NewFolderTemplate = forwardRef(
  (props: NewFolderTemplateProps, ref: React.Ref<NewFolderTemplateRef>) => {
    const { itemId, closeCallback, initialFocusRef } = props;
    const [folderName, setFolderName] = useState("");
    const [shouldValidate, setShouldValidate] = useState(false);
    const [errorMessage, setErrorMessage] = useState("");
    const createList = useCreateList({
      itemId,
      setErrorMessage,
      closeCallback,
    });
    async function onSubmitFolder() {
      if (!folderName.trim()) {
        if (initialFocusRef.current) {
          initialFocusRef.current.focus();
        }
        setShouldValidate(true);
        return;
      }
      createList(folderName);
    }
    useImperativeHandle(ref, () => ({ submit: () => onSubmitFolder() }));

    // Validation feedback shouldn't be shown until after the user have interacted with the input
    const inputField = (
      <TextField
        error={shouldValidate && folderName.trim().length < 1}
        helpText={`${folderName.length}/40 tegn`}
        label="Gi listen et navn"
        maxLength={40}
        onChange={(event) => setFolderName(event.target.value)}
        ref={initialFocusRef}
        required
        value={folderName}
      />
    );

    return (
      <form
        className="pb-8"
        onSubmit={(event) => {
          event.preventDefault();
          onSubmitFolder();
        }}
      >
        {inputField}
        {errorMessage && (
          <p className="text-red-600" role="alert">
            {errorMessage}
          </p>
        )}
      </form>
    );
  }
);

NewFolderTemplate.displayName = "NewFolderTemplate";
export default NewFolderTemplate;
