import { Button } from "@fabric-ds/react";
import NewFolderTemplate from ".";

type NewFolderTemplateRef = {
  submit: () => void;
};

type NewFolderTemplateProps = {
  itemId: number;
  closeCallback: () => void;
  initialFocusRef: React.RefObject<HTMLInputElement>;
  ref: React.Ref<NewFolderTemplateRef>;
};

type ModalContentProps = {
  onCancel: () => void;
  onSubmit: () => void;
};
const ModalContent: (
  props: NewFolderTemplateProps & ModalContentProps
) => [JSX.Element, JSX.Element, JSX.Element] = (
  props: NewFolderTemplateProps & ModalContentProps
) => {
  const { itemId, initialFocusRef, closeCallback, onCancel, onSubmit } = props;
  const footer = (
    <>
      <Button pill onClick={onCancel} className={"backButton"}>
        Tilbake
      </Button>
      <Button primary onClick={onSubmit}>
        Legg i liste
      </Button>
    </>
  );
  const body: JSX.Element = (
    <>
      <NewFolderTemplate
        itemId={itemId}
        initialFocusRef={initialFocusRef}
        closeCallback={closeCallback}
        ref={props.ref}
      />
    </>
  );
  return [
    body,
    footer,
    <h1 key="title" className="my-16 font-bold text-22">
      Ny liste
    </h1>,
  ];
};

export default ModalContent;
