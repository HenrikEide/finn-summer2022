import React, { useCallback, useRef, useState } from "react";
import { Modal } from "@fabric-ds/react";
import FoldersModalContent from "./FoldersTemplate/ModalContent";
import useFetchFolders from "./hooks/useFetchFolders";
import { NewFolderTemplateRef } from "./NewFolderTemplate";
import ModalContent from "./NewFolderTemplate/ModalContent";
import LoginTemplate from "./LoginTemplate";

type SaveAdModalProps = {
  itemType: string;
  itemId: number;
  setOpen: (isOpen: boolean) => void;
  isOpen: boolean;
  redirectUrl?: string;
  restoreFocus: () => void;
  toggled?: boolean;
  userId: number | string;
};

const isBrowser = typeof window !== "undefined";

const SaveAdModal: React.FC<SaveAdModalProps> = (props) => {
  const {
    itemType,
    itemId,
    setOpen,
    isOpen,
    redirectUrl,
    restoreFocus,
    toggled,
    userId,
  } = props;

  const [resetSearch, setResetSearch] = useState(false); // Reset whenever state is changed
  const [createNewFolder, setCreateNewFolder] = useState(false);
  const toggleCreateNewFolder = () => setCreateNewFolder(!createNewFolder);
  const [errorMessage, setErrorMessage] = useState<null | string>(null);
  const { items, errorMessage: fetchFoldersErrorMessage } = useFetchFolders({
    itemType,
    itemId,
    userId,
    isOpen,
  });
  const newFolderFormRef = useRef<NewFolderTemplateRef>(null);
  const FavoritesMoreOptionsFocusRef = useRef<HTMLInputElement | null>(null);
  const NewFolderTemplateFocusRef = useRef<HTMLInputElement | null>(null);

  const closeCallback = useCallback(() => {
    setErrorMessage("");
    setResetSearch(!resetSearch);
    setOpen(false);
    setCreateNewFolder(false);
    restoreFocus();
  }, [setOpen, restoreFocus]);

  const finalErrorMessage = errorMessage || fetchFoldersErrorMessage;

  const login = LoginTemplate({
    closeCallback,
    redirectUrl,
  });

  const newFolderModalContent = ModalContent({
    itemId,
    initialFocusRef: NewFolderTemplateFocusRef,
    closeCallback,
    ref: newFolderFormRef,
    onCancel: toggleCreateNewFolder,
    onSubmit: () => {
      newFolderFormRef.current!.submit();
      closeCallback();
    },
  });

  const foldersModalContent = FoldersModalContent({
    itemType,
    itemId,
    initialFocusRef: FavoritesMoreOptionsFocusRef,
    closeCallback,
    errorMessage: finalErrorMessage,
    items,
    setErrorMessage,
    toggleCreateNewFolder,
    resetSearch,
  });

  const getContent = () => {
    if (!userId) return login;
    if (createNewFolder) return newFolderModalContent;
    return foldersModalContent;
  };

  const [body, footer, title]: [
    JSX.Element,
    JSX.Element,
    JSX.Element | string
  ] = getContent();

  const modalProps = {
    open: isOpen,
    onDismiss: closeCallback,
    key: "favorite-modal",
    footer,
  };

  const modalView = isBrowser ? window.innerWidth > 479 : 0;
  const customStyles = (
    !userId && modalView ? { "--f-modal-width": "295px" } : {}
  ) as React.CSSProperties;

  return (
    <Modal title={title} {...modalProps} style={customStyles}>
      {body}
    </Modal>
  );
};

export default SaveAdModal;
