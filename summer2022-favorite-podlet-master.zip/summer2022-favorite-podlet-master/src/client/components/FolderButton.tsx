import { toast } from "@fabric-ds/elements/toast";
import classNames from "classnames";
import React, { forwardRef, useState } from "react";
import { Folder } from "./types";
import axiosInstance from "./axios";

type FolderButtonProps = {
  adExists: boolean;
  itemType: string;
  itemId: number;
  closeCallback: () => void;
  folder: Folder;
  handleError: (e: string) => void;
};

const doToast = (message: string, options: { type: "error" | "success" }) => {
  try {
    toast(message, options);
  } catch (e) {
    console.error("Problem toasting", e);
  }
};

const FolderButton = forwardRef(
  (props: FolderButtonProps, ref: React.Ref<HTMLButtonElement>) => {
    const { adExists, itemType, itemId, closeCallback, folder, handleError } =
      props;
    const [spinner, setSpinner] = useState(false);

    async function addFavorite() {
      try {
        axiosInstance.put(`api/addAdToAdList/${folder.id}/${itemId}`);
        doToast(`Favoritten ble lagt til i ${folder.title}`, {
          type: "success",
        });
        closeCallback();
      } catch (error) {
        console.error(error);

        setSpinner(false);

        handleError("Kunne ikke legge til favoritten. Prøv på nytt senere.");
      }
    }

    async function unFavorite() {
      try {
        await axiosInstance.delete(
          `api/removeAdFromAdList/${folder.id}/${itemId}`
        );
        doToast(`Fjernet favoritten fra ${folder.title}`, {
          type: "success",
        });
        closeCallback();
      } catch (error) {
        console.error(error);

        setSpinner(false);

        handleError("Kunne ikke fjerne favoritten. Prøv på nytt senere.");
      }
    }

    async function handleToggleFavorite() {
      // clear out any potential error messages, if none exists then it's a no-op
      handleError("");

      setSpinner(true);
      if (adExists) {
        await unFavorite();
      } else {
        await addFavorite();
      }
    }

    const classList = ["image"];
    if (adExists) {
      if (!folder.image) {
        classList.push("folderIconChecked");
      } else {
        classList.push("imageChecked");
      }
    } else {
      // eslint-disable-next-line no-lonely-if
      if (!folder.image) {
        classList.push("folderIcon");
      } else {
        classList.push("imageUnchecked");
      }
    }
    if (spinner) {
      classList.push("imageSpinner");
    }

    const image = `url(${folder.image})`;

    return (
      <button
        className={classNames("listButton")}
        onClick={handleToggleFavorite}
        aria-pressed={adExists}
        ref={ref}
      >
        <span
          className={classNames(classList)}
          style={{
            ["--image-url" as any]: image,
          }}
        />

        <span className={"label"}>{folder.title}</span>
      </button>
    );
  }
);

FolderButton.displayName = "FolderButton";

export default FolderButton;
