import { Button } from "@fabric-ds/react";
import React, { forwardRef } from "react";
import MultipleNeutral2 from "./resources/MultipleNeutral2";

type ShareButtonProps = {
  onClick: () => void;
  isMobile: boolean;
};

const ShareButton = forwardRef(
  (props: ShareButtonProps, ref: React.Ref<HTMLButtonElement>) => {
    const { onClick, isMobile } = props;

    const button = (
      /* Set the max height of the button to match the other icons placed near it.
       *  The height of the icons are 37px + 7px margin.
       */
      <Button pill onClick={onClick} ref={ref} style={{ maxHeight: "37px", maxWidth: "100%"}}>
        <div className="flex flex-row items-center">
          <MultipleNeutral2 />
          {isMobile ? null : (
            <p className="mb-0 text-16 font-bold">Delte lister</p>
          )}
        </div>
      </Button>
    );

    return button;
  }
);

ShareButton.displayName = "ShareButton";

export default ShareButton;
