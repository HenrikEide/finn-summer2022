import { Affix, TextField } from "@fabric-ds/react";
import React, { Ref } from "react";

type SearchProps = {
  onSearch: (searchQuery: string) => void;
  initialFocusRef: Ref<HTMLInputElement> | undefined;
};

const Search: React.FC<SearchProps> = ({ onSearch, initialFocusRef }) => (
  <TextField
    ref={initialFocusRef}
    className="mb-8"
    label="Søk etter en liste"
    type="search"
    placeholder="Navn på en liste"
    onChange={(event) => onSearch(event.target.value)}
  >
    <Affix
      suffix
      search
      // onClick={() => onSearch(initialFocusRef?.textfield?.value)}
    />
  </TextField>
);

export default Search;
