import classNames from "classnames";
import React, { forwardRef } from "react";

type NewListButtonProps = {
  onClick: () => void;
};

const NewListButton = forwardRef(
  ({ onClick }: NewListButtonProps, ref: React.Ref<HTMLButtonElement>) => (
    <button className={"listButton"} onClick={onClick} ref={ref}>
      <>
        <span className={classNames("plusButton", "plus")} />
        <span className={classNames("label")}>Lag ny liste</span>
      </>
    </button>
  )
);
NewListButton.displayName = "NewListButton";
export default NewListButton;
