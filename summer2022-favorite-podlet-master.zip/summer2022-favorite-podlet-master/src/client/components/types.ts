export type PaginationContent = {
  totalPages: number;
  startIndex: number;
  endIndex: number;
};

type FolderAdResponse = {
  extraInfo: string;
  id: number;
  image: string;
  info: string;
  location: string;
  marketplace: string;
  status: string;
  subtitle: string;
  title: string;
};

export type FolderResponse = {
  id: number;
  isOwner: boolean;
  title: string;
  ads: FolderAdResponse[];
};

export type Folder = {
  id: number;
  isOwner: boolean;
  title: string;
  ads: FolderAdResponse[];
  image?: string;
};
