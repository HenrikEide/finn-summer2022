import { useEffect, useState } from "react";
import type { Folder, FolderResponse } from "../types";
import axiosInstance from "../axios";

type UseFetchFoldersProps = {
  itemType: string;
  itemId: number;
  userId: number | string;
  isOpen: boolean;
};

const useFetchFolders = ({
  itemType,
  itemId,
  userId,
  isOpen,
}: UseFetchFoldersProps) => {
  const [items, setItems] = useState<Folder[]>([]);
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    if (!isOpen) {
      return;
    }
    let didCancel = false;
    async function fetchFolders() {
      try {
        const folderResponse: FolderResponse[] = await axiosInstance
          .get("api/fetchFolders")
          .then((res) => res.data);
        if (!didCancel) {
          const mappedFolders: Folder[] = folderResponse.map((folder) => ({
            ...folder,
            image: folder?.ads.length ? folder.ads[0].image : "",
          }));
          setItems(mappedFolders);
        }
      } catch (error: any) {
        console.error(error);
        setErrorMessage(error.toString());
      }
    }

    if (userId) {
      fetchFolders();

      // eslint-disable-next-line consistent-return
      return () => {
        didCancel = true;
      };
    }
  }, [itemType, itemId, userId, isOpen]);

  return { items, errorMessage };
};

export default useFetchFolders;
