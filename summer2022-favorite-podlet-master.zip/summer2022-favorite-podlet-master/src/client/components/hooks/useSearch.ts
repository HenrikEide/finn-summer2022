import { useMemo, useState } from "react";
import { Folder } from "../types";

type UseSearchProps = {
  items: Folder[];
};

const useSearch = ({ items }: UseSearchProps) => {
  const [searchQuery, setSearchQuery] = useState("");

  const filteredFavoriteLists = useMemo(() => {
    const query = searchQuery.toLowerCase();
    return query
      ? items.filter((fl) => fl.title.toLowerCase().includes(query))
      : items;
  }, [items, searchQuery]);

  return { searchQuery, setSearchQuery, filteredFavoriteLists };
};

export default useSearch;
