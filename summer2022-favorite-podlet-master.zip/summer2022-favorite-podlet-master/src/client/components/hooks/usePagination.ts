import { useEffect, useMemo, useState } from "react";
import { Folder, PaginationContent } from "../types";

type UsePaginationProps = {
  pageSize: number;
  folders: Folder[];
  searchQuery: string;
  specialButtons: number;
};

const usePagination = ({
  pageSize,
  folders,
  searchQuery,
  specialButtons,
}: UsePaginationProps) => {
  const [currentPage, setCurrentPage] = useState(1);
  const pagination = useMemo<PaginationContent>(() => {
    // The `+ ${specialButtons}` is because we're prepending special button(s) to the list
    const totalPages = Math.ceil((folders.length + specialButtons) / pageSize);
    // calculate start and end item indexes with logic to handle the "Ny liste" insertion
    const startIndex =
      (currentPage - 1) * pageSize - (currentPage > 1 ? specialButtons : 0);
    const endIndex = Math.min(
      currentPage * pageSize - 1 - specialButtons,
      folders.length - 1
    );
    return {
      totalPages,
      startIndex,
      endIndex,
    };
  }, [currentPage, folders.length, pageSize, specialButtons]);
  const paginatedFolders = useMemo(
    () =>
      folders.filter(
        (_, index) =>
          index >= pagination.startIndex && index <= pagination.endIndex
      ),
    [folders, pagination.endIndex, pagination.startIndex]
  );
  // If a search query happened or the list changed length we need to reset the pagination
  useEffect(() => {
    if (searchQuery || folders.length) {
      setCurrentPage(1);
    }
  }, [searchQuery, folders.length]);
  return { pagination, paginatedFolders, currentPage, setCurrentPage };
};

export default usePagination;
