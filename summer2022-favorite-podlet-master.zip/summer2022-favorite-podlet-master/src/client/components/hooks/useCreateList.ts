import { useRef } from "react";
import { toast } from "@fabric-ds/elements/toast";
import axiosInstance from "../axios";

type UseCreateListProps = {
  itemId: number;
  setErrorMessage: (errorMessage: string) => void;
  closeCallback: () => void;
};
const useCreateList = ({
  itemId,
  setErrorMessage,
  closeCallback,
}: UseCreateListProps) => {
  const submittingRef = useRef(false);
  return async (folderName: string, extraFlags?: string) => {
    // Just ignore additional submit events while processing the current request
    if (submittingRef.current) return;
    submittingRef.current = true;
    try {
      const res = await axiosInstance.post("api/createFolder", {
        listName: folderName,
        adId: itemId,
      });
    } catch (e) {
      console.log(e);
    }
  };
};

export default useCreateList;
