import React, { useRef, useCallback, useEffect, useState, Ref } from "react";
import { Button } from "@fabric-ds/react";
import usePagination from "../hooks/usePagination";
import useSearch from "../hooks/useSearch";
import Pagination from "../Pagination";
import Search from "../Search";
import { Folder } from "../types";
import FoldersTemplate from ".";

type ContentProps = {
  itemType: string;
  itemId: number;
  closeCallback: () => void;
  errorMessage: string;
  toggleCreateNewFolder: () => void;
  items: Folder[];
  setErrorMessage: (error: string) => void;
  initialFocusRef: Ref<HTMLInputElement>;
  resetSearch: boolean;
};

const ModalContent: (
  props: ContentProps
) => [JSX.Element, JSX.Element, JSX.Element] = (props) => {
  const {
    itemType,
    itemId,
    closeCallback,
    errorMessage,
    items,
    toggleCreateNewFolder,
    setErrorMessage,
    initialFocusRef,
    resetSearch,
  } = props;

  const { filteredFavoriteLists, searchQuery, setSearchQuery } = useSearch({
    items,
  });

  useEffect(() => {
    setSearchQuery("");
  }, [resetSearch, setSearchQuery]);

  const { currentPage, paginatedFolders, pagination, setCurrentPage } =
    usePagination({
      folders: filteredFavoriteLists,
      pageSize: 8,
      searchQuery,
      specialButtons: 1,
    });

  const focusFirstItemRef = useRef<HTMLButtonElement>(null);
  const [shouldFocusFirstItem, setShouldFocusFirstItem] = useState(false);
  const setCurrentPageAndFocusFirstItem = useCallback(
    (page: number) => {
      setCurrentPage(page);
      setShouldFocusFirstItem(true);
    },
    [setCurrentPage]
  );
  useEffect(() => {
    if (shouldFocusFirstItem && currentPage >= 0 && focusFirstItemRef.current) {
      focusFirstItemRef.current.focus();
      // Setting to false again to avoid the search input losing focus when typing
      setShouldFocusFirstItem(false);
    }
  }, [currentPage, shouldFocusFirstItem]);

  const footer: JSX.Element = <Button onClick={closeCallback}>Lukk</Button>;
  const body: JSX.Element = (
    <>
      <Button link href="/delte-lister" target="_blank" rel="noopener noreferrer">Hva er Delte lister?</Button>
      <div className="flex justify-between items-center">
        <Search
          onSearch={(searchQuery2) => setSearchQuery(searchQuery2)}
          initialFocusRef={initialFocusRef}
        />
      </div>
      {searchQuery !== "" && filteredFavoriteLists.length < 1 ? (
        <p className="pt-32 px-8 text-center text-16 font-bold">
          Fant ingen lister som svarer til søket ditt :(
        </p>
      ) : (
        <span />
      )}
      {errorMessage !== "" ? (
        <div className="text-red-600 my-16" role="alert">
          {errorMessage}
        </div>
      ) : (
        <span />
      )}
      <FoldersTemplate
        ref={focusFirstItemRef}
        itemType={itemType}
        itemId={itemId}
        closeCallback={closeCallback}
        folders={paginatedFolders}
        setErrorMessage={setErrorMessage}
        toggleCreateNewFolder={
          currentPage !== 1 || searchQuery ? undefined : toggleCreateNewFolder
        }
      />
      <Pagination
        currentPage={currentPage}
        setCurrentPage={setCurrentPageAndFocusFirstItem}
        totalPages={pagination.totalPages}
      />
    </>
  );
  return [
    body,
    footer,
    <h1 key="velgliste" className="my-16 font-bold text-22">
      Velg Delt liste
    </h1>,
  ];
};

export default ModalContent;
