import React, { forwardRef } from "react";
import MoreOptionsFolder from "../FolderButton";
import { Folder } from "../types";
import NewListButton from "../NewListButton";

type FoldersTemplateProps = {
  itemType: string;
  itemId: number;
  closeCallback: () => void;
  folders: Folder[];
  setErrorMessage: (error: string) => void;
  toggleCreateNewFolder?: () => void;
};

const checkIfAdIsInList = (adId: number, list: Folder) =>
  list.ads.some((ad) => adId === ad.id);

const FoldersTemplate = forwardRef(
  (props: FoldersTemplateProps, ref: React.Ref<HTMLButtonElement>) => {
    const {
      toggleCreateNewFolder,
      itemType,
      itemId,
      closeCallback,
      folders,
      setErrorMessage,
    } = props;

    // This CSS class mitigates a known style conflict between Troika and Fabric, as described
    // here https://github.schibsted.io/finn/fabric/blob/master/README.md#the-grid-class
    // The class can be removed once this component has been migrated to Fabric.
    const fabricOverrideClassName = "f-grid";

    return (
      <div
        style={{ margin: "0 -7px" }}
        className={`${"grid"} grid ${fabricOverrideClassName} grid-cols-3 sm:grid-cols-4`}
      >
        {toggleCreateNewFolder && (
          <div key="new-list">
            <NewListButton ref={ref} onClick={toggleCreateNewFolder} />
          </div>
        )}
        {folders.map((fl, index) => (
          <div key={fl.id}>
            <MoreOptionsFolder
              ref={!toggleCreateNewFolder && index === 0 ? ref : undefined}
              adExists={checkIfAdIsInList(itemId, fl)}
              itemType={itemType}
              itemId={itemId}
              closeCallback={closeCallback}
              folder={fl}
              handleError={(message) => setErrorMessage(message)}
              key={fl.id}
            />
          </div>
        ))}
      </div>
    );
  }
);

FoldersTemplate.displayName = "FoldersTemplate";

export default FoldersTemplate;
