import axios from "axios";
import { getDataProps } from "../utils/dataProps";

const { endpoint, finnToken } = getDataProps();

const axiosConfig = {
  baseURL: `${endpoint}/`,
  headers: {
    Authorization: `Bearer ${finnToken}`,
  },
};

const axiosInstance = axios.create({ ...axiosConfig });

export default axiosInstance;
