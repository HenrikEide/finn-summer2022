import { PureComponent, ReactNode } from 'react';
import ReactDOM from 'react-dom';

/**
 * This class makes it possible to mount a react component into a shadow dom.
 *
 * A shadow root is added to the container element that is provided through props,
 * then a react portal will be mounted into the shadow dom.
 */

type Props = {
    containerElement: HTMLElement;
    children: ReactNode;
};

class WebComponentPortal extends PureComponent<Props> {
    shadowRoot: ShadowRoot;

    constructor(props: Props) {
        super(props);

        this.shadowRoot = props.containerElement.attachShadow({
            mode: 'open',
        });
    }

    render() {
        return ReactDOM.createPortal(
            this.props.children,
            this.shadowRoot,
        ) as ReactNode;
    }
}

export default WebComponentPortal;
