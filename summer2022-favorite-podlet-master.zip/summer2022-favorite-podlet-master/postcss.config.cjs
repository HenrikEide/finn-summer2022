module.exports = () => ({
    plugins: [require('@eik/postcss-plugin')(), require('postcss-import')()],
});
