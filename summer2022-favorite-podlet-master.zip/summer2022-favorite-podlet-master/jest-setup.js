import '@testing-library/jest-dom';
import { jest } from '@jest/globals';


jest.mock('@finn-no/safe-props');
