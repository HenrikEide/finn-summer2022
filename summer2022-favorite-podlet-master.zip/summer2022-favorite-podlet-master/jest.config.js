export default {
    testEnvironment: 'jsdom',
    setupFilesAfterEnv: ['<rootDir>/jest-setup.js'],
    extensionsToTreatAsEsm: ['.jsx', '.tsx', '.ts'],
    testURL: 'https://finn.no/',
    verbose: true,
    moduleDirectories: ['node_modules', 'src/client'],
    transform: {
        '\\.[jt]sx?$': [
            'babel-jest',
            {
                babelrc: false,
                presets: [
                    [
                        '@babel/preset-env',
                        {
                            targets: {
                                node: '16',
                            },
                        },
                    ],
                    '@babel/preset-react',
                    '@babel/preset-typescript',
                ],
            },
        ],
    },
    testPathIgnorePatterns: [],
};
