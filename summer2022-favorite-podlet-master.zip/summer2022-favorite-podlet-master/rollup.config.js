import { nodeResolve } from "@rollup/plugin-node-resolve";
import { terser } from "rollup-plugin-terser";
import commonjs from "@rollup/plugin-commonjs";
import eik from "@eik/rollup-plugin";
import babel from "@rollup/plugin-babel";
import typescript from "@rollup/plugin-typescript";
import replace from "@rollup/plugin-replace";
import image from "@rollup/plugin-image";
import scss from "rollup-plugin-scss";

const config = {
  input: "src/client/index.tsx",
  plugins: [
    eik(),
    nodeResolve({
      browser: true,
      preferBuiltins: false,
      extensions: [".js", ".jsx", ".ts", ".tsx"],
    }),
    scss(),
    commonjs({ include: /node_modules/, requireReturnsDefault: false }),
    babel({
      babelHelpers: "runtime",
      exclude: "node_modules/**",
    }),
    terser({ format: { comments: false } }),
    replace({
      "process.env.NODE_ENV": JSON.stringify("production"),
      preventAssignment: true,
    }),
    typescript({ tsconfig: "./tsconfig.json" }),
    image(),
  ],
  output: [{ sourcemap: true, format: "esm", file: "dist/index.js" }],
};

export default config;
