# summer-fav-backend


# LOCAL DEV

* Install docker eg.: `brew install --cask docker`
* Install postgres eg.: `brew install postgresql`
* `docker-compose up`

* `summer-fav-backend.svc.dev.finn.no` for å hente fra dev

# How to run project

Navigate to root of project in terminal then do: ```sbt```, followed by usually
```reStart ``` or
```reStop``` which gives hot-reload

# sbt

* test
* compile
* validate
* ~ kjører kommando onsave
* reStart
* reStop

# scala extensions

https://pages.github.schibsted.io/finn/pf-scala-extensions/

# prerequisites

* psql for password retrieval
    - psql -h sharedfavorites.pg.dev.finn.no -U sharedfavorites_user -d sharedfavorites

# Annonse format skjema

https://dashboard.finn.no/adcontent/docs/

# format on save

Gå på "code style/Scala", velg Scalafmt som formatter og sjekk av "reformat on save" 

# data migration script 

https://gist.github.schibsted.io/henrik-olsen-eide/2ba77a8a0d46e1a99efe7278b0b5e777

# Hacks

## Profiles
Profiles has only changed events so also needed backfill (backfilled from pf-authorization)

Kafka topic: https://akhq.svc.prod.finn.no/ui/prod/topic/public.profile.changed

GetProfileImage lead down the code search rabbit hole of ending up with thrift service at -> https://github.schibsted.io/finn/profile-management/tree/master/profile-client. This requires implicitly env var CONSTRETTO_TAGS=dev/prod to not crash locally

## Fav
Kafka only has changes so needed backfill. Backfill ran from existing database cluster.

Kafka topic: https://akhq.svc.prod.finn.no/ui/prod/topic/public.favorite.change

Topic and does not have name for lists, so for new lists we run a request on behalf of the user to the old system to get the name of the list. This request then needs to pass the user token, but not as a Authorization header. To find the header in use we found an integration test in the repo to check for example.
