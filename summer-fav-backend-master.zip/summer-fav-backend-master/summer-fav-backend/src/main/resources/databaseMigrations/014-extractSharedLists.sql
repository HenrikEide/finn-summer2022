--liquibase formatted sql

--changeset vildetk:014-extractSharedLists

CREATE TABLE shared_list(
    shared_list_id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    is_public BOOLEAN NOT NULL,
    owner BIGINT NOT NULL
);

CREATE TABLE ads_in_shared_list(
    shared_list_id BIGINT NOT NULL REFERENCES shared_list(shared_list_id),
    ad_id BIGINT NOT NULL,
    pinned BOOLEAN NOT NULL
);

ALTER TABLE list drop column is_public;
ALTER TABLE ads_in_list drop column pinned;

ALTER TABLE access_levels DROP CONSTRAINT fk_list;
ALTER TABLE access_levels
    ADD CONSTRAINT fk_list FOREIGN KEY (list_id) REFERENCES shared_list(shared_list_id);

ALTER TABLE invites_finn_users DROP CONSTRAINT invites_finn_users_list_id_fkey;
ALTER TABLE invites_finn_users
    ADD CONSTRAINT invites_finn_users_list_id_fkey FOREIGN KEY (list_id) REFERENCES shared_list(shared_list_id);

--changeset vildetk:014-extractSharedLists2
ALTER TABLE ads_in_shared_list ALTER COLUMN pinned SET DEFAULT FALSE;