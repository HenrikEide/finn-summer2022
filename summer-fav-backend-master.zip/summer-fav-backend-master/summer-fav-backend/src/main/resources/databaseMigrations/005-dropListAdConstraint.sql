--liquibase formatted sql

--changeset district:005-dropListAdConstraint

ALTER TABLE ads_in_list
DROP CONSTRAINT fk_ad;
