--liquibase formatted sql

--changeset VillRubikk:003-createUserInviteTable
CREATE TABLE finn_user(
    user_id BIGINT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL
);

CREATE TABLE invites_finn_users(
    user_email TEXT NOT NULL,
    list_id BIGINT NOT NULL REFERENCES list (list_id),
    access_level VARCHAR(30) NOT NULL,
    created TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_email, list_id)
);