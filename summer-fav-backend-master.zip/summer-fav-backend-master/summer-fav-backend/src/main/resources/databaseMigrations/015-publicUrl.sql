--liquibase formatted sql

--changeset amumurst:015-publicUrl

ALTER TABLE shared_list DROP COLUMN is_public;
ALTER TABLE shared_list ADD COLUMN public_list_id VARCHAR(64);

--changeset amumurst:015-publicUrl2

ALTER TABLE shared_list ALTER COLUMN public_list_id TYPE VARCHAR(128);
