--liquibase formatted sql

--changeset vilde:000-createAdTable
CREATE TABLE finn_ad(
    ad_id BIGINT PRIMARY KEY
);

--changeset vilde:000-createAdTable2
ALTER TABLE finn_ad
    ADD COLUMN price DOUBLE PRECISION,
    ADD COLUMN updated timestamp with time zone DEFAULT now() NOT NULL;
