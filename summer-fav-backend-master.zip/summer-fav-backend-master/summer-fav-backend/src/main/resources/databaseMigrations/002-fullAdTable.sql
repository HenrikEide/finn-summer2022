--liquibase formatted sql

--changeset genser:002-fullAdTable
CREATE TABLE finn_full_ad(
    ad_id BIGINT PRIMARY KEY,
    title VARCHAR(80),
    subtitle VARCHAR(80),
    info VARCHAR(40),
    ad_location VARCHAR(40),
    ad_image VARCHAR(1000),
    extraInfo VARCHAR(20),
    ad_status VARCHAR(20)
);

--changeset genser:002-fullAdTable2
ALTER TABLE finn_full_ad
    ALTER COLUMN subtitle TYPE TEXT;
    
--changeset genser:002-fullAdTable3
ALTER TABLE finn_full_ad
    ALTER COLUMN title TYPE TEXT;