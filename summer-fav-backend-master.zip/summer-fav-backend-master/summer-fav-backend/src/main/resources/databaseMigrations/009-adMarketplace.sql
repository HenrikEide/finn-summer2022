--liquibase formatted sql

--changeset amumurst:009-adMarketplace

ALTER TABLE finn_full_ad
    ADD COLUMN marketplace TEXT;
