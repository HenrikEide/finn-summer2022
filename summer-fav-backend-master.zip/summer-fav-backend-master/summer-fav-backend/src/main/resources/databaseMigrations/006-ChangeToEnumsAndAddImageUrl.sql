--liquibase formatted sql

--changeset VillRubikk:006-ChangeToEnumsAndAddImageUrl

CREATE TYPE access_level AS ENUM ('WRITE', 'READ');

ALTER TABLE access_levels
    ALTER COLUMN access_level
        TYPE access_level USING (access_level::access_level);

ALTER TABLE finn_user
    ADD image TEXT NOT NULL;