--liquibase formatted sql

--changeset Lotfi:012-alterCommentsUpdated

ALTER TABLE ad_comments
    ALTER COLUMN updated
        SET DEFAULT now() at TIME ZONE 'Europe/Oslo';
