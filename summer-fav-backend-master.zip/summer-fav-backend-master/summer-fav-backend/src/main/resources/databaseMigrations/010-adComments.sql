--liquibase formatted sql

--changeset Lotfi:010-adComments

CREATE TABLE ad_comments(
    comment_id SERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    list_id BIGINT NOT NULL,
    ad_id BIGINT NOT NULL,
    text_content TEXT NOT NULL,
    updated timestamp with time zone DEFAULT now() NOT NULL
);

--changeset Lotfi:010-maxReadComment

CREATE TABLE max_read_comment (
    user_id BIGINT NOT NULL,
    list_id BIGINT NOT NULL,
    ad_id BIGINT NOT NULL,
    max_read_comment_id BIGINT NOT NULL,
    PRIMARY KEY (user_id,list_id,ad_id)
);
