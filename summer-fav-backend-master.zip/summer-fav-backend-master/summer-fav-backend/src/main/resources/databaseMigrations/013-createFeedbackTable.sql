--liquibase formatted sql

--changeset vildetk:013-createFeedbackTable

CREATE TABLE feedback(
    feedback_id SERIAL PRIMARY KEY,
    rating SMALLINT NOT NULL,
    comment TEXT,
    created TIMESTAMPTZ NOT NULL DEFAULT now()
);