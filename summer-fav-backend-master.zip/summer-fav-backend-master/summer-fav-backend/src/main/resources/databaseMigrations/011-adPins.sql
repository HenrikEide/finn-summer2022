--liquibase formatted sql

--changeset amumurst:011-adPins

ALTER TABLE ads_in_list ADD COLUMN pinned BOOLEAN NOT NULL DEFAULT FALSE;