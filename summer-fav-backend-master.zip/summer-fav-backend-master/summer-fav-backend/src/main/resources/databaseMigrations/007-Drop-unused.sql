--liquibase formatted sql

--changeset amumurst:007-Drop unused table

DROP TABLE finn_ad;