--liquibase formatted sql

--changeset genser:008-fullAdTable4
ALTER TABLE finn_full_ad
    ALTER COLUMN info TYPE TEXT;
