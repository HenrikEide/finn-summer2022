--liquibase formatted sql
--changeset genser:002-fullAdTable4
ALTER TABLE finn_full_ad
    ALTER COLUMN title TYPE TEXT;


ALTER TABLE ads_in_list
    DROP CONSTRAINT fk_ad;

ALTER TABLE ads_in_list
    ADD CONSTRAINT fk_ad
        FOREIGN KEY (ad_id)
            REFERENCES finn_full_ad(ad_id);



