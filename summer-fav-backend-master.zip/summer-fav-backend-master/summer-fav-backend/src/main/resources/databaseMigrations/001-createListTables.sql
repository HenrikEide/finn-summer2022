--liquibase formatted sql

--changeset RubiksKube:001-createListTables
CREATE TABLE list(
    list_id BIGINT PRIMARY KEY,
    name VARCHAR(100),
    is_public BOOLEAN,
    owner BIGINT
);

CREATE TABLE access_levels(
    user_id BIGINT,
    list_id BIGINT,
    access_level VARCHAR(30),
    PRIMARY KEY (user_id, list_id),
    CONSTRAINT fk_list
        FOREIGN KEY(list_id)
            REFERENCES list(list_id)
);

CREATE TABLE ads_in_list(
    list_id BIGINT,
    ad_id BIGINT,
    PRIMARY KEY (list_id, ad_id),
    CONSTRAINT fk_list
            FOREIGN KEY(list_id)
                REFERENCES list(list_id),
    CONSTRAINT fk_ad
            FOREIGN KEY(ad_id)
                REFERENCES finn_ad(ad_id)
);


--changeset RubiksKube:001-noNullsAtAllInTheDatabase
ALTER TABLE list
    ALTER COLUMN owner
        SET NOT NULL;

ALTER TABLE list
    ALTER COLUMN name
        SET NOT NULL;

ALTER TABLE list
    ALTER COLUMN is_public
        SET NOT NULL;

ALTER TABLE access_levels
    ALTER COLUMN access_level
        SET NOT NULL;