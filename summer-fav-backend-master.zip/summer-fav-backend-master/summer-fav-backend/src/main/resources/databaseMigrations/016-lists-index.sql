--liquibase formatted sql

--changeset amumurst:016-lists-index

CREATE INDEX IF NOT EXISTS list_owner_index ON list (owner);