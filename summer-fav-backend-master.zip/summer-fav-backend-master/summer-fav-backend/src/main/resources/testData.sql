
-- Copy and paste the sql from top to bottom to fill database with some test lists, given users correct access to list as well
-- The number: 1964305875 is your finn id on dev.finn.no should be changed to your own finn id was can be found here: https://dev.finn.no/pf/api/v1/user
-- Info on how to do get requests through authed routes is here: https://pages.github.schibsted.io/finn/pf-scala-extensions/auth/



654141927
237922452
INSERT INTO ad_comments(
              user_id,
              list_id,
              ad_id,
              text_content
           ) VALUES (
              654141927,
              971,
              237922452,
              'This is my first  comment ever lets go'
              )

SELECT ac.comment_id, ac.user_id, ac.list_id, ac.ad_id, ac.text_content
FROM ad_comments as ac
WHERE user_id = 654141927
AND list_id = 971
AND ad_id = 237922452

INSERT INTO finn_ad(
              ad_id,
              price
           ) VALUES (
              1,
              100
           );
INSERT INTO finn_ad(
              ad_id,
              price
           ) VALUES (
              2,
              200
           );
INSERT INTO finn_ad(
              ad_id,
              price
           ) VALUES (
              3,
              300
           );

INSERT INTO finn_ad(
              ad_id,
              price
           ) VALUES (
              4,
              400
           );

INSERT INTO list(
        list_id,
        name,
        is_public,
        owner
) VALUES (
        1,
        'Team Vill Rubikks liste',
        FALSE,
        137742857
);

INSERT INTO list(
        list_id,
        name,
        is_public,
        owner
) VALUES (
        2,
        'second es second list',
        FALSE,
        1964305875

);


INSERT INTO list(
        list_id,
        name,
        is_public,
        owner
) VALUES (
        3,
        'mikkel sin liste',
        FALSE,
        16551227325229322

);

INSERT INTO ads_in_list(
list_id,
ad_id
) VALUES(
1,
1
);

INSERT INTO ads_in_list(
list_id,
ad_id
) VALUES(
1,
2
);

INSERT INTO ads_in_list(
list_id,
ad_id
) VALUES(
1,
4
);

INSERT INTO ads_in_list(
list_id,
ad_id) Values (
2,
3
);

INSERT INTO access_levels(
user_id,
list_id,
access_level
) Values (
1964305875,
1,
'WRITE'
);

INSERT INTO access_levels(
user_id,
list_id,
access_level
) Values (
1964305875,
2,
'WRITE'
);

INSERT INTO access_levels(
user_id,
list_id,
access_level
) Values (
16551227325229322,
3,
'WRITE'
);

INSERT INTO finn_user VALUES (137742857, 'Ruben', 'ruben@ruben.ruben', 'https://i1.sndcdn.com/avatars-000211587193-3w9che-t500x500.jpg');
INSERT INTO finn_user VALUES (1964305875, 'Vilde', 'vilde@vilde.vilde', 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8cGVyc29ufGVufDB8fDB8fA%3D%3D&w=1000&q=80');
