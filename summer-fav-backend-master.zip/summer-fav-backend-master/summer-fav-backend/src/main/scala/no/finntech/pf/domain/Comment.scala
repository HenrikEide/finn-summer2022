package no.finntech.pf.domain

import java.time.LocalDateTime

final case class Comment(
    commentId: Long,
    commenter: Member,
    listId: Long,
    adId: Long,
    textContent: String,
    updated: LocalDateTime,
)

final case class CommentList(
    userId: Long,
    unreadComments: Int,
    comments: List[Comment],
)
