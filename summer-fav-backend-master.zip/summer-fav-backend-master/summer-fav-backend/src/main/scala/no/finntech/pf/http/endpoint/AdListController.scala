package no.finntech.pf.http.endpoint

import cats.effect._
import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}
import no.finntech.pf.domain.AdListService.AdListAccesses
import no.finntech.pf.domain.{AccessService, AdList, AdListService, ListedAd, UserAccessLevel}
import no.finntech.pf.extensions.auth._
import org.http4s._
import org.http4s.circe.CirceEntityCodec._
import org.http4s.circe.CirceSensitiveDataEntityDecoder.circeEntityDecoder
import org.http4s.dsl.io._

object AdListController {

  case class CreateListRequest(name: String)

  object CreateListRequest {
    implicit val decoder: Decoder[CreateListRequest] = deriveDecoder
  }

  case class CreateListResponse(id: Long)

  object CreateListResponse {
    implicit val encoder: Encoder[CreateListResponse] = deriveEncoder
  }

  case class ChangeNameRequest(listId: Long, newName: String)

  object ChangeNameRequest {
    implicit val decoder: Decoder[ChangeNameRequest] = deriveDecoder
  }

  case class AdResponse(
      id: Long,
      title: String,
      subtitle: String,
      info: String,
      location: String,
      image: String,
      extraInfo: String,
      status: String,
      marketplace: String,
      pinned: Boolean,
  )

  object AdResponse {
    def apply(listedAd: ListedAd): AdResponse = AdResponse(
      id = listedAd.ad.id,
      title = listedAd.ad.title,
      subtitle = listedAd.ad.subtitle,
      info = listedAd.ad.info,
      location = listedAd.ad.location,
      image = listedAd.ad.image,
      extraInfo = listedAd.ad.extraInfo,
      status = listedAd.ad.status,
      marketplace = listedAd.ad.marketplace,
      pinned = listedAd.pinned,
    )

    implicit val encode: Encoder[AdResponse] = deriveEncoder
  }

  case class AdListResponse(
      id: Long,
      title: String,
      ads: List[AdResponse],
      accessLevel: String,
      listOwner: String,
  )

  object AdListResponse {
    def apply(domainList: AdList, userAccessLevel: String): AdListResponse =
      AdListResponse(
        domainList.id,
        domainList.title,
        domainList.ads.reverse.map(AdResponse.apply),
        userAccessLevel,
        domainList.owner.name,
      )
    def apply(domainList: AdList, userAccessLevel: UserAccessLevel): AdListResponse =
      AdListResponse(
        domainList.id,
        domainList.title,
        domainList.ads.reverse.map(AdResponse.apply),
        accessLevelToResponseString(userAccessLevel),
        domainList.owner.name,
      )

    implicit val encode: Encoder[AdListResponse] = deriveEncoder
  }

  private case class MemberResponse(userId: Long, name: String, email: String, accessLevel: String, image: String)

  private object MemberResponse {
    implicit val encode: Encoder[MemberResponse] = deriveEncoder
  }

  private case class CreateListWithAdRequest(
      listName: String,
      adId: Long,
  )

  private object CreateListWithAdRequest {
    implicit val decoder: Decoder[CreateListWithAdRequest] = deriveDecoder
  }

  private case class ListMembersResponse(listMembers: List[MemberResponse], publicUrl: Option[String])

  def accessLevelToResponseString(userAccessLevel: UserAccessLevel): String = userAccessLevel match {
    case UserAccessLevel.READ  => "READ"
    case UserAccessLevel.WRITE => "WRITE"
    case UserAccessLevel.OWNER => "OWNER"
    case _                     => "NO_ACCESS"
  }

  private object ListMembersResponse {
    def create(adListAccesses: AdListAccesses): ListMembersResponse =
      ListMembersResponse(
        listMembers = adListAccesses.members.map { member =>
          MemberResponse(
            member.userId,
            member.name,
            member.email,
            accessLevelToResponseString(member.accessLevel),
            member.image,
          )
        },
        publicUrl = adListAccesses.publicUrl.map(_.renderString),
      )

    implicit val encode: Encoder[ListMembersResponse] = deriveEncoder
  }

  private case class PinToggleRequest(listId: Long, adId: Long)

  private object PinToggleRequest {
    implicit val decode: Decoder[PinToggleRequest] = deriveDecoder
  }

  object PublicListIdVar {
    //Public lists are strings only
    def unapply(s: String): Option[String] = s.toLongOption match {
      case Some(_) => None
      case None    => Some(s)
    }
  }

  def publicRoutes(adListService: AdListService, authService: AccessService): HttpRoutes[IO] = HttpRoutes.of {
    case GET -> Root / "api" / "list" / PublicListIdVar(listIdString) =>
      authService.getPublicAccessListId(listIdString).flatMap {
        case Some(listId) =>
          adListService.getAdList(listId).flatMap {
            case Some(domainList) => Ok(AdListResponse(domainList, "PUBLIC"))
            case None             => NotFound()
          }
        case None => NotFound("List does not appear to be public")
      }
  }

  def authedRoutes(adListService: AdListService, authService: AccessService): AuthedRoutes[AuthedFinnUserId, IO] =
    AuthedRoutes.of[AuthedFinnUserId, IO] {

      case GET -> Root / "api" / "is-list-collaborator" as user =>
        adListService.isListCollaborator(user.id).flatMap {
          case false => NoContent()
          case true  => Ok()
        }

      case req @ PATCH -> Root / "api" / "pin" as user =>
        for {
          data       <- req.req.as[PinToggleRequest]
          userAccess <- authService.getUserAccessLevel(user, data.listId)
          res <- userAccess match {
                   case UserAccessLevel.WRITE | UserAccessLevel.OWNER =>
                     adListService.toggleAdPin(data.adId, data.listId) *> Ok()
                   case _ =>
                     Forbidden("User can not pin in read mode")
                 }
        } yield res

      case DELETE -> Root / "api" / "list" / LongVar(listId) as user =>
        authService.getUserAccessLevel(user, listId).flatMap {
          case UserAccessLevel.OWNER =>
            adListService.deleteList(listId) *> Ok()
          case _ => Forbidden("Not your thing")
        }

      case GET -> Root / "api" / "lists" as user =>
        for {
          list <- adListService.getAdListsFromUser(user.id)
          jsonModel = list.readLists.map(adList => AdListResponse(adList, UserAccessLevel.READ)) ++
                        list.writeLists.map(adList => AdListResponse(adList, UserAccessLevel.WRITE)) ++
                        list.ownedLists.map(adList => AdListResponse(adList, UserAccessLevel.OWNER))
          response <- Ok(jsonModel)
        } yield response

      case GET -> Root / "api" / "ownWriteAccessLists" as user =>
        for {
          list <- adListService.getAdListsFromUser(user.id)
          jsonModel = list.writeLists.map(adList => AdListResponse(adList, UserAccessLevel.WRITE)) ++
                        list.ownedLists.map(adList => AdListResponse(adList, UserAccessLevel.OWNER))
          response <- Ok(jsonModel)
        } yield response

      case GET -> Root / "api" / "list" / LongVar(listId) as user =>
        authService.getUserAccessLevel(user, listId).flatMap {
          case UserAccessLevel.NO_ACCESS => Forbidden("Not your thing")
          case accessLevel @ (UserAccessLevel.READ | UserAccessLevel.WRITE | UserAccessLevel.OWNER) =>
            for {
              list <- adListService.getAdList(listId)
              response <- list match {
                            case Some(domainList) => Ok(AdListResponse(domainList, accessLevel))
                            case None             => NotFound()
                          }
            } yield response
        }

      case req @ POST -> Root / "api" / "list" as user =>
        for {
          json     <- req.req.as[CreateListRequest]
          id       <- adListService.createList(json.name, user.id)
          response <- Ok(CreateListResponse(id))
        } yield response

      case PATCH -> Root / "api" / "list" / LongVar(listId) as user =>
        authService.getUserAccessLevel(user, listId).flatMap {
          case UserAccessLevel.READ | UserAccessLevel.NO_ACCESS => Forbidden("Not your thing")
          case UserAccessLevel.WRITE | UserAccessLevel.OWNER =>
            for {
              //adListService.updateAdList(listId)
              response <- NotFound() // TODO: Send actual data :)
            } yield response
        }

      case PUT -> Root / "api" / "addAdToList" / LongVar(listId) / LongVar(adId) as user =>
        authService.getUserAccessLevel(user, listId).flatMap {
          case UserAccessLevel.READ | UserAccessLevel.NO_ACCESS => Forbidden("Not your thing")
          case UserAccessLevel.WRITE | UserAccessLevel.OWNER =>
            for {
              _        <- adListService.addToList(listId, adId)
              response <- Ok()
            } yield response
        }
      case DELETE -> Root / "api" / "deleteAdFromList" / LongVar(listId) / LongVar(adId) as user =>
        authService.getUserAccessLevel(user, listId).flatMap {
          case UserAccessLevel.READ | UserAccessLevel.NO_ACCESS => Forbidden("Not your thing")
          case UserAccessLevel.WRITE | UserAccessLevel.OWNER =>
            for {
              _        <- adListService.removeFromList(listId, adId)
              response <- Ok()
            } yield response
        }

      case GET -> Root / "api" / "list-members" / LongVar(listId) as user =>
        authService.getUserAccessLevel(user, listId).flatMap {
          case UserAccessLevel.OWNER =>
            for {
              listMembers <- adListService.getAdListAccesses(listId)
              response    <- Ok(ListMembersResponse.create(listMembers))
            } yield response
          case _ => Forbidden("Forbidden!")
        }

      case request @ PUT -> Root / "api" / "list" / "change-name" as user =>
        for {
          changeNameRequest         <- request.req.as[ChangeNameRequest]
          requestingUserAccessLevel <- authService.getUserAccessLevel(user, changeNameRequest.listId)
          response <- if (requestingUserAccessLevel == UserAccessLevel.OWNER)
                        adListService.changeAdListName(changeNameRequest.listId, changeNameRequest.newName) *> Ok()
                      else Forbidden()
        } yield response

      case req @ POST -> Root / "api" / "addAdToNewList" as user =>
        for {
          json     <- req.req.as[CreateListWithAdRequest]
          _        <- adListService.createListWithAd(json.listName, json.adId, user.id)
          response <- Ok()
        } yield response
    }
}
