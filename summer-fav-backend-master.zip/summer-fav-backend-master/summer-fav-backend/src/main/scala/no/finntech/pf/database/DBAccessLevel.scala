package no.finntech.pf.database

import doobie.Meta
import no.finntech.pf.domain.UserAccessLevel

sealed trait DBAccessLevel extends Product with Serializable {
  def asDomain: UserAccessLevel = this match {
    case DBAccessLevel.READ  => UserAccessLevel.READ
    case DBAccessLevel.WRITE => UserAccessLevel.WRITE
  }
}
object DBAccessLevel {
  case object READ  extends DBAccessLevel
  case object WRITE extends DBAccessLevel

  implicit val meta: Meta[DBAccessLevel] = Meta.StringMeta.imap {
    case "WRITE" => WRITE
    case "READ"  => READ
  } {
    case READ  => "READ"
    case WRITE => "WRITE"
  }
}
