package no.finntech.pf.kafka

import io.circe.Decoder
import io.circe.generic.semiauto.deriveDecoder
import no.finntech.pf.extensions.facade.types.FacadeDecoder
import no.finntech.pf.extensions.facade.types.json.data.{
  EstateRentalPriceFieldJson,
  EstateSizeFieldJson,
  ImageFieldJson,
  LocationFieldJson,
  MotorPriceFieldJson,
}

import java.time.LocalDate

sealed trait FacadeAd {
  def images: Option[List[ImageFieldJson]]

  def title: Option[String]

  def location: Option[LocationFieldJson]

  def disposed: Option[Boolean]
}

object FacadeAd {
  implicit val facadeDecoder: FacadeDecoder[FacadeAd] = FacadeDecoder(
    List(MotorAd.facadeDecoder, RealEstateAd.facadeDecoder, RentalAd.facadeDecoder, GeneralFacadeAd.facadeDecoder),
  )

  case class Deadline(date: Option[LocalDate], note: Option[String])

  object Deadline {
    implicit val decoder: Decoder[Deadline] = deriveDecoder[Deadline]
  }

  case class Company(name: Option[String])

  object Company {
    implicit val decoder: Decoder[Company] = deriveDecoder[Company]
  }

  case class Viewings(date: Option[LocalDate])

  object Viewings {
    implicit val decoder: Decoder[Viewings] = deriveDecoder[Viewings]
  }

  case class RentalDetails(max_price: Double)

  object RentalDetails {
    implicit val decoder: Decoder[RentalDetails] = deriveDecoder[RentalDetails]
  }

  case class EstatePriceFieldJson(
      collective_debt: Option[Double],
      total: Option[Double],
      currency: Option[String],
      suggestion: Option[Double],
  )

  object EstatePriceFieldJson {
    implicit val decoder: Decoder[EstatePriceFieldJson] = deriveDecoder[EstatePriceFieldJson]
  }

  case class MotorAd(
      images: Option[List[ImageFieldJson]],
      title: Option[String],
      price: Option[MotorPriceFieldJson],
      location: Option[LocationFieldJson],
      disposed: Option[Boolean],
  ) extends FacadeAd

  object MotorAd {
    implicit val decoder: Decoder[MotorAd] = deriveDecoder[MotorAd]

    //Only attempts to parse messages for given schema type
    implicit val facadeDecoder: FacadeDecoder[MotorAd] = FacadeDecoder(
      Set(
        "caravan",
        "car-used",
        "snowmobile",
        "moped",
        "mc",
        "mc-new",
        "truck",
        "agriculture-tresher",
        "agriculture-tools",
        "agriculture-tractor",
        "atv",
        "bus",
        "car-leasing",
        "car-leasing-business",
        "car-new",
        "car-subscription",
        "car-used-business",
        "motorcycle",
        "mobile-home",
        "construction",
      ),
    )
  }

  case class GeneralFacadeAd(
      images: Option[List[ImageFieldJson]],
      title: Option[String],
      price: Option[Double],
      application_deadline: Option[Deadline],
      company: Option[Company],
      location: Option[LocationFieldJson],
      disposed: Option[Boolean],
  ) extends FacadeAd

  object GeneralFacadeAd {
    implicit val decoder: Decoder[GeneralFacadeAd] = deriveDecoder[GeneralFacadeAd]

    //Only attempts to parse messages for given schema type
    implicit val facadeDecoder: FacadeDecoder[GeneralFacadeAd] = FacadeDecoder(
      Set(
        "bap-sell",
        "bap-gift-offer",
        "bap-gift-wish",
        "bap-giveaway",
        "bap-wanted",
        "boat-dock",
        "boat-motor",
        "boat-new-sale",
        "boat-sale",
        "boat-wanted",
        "company-for-sale",
        "job-agency-full-time",
        "job-agency-part-time",
        "job-full-time",
        "job-management",
        "job-part-time",
        "webstore",
        "realestate-development",
      ),
    )
  }

  case class RealEstateAd(
      images: Option[List[ImageFieldJson]],
      title: Option[String],
      price: Option[EstatePriceFieldJson],
      location: Option[LocationFieldJson],
      size: Option[EstateSizeFieldJson],
      rental_details: Option[RentalDetails],
      viewings: Option[List[Viewings]],
      disposed: Option[Boolean],
  ) extends FacadeAd

  object RealEstateAd {
    implicit val decoder: Decoder[RealEstateAd] = deriveDecoder[RealEstateAd]

    //Only attempts to parse messages for given schema type
    implicit val facadeDecoder: FacadeDecoder[RealEstateAd] = FacadeDecoder(
      Set(
        "realestate-abroad-sale",
        "realestate-business-plot",
        "realestate-business-sale",
        "realestate-development-project-unit",
        "realestate-development-single",
        "realestate-development-project",
        "realestate-home",
        "realestate-leisure-plot",
        "realestate-leisure-sale",
        "realestate-plot",
      ),
    )
  }

  case class RentalAd(
      images: Option[List[ImageFieldJson]],
      title: Option[String],
      price: Option[EstateRentalPriceFieldJson],
      location: Option[LocationFieldJson],
      size: Option[EstateSizeFieldJson],
      viewings: Option[List[Viewings]],
      disposed: Option[Boolean],
  ) extends FacadeAd

  object RentalAd {
    implicit val decoder: Decoder[RentalAd] = deriveDecoder[RentalAd]

    //Only attempts to parse messages for given schema type
    implicit val facadeDecoder: FacadeDecoder[RentalAd] = FacadeDecoder(
      Set(
        "realestate-letting",
        "realestate-business-letting",
        "realestate-letting-wanted",
      ),
    )
  }
}
