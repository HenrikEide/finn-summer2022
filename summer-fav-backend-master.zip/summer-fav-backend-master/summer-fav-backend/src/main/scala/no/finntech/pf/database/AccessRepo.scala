package no.finntech.pf.database

import cats.effect.IO
import doobie.implicits._
import doobie.util.transactor.Transactor
import no.finntech.pf.domain.{Member, UserAccessLevel}
import org.http4s.Uri

trait AccessRepo {

  def getUserId(email: String): IO[Option[Long]]

  def deleteUserInvite(email: String, listId: Long): IO[Unit]

  def getInvitationAccessLevel(email: String, listId: Long): IO[UserAccessLevel]

  def getUserEmail(uId: Long): IO[Option[String]]

  def addUserInvite(email: String, list_id: Long, access_level: UserAccessLevel): IO[Unit]

  def getAccessLevel(uId: Long, listId: Long): IO[UserAccessLevel]

  def setAccessLevel(uId: Long, listId: Long, accessLevel: UserAccessLevel): IO[Unit]

  def removeAccessLevel(uId: Long, listId: Long): IO[Unit]

  def setPublicAccess(publicListUri: Option[Uri], listId: Long): IO[Unit]

  def getParticipatingListIds(uid: Long): IO[List[(Long, UserAccessLevel)]]

  def getListIdForPublicAccess(publicListUri: Uri): IO[Option[Long]]

  def getPublicAcccessForListId(id: Long): IO[Option[Uri]]

  def getListMembers(listId: Long): IO[List[Member]]
}

object AccessRepo {
  def apply(transactor: Transactor[IO]): AccessRepo = new AccessRepo {

    override def getAccessLevel(uId: Long, listId: Long): IO[UserAccessLevel] = {
      val accessQuery: doobie.ConnectionIO[Option[UserAccessLevel]] =
        sql"SELECT access_level FROM access_levels WHERE list_id=$listId AND user_id=$uId"
          .query[DBAccessLevel]
          .map {
            case DBAccessLevel.READ  => UserAccessLevel.READ
            case DBAccessLevel.WRITE => UserAccessLevel.WRITE
          }
          .option

      val query: doobie.ConnectionIO[UserAccessLevel] = for {
        isOwner      <- Queries.ownerQuery(listId).map(_.exists(_.userId == uId))
        accessLevels <- accessQuery
      } yield
        if (isOwner) UserAccessLevel.OWNER
        else accessLevels.getOrElse(UserAccessLevel.NO_ACCESS)

      query.transact(transactor)
    }

    override def setAccessLevel(uId: Long, listId: Long, accessLevel: UserAccessLevel): IO[Unit] = {
      val accessLevelString = accessLevel match {
        case UserAccessLevel.READ  => Some(DBAccessLevel.READ)
        case UserAccessLevel.WRITE => Some(DBAccessLevel.WRITE)
        case _                     => None
      }
      accessLevelString match {
        case Some(level) =>
          sql"""
               INSERT INTO access_levels (user_id, list_id, access_level)
               VALUES($uId, $listId, $level::access_level)
               ON CONFLICT(user_id, list_id) DO UPDATE SET access_level=$level::access_level
             """.update.run
            .transact(transactor)
            .void
        case None => removeAccessLevel(uId, listId)
      }
    }

    override def removeAccessLevel(uId: Long, listId: Long): IO[Unit] =
      sql"""
            DELETE FROM access_levels WHERE user_id=$uId AND list_id=$listId
         """.update.run
        .transact(transactor)
        .void

    override def setPublicAccess(publicListUri: Option[Uri], listId: Long): IO[Unit] =
      sql"""
            UPDATE shared_list
            SET public_list_id=${publicListUri.map(_.renderString)}
            WHERE shared_list_id=$listId 
         """.update.run
        .transact(transactor)
        .void

    override def getParticipatingListIds(uid: Long): IO[List[(Long, UserAccessLevel)]] =
      sql"""SELECT list_id, access_level
           FROM access_levels
           WHERE user_id = $uid
         """
        .query[(Long, DBAccessLevel)]
        .map { case (id, level) => (id, level.asDomain) }
        .to[List]
        .transact(transactor)

    override def getListIdForPublicAccess(publicListUri: Uri): IO[Option[Long]] =
      sql"""
            SELECT shared_list_id from shared_list
            WHERE public_list_id=${publicListUri.renderString}
         """
        .query[Long]
        .option
        .transact(transactor)

    override def getPublicAcccessForListId(id: Long): IO[Option[Uri]] =
      sql"""
           SELECT public_list_id FROM shared_list WHERE shared_list_id=$id
         """.query[Option[String]].option.map(_.flatten.map(Uri.unsafeFromString)).transact(transactor)

    override def getListMembers(listId: Long): IO[List[Member]] = {
      val transaction = for {
        owner   <- Queries.ownerQuery(listId)
        members <- Queries.listMemberQuery(listId)
      } yield (owner.toList ++ members)
      transaction.transact(transactor)
    }

    override def addUserInvite(email: String, list_id: Long, access_level: UserAccessLevel): IO[Unit] = {
      val accessLevelString = access_level match {
        case UserAccessLevel.READ  => Some("READ")
        case UserAccessLevel.WRITE => Some("WRITE")
        case _                     => None
      }

      accessLevelString match {
        case Some(accessLevel) =>
          sql"""
           INSERT INTO invites_finn_users (user_email, list_id, access_level)
           VALUES ($email, $list_id, $accessLevel)
           ON CONFLICT(user_email, list_id) DO UPDATE SET access_level = $accessLevel 
         """.update.run
            .transact(transactor)
            .void
        case None => IO.unit
      }
    }

    override def getUserEmail(uId: Long): IO[Option[String]] =
      sql"SELECT email FROM finn_user WHERE user_id=$uId".query[String].option.transact(transactor)

    override def getInvitationAccessLevel(email: String, listId: Long): IO[UserAccessLevel] =
      sql"""SELECT access_level FROM invites_finn_users WHERE user_email=$email AND list_id=$listId"""
        .query[String]
        .option
        .transact(transactor)
        .map {
          case Some(accessLevel) =>
            accessLevel match {
              case "READ"  => UserAccessLevel.READ
              case "WRITE" => UserAccessLevel.WRITE
              case _       => UserAccessLevel.NO_ACCESS
            }
          case None => UserAccessLevel.NO_ACCESS
        }

    override def deleteUserInvite(email: String, listId: Long): IO[Unit] =
      sql"""
           DELETE FROM invites_finn_users WHERE user_email=$email AND list_id=$listId
         """.update.run
        .transact(transactor)
        .void

    override def getUserId(email: String): IO[Option[Long]] =
      sql"""
           SELECT user_id FROM finn_user WHERE email = $email
         """
        .query[Long]
        .option
        .transact(transactor)
  }

  object Queries {
    def ownerQuery(listId: Long): doobie.ConnectionIO[Option[Member]] =
      sql"""
            SELECT l.owner as user_id, fu.name, fu.email, fu.image
            FROM shared_list as l
              INNER JOIN finn_user as fu on l.owner = fu.user_id
            WHERE l.shared_list_id=$listId
         """
        .query[OwnerModel]
        .map(row =>
          Member(
            userId = row.userId,
            name = row.name,
            email = row.email,
            accessLevel = UserAccessLevel.OWNER,
            image = row.image,
          ),
        )
        .option

    def listMemberQuery(listId: Long) = sql"""
           SELECT al.user_id, al.access_level, fu.name, fu.email, fu.image
            FROM access_levels as al
              INNER JOIN finn_user as fu on al.user_id = fu.user_id
            WHERE al.list_id=$listId
         """
      .query[MemberModel]
      .map(row =>
        Member(
          userId = row.userId,
          name = row.name,
          email = row.email,
          accessLevel = row.accessLevel.asDomain,
          image = row.image,
        ),
      )
      .to[List]
  }
  case class OwnerModel(userId: Long, name: String, email: String, image: String)

  private case class MemberModel(
      userId: Long,
      accessLevel: DBAccessLevel,
      name: String,
      email: String,
      image: String,
  )
}
