package no.finntech.pf.database

import cats.effect.IO
import cats.syntax.all._
import doobie.implicits._
import doobie.util.transactor.Transactor
import no.finntech.pf.domain.{Ad, FavoriteList}

trait FavoriteRepo {
  def getAdListsFromUser(userId: Long): IO[List[FavoriteList]]

  def addToList(listId: Long, adId: Long): IO[Unit]

  def removeFromList(listId: Long, adId: Long): IO[Unit]

  def setListName(listId: Long, name: String): IO[Unit]

  def createNewList(listId: Long, userId: Long): IO[Unit]

  def deleteList(listId: Long): IO[Unit]

  def getFavoriteList(listId: Long): IO[Option[FavoriteList]]
}

object FavoriteRepo {

  val NO_GIVEN_NAME = "New list"

  def apply(transactor: Transactor[IO]): FavoriteRepo = new FavoriteRepo {

    override def addToList(listId: Long, adId: Long): IO[Unit] =
      sql"""INSERT INTO ads_in_list(list_id, ad_id)
            VALUES($listId, $adId)
            ON CONFLICT DO NOTHING
         """.update.run.transact(transactor).void

    override def removeFromList(listId: Long, adId: Long): IO[Unit] =
      sql"""DELETE FROM ads_in_list
            WHERE list_id=$listId
            AND ad_id=$adId
         """.update.run.transact(transactor).void

    override def setListName(listId: Long, name: String): IO[Unit] =
      sql"""UPDATE list SET name=$name
            WHERE list_id=$listId
         """.update.run.transact(transactor).void

    override def createNewList(listId: Long, userId: Long): IO[Unit] =
      sql"""INSERT INTO list(list_id, name, owner)
           VALUES($listId, $NO_GIVEN_NAME, $userId)
           ON CONFLICT (list_id) DO NOTHING
         """.update.run.transact(transactor).void

    override def deleteList(listId: Long): IO[Unit] =
      sql"""DELETE FROM list WHERE list_id=$listId""".update.run.transact(transactor).void

    override def getAdListsFromUser(userId: Long): IO[List[FavoriteList]] =
      for {
        listIds <- sql"""SELECT list_id FROM list WHERE owner=$userId""".query[Long].to[List].transact(transactor)
        lists   <- listIds.traverse(getFavoriteList)
      } yield lists.collect { case Some(list) if list.ads.nonEmpty => list }

    override def getFavoriteList(listId: Long): IO[Option[FavoriteList]] = {
      val selectAdDataQuery = sql"""
           SELECT 
              finn_full_ad.ad_id,
              finn_full_ad.title,
              finn_full_ad.subtitle,
              finn_full_ad.info,
              finn_full_ad.ad_location,
              finn_full_ad.ad_image,
              finn_full_ad.extrainfo,
              finn_full_ad.ad_status,
              finn_full_ad.marketplace
           FROM finn_full_ad WHERE ad_id in (SELECT ad_id FROM ads_in_list WHERE list_id=$listId);
         """
        .query[FavoriteListModel]
        .map(row =>
          Ad(
            id = row.ad_id,
            title = row.title,
            subtitle = row.subtitle,
            info = row.info,
            location = row.ad_location,
            image = row.ad_image,
            extraInfo = row.extraInfo,
            status = row.ad_status,
            marketplace = row.marketplace,
          ),
        )
        .to[List]

      val listNameQuery = sql"""SELECT name FROM list WHERE list_id=$listId""".query[String].option
      val transaction = for {
        listName <- listNameQuery
        ads      <- selectAdDataQuery
      } yield listName.map(title => FavoriteList(listId, title, ads))

      transaction.transact(transactor)
    }
  }
}

private case class FavoriteListModel(
    ad_id: Long,
    title: String,
    subtitle: String,
    info: String,
    ad_location: String,
    ad_image: String,
    extraInfo: String,
    ad_status: String,
    marketplace: String,
)
