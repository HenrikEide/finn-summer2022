package no.finntech.pf.domain

import cats.effect.IO
import no.finntech.pf.database.ProfileRepo
import no.finntech.profilemanagement.client.ProfileServiceImpl

import scala.jdk.CollectionConverters.MapHasAsScala

trait ProfileService {
  def setProfile(userId: Long, email: String, name: String): IO[Unit]

  def deleteProfile(userId: Long): IO[Unit]
}
object ProfileService {
  def apply(repo: ProfileRepo) = new ProfileService {
    val service = new ProfileServiceImpl()

    //IO to catch exceptions, Option to catch null
    def getProfileImage(userId: Long): IO[String] =
      IO(Option(service.getProfilePicture(userId))).map {
        case None => ""
        case Some(imageMap) =>
          imageMap.asScala.get("thumb") match {
            case Some(image) => image
            case None        => ""
          }
      }

    override def setProfile(userId: Long, email: String, name: String): IO[Unit] =
      for {
        image <- getProfileImage(userId)
        _     <- repo.setProfile(userId, email, name, image)
      } yield ()

    override def deleteProfile(userId: Long): IO[Unit] = repo.deleteProfile(userId)
  }
}
