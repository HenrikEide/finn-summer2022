package no.finntech.pf

import cats.effect.IO
import no.finntech.pf.extensions.postgres.DbConfig
import no.finntech.pf.extensions.{EnvReader, FiaasEnv}

object DatabaseSetup {
  val dbName = "sharedfavorites"

  def create(implicit env: FiaasEnv, envReader: EnvReader[IO]): IO[DbConfig] = env match {
    case FiaasEnv.Local =>
      /*
        Install docker eg.: `brew install --cask docker`
        Install postgres eg.: `brew install postgresql`
        `docker-compose up`
       */
      IO(DbConfig.local(dbName))
    case FiaasEnv.LocalDev =>
      //Passwords: https://vault.svc.dev.finn.no/ui/vault/secrets/secret/list/fiaas/default/summer-fav-backend/
      val config = DbConfig(
        dbName = dbName,
        hostName = "sharedfavorites.pg.dev.finn.no",
        username = "sharedfavorites_user",
        password = "", //use from vault
        adminUsername = "sharedfavorites_admin",
        adminPassword = "",
        sslMode = Some("require"),
      )
      IO(config)
    case FiaasEnv.Prod | FiaasEnv.Dev =>
      for {
        userPassword  <- envReader.unsafeGet("sharedfavorites-user-psql-password")
        adminPassword <- envReader.unsafeGet("sharedfavorites-admin-psql-password")
      } yield DbConfig(
        dbName = dbName,
        hostName = "sharedfavorites-pgsql",
        username = "sharedfavorites_user",
        password = userPassword,
        adminUsername = "sharedfavorites_admin",
        adminPassword = adminPassword,
        sslMode = Some("require"),
      )
  }
}
