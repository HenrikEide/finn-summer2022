package no.finntech.pf.domain

import cats.effect.IO
import no.finntech.pf.database.{AccessRepo, AdListRepo}
import no.finntech.pf.efflog.{EffectLogging, Logger}
import no.finntech.pf.kafka.NotificationProducer
import cats.data.OptionT

trait NotificationService {
  def inviteUser(email: String, list_id: Long, access_level: UserAccessLevel): IO[Unit]
}

object NotificationService extends EffectLogging {
  def apply(repo: AccessRepo, listRepo: AdListRepo, producer: NotificationProducer)(
      implicit L: Logger[IO],
  ): NotificationService =
    new NotificationService {

      /** Sends notification with invite to user
        * @param email
        *   Email of the recipient
        * @param listId
        *   List to be shared
        * @param access_level
        *   Access level to be given to recipient
        */
      override def inviteUser(email: String, listId: Long, access_level: UserAccessLevel): IO[Unit] = {
        val program = for {
          owner <- OptionT(listRepo.getOwner(listId))
                     .flatTapNone(logInfo(s"Tried to invite user but list $listId was not found"))
          ownerName <- OptionT(listRepo.getUserName(owner))
                         .flatTapNone(logInfo(s"Tried to invite user but user $owner was not found"))
          listName <- OptionT(listRepo.getListName(listId))
                        .flatTapNone(logInfo(s"Tried to invite user but $ownerName was not found"))
          userId <- OptionT(repo.getUserId(email))
                      .flatTapNone(logInfo(s"Tried to invite user but $email was not found"))
          _ <- OptionT.unless[IO, Unit](owner == userId)(()).flatTapNone(logInfo(s"User $listId did a self-invite"))
          _ <- OptionT.liftF(producer.notify(userId, ownerName, listId, listName))
        } yield ()
        program.value.void
      }
    }
}
