package no.finntech.pf.domain

import cats.effect.IO
import no.finntech.pf.database.{AccessRepo, AdListRepo}
import cats.syntax.all._
import no.finntech.pf.domain.AdListService.AdListAccesses
import org.http4s.Uri

trait AdListService {
  def createListWithAd(listName: String, adId: Long, userId: Long): IO[Unit]

  def changeAdListName(listId: Long, name: String): IO[Unit]

  def getAdListAccesses(listId: Long): IO[AdListAccesses]

  def createList(name: String, userId: Long): IO[Long]

  def getAdList(listId: Long): IO[Option[AdList]]

  def getListOwner(listId: Long): IO[Option[Member]]

  def getAdListsFromUser(userId: Long): IO[UserLists]

  def getWriteAccessLists(userId: Long): IO[List[AdList]]

  def isListCollaborator(userId: Long): IO[Boolean]

  def toggleAdPin(adId: Long, listId: Long): IO[Unit]

  def addToList(listId: Long, adId: Long): IO[Unit]

  def removeFromList(listId: Long, adId: Long): IO[Unit]

  def deleteList(listId: Long): IO[Unit]

  def makeListFromFavorites(favoriteList: FavoriteList, userId: Long): IO[Long]
}

object AdListService {
  case class AdListAccesses(members: List[Member], publicUrl: Option[Uri])

  def apply(repo: AdListRepo, accessRepo: AccessRepo) = new AdListService {
    override def getAdList(listId: Long): IO[Option[AdList]] = repo.getAdList(listId)

    override def getListOwner(listId: Long): IO[Option[Member]] =
      accessRepo.getListMembers(listId).map(_.find(_.accessLevel == UserAccessLevel.OWNER))

    override def isListCollaborator(userId: Long): IO[Boolean] =
      accessRepo
        .getParticipatingListIds(userId)
        .map(_.nonEmpty)

    override def toggleAdPin(adId: Long, listId: Long): IO[Unit] = repo.togglePin(adId, listId)

    override def getAdListsFromUser(userId: Long): IO[UserLists] =
      for {
        ownedListIds <- repo.getOwnedListIds(userId)
        ownedLists   <- ownedListIds.traverse(repo.getAdList).map(_.flatten)

        participatingListIds <- accessRepo.getParticipatingListIds(userId)

        readListIds  = participatingListIds.collect { case (id, UserAccessLevel.READ) => id }
        writeListIds = participatingListIds.collect { case (id, UserAccessLevel.WRITE) => id }

        readList   <- readListIds.traverse(repo.getAdList).map(_.flatten)
        writeLists <- writeListIds.traverse(repo.getAdList).map(_.flatten)

      } yield UserLists(ownedLists = ownedLists, readLists = readList, writeLists = writeLists)

    override def createList(name: String, userId: Long): IO[Long] =
      repo.createNewList(userId, name)

    override def getWriteAccessLists(userId: Long): IO[List[AdList]] = for {
      participatingListIds <-
        accessRepo.getParticipatingListIds(userId).map(_.collect { case (listId, UserAccessLevel.WRITE) => listId })
      participatingLists <- participatingListIds.traverse(repo.getAdList).map(_.flatten)
    } yield participatingLists

    override def addToList(listId: Long, adId: Long): IO[Unit] = repo.addToList(listId, adId)

    override def removeFromList(listId: Long, adId: Long): IO[Unit] = repo.removeFromList(listId, adId)

    override def getAdListAccesses(listId: Long): IO[AdListAccesses] =
      for {
        members <- accessRepo.getListMembers(listId)
        public  <- accessRepo.getPublicAcccessForListId(listId)
      } yield AdListAccesses(members, public)

    override def deleteList(listId: Long): IO[Unit] =
      repo.deleteListAndAllRelatedDbEntries(listId)

    override def changeAdListName(listId: Long, name: String): IO[Unit] =
      repo.changeListName(listId, name)

    override def makeListFromFavorites(favoriteList: FavoriteList, userId: Long): IO[Long] =
      for {
        listId <- createList(favoriteList.title, userId)
        _      <- favoriteList.ads.traverse(ad => addToList(listId, ad.id))
      } yield listId

    override def createListWithAd(listName: String, adId: Long, userId: Long): IO[Unit] =
      for {
        listId <- createList(listName, userId)
        _      <- addToList(listId, adId)
      } yield ()
  }
}
