package no.finntech.pf.database

import doobie.implicits._
import cats.effect.IO
import doobie.util.transactor.Transactor

trait FeedbackRepo {
  def insertFeedback(rating: Int, comment: String): IO[Long]
}

object FeedbackRepo {
  def apply(transactor: Transactor[IO]): FeedbackRepo = new FeedbackRepo {
    override def insertFeedback(rating: Int, comment: String): IO[Long] =
      sql"""
           INSERT INTO feedback(
              rating,
              comment
           ) VALUES (
              $rating,
              $comment
              )
         """.update
        .withUniqueGeneratedKeys[Long]("feedback_id")
        .transact(transactor)
  }
}
