package no.finntech.pf.http.endpoint

import cats.effect.IO
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}
import io.circe.{Decoder, Encoder}
import no.finntech.pf.domain.{Ad, FavoriteList, FavoriteService, UserAccessLevel}
import no.finntech.pf.extensions.auth.AuthedFinnUserId
import no.finntech.pf.http.endpoint.AdListController.AdListResponse
import org.http4s.Credentials.Token
import org.http4s._
import org.http4s.circe.CirceEntityCodec._
import org.http4s.dsl.io._
import org.http4s.headers.Authorization

object FavoriteController {

  private case class FavoriteResponse(
      id: Long,
      title: String,
      subtitle: String,
      info: String,
      location: String,
      image: String,
      extraInfo: String,
      status: String,
      marketplace: String,
  )

  private object FavoriteResponse {
    def apply(ad: Ad): FavoriteResponse = FavoriteResponse(
      id = ad.id,
      title = ad.title,
      subtitle = ad.subtitle,
      info = ad.info,
      location = ad.location,
      image = ad.image,
      extraInfo = ad.extraInfo,
      status = ad.status,
      marketplace = ad.marketplace,
    )

    implicit val encode: Encoder[FavoriteResponse] = deriveEncoder
  }

  private case class FavoriteListResponse(
      id: Long,
      title: String,
      ads: List[FavoriteResponse],
  )

  private object FavoriteListResponse {
    def apply(favoriteList: FavoriteList): FavoriteListResponse = FavoriteListResponse(
      favoriteList.id,
      favoriteList.title,
      favoriteList.ads.map(FavoriteResponse.apply),
    )
    implicit val encode: Encoder[FavoriteListResponse] = deriveEncoder
  }

  case class FavoriteExportRequest(listId: Long)
  object FavoriteExportRequest {
    implicit val decode: Decoder[FavoriteExportRequest] = deriveDecoder
  }

  def authedRoutes(favoriteService: FavoriteService): AuthedRoutes[AuthedFinnUserId, IO] =
    AuthedRoutes.of[AuthedFinnUserId, IO] {
      case req @ GET -> Root / "api" / "favorite-lists" as user =>
        for {
          favoriteLists <- favoriteService.getAdListsFromUser(user.id, extractToken(req.req))
          jsonModel      = favoriteLists.map(FavoriteListResponse.apply)
          response      <- Ok(jsonModel)
        } yield response

      case req @ POST -> Root / "api" / "export-as-shared-list" as user =>
        for {
          json   <- req.req.as[FavoriteExportRequest]
          result <- favoriteService.importFavoritesToAdList(json.listId, user.id)
          response <- result match {
                        case Some(adList) => Ok(AdListResponse(adList, UserAccessLevel.OWNER))
                        case None         => InternalServerError("Could not export list")
                      }
        } yield response

    }

  def extractToken(req: Request[IO]): Option[String] = req.headers
    .get[Authorization]
    .map(_.credentials)
    .collect { case Token(AuthScheme.Bearer, token) => token }
}
