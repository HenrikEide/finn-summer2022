package no.finntech.pf.http.endpoint

import cats.effect.IO
import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto._
import no.finntech.pf.domain.{AccessService, UserAccessLevel}
import no.finntech.pf.efflog.{EffectLogging, Logger}
import no.finntech.pf.extensions.auth.AuthedFinnUserId
import org.http4s.AuthedRoutes
import org.http4s.circe.CirceEntityCodec._
import org.http4s.dsl.io._

object AccessController extends EffectLogging {

  case class AccessRequestJson(uId: Long, listId: Long, userAccessLevel: String)

  object AccessRequestJson {
    implicit val decoder: Decoder[AccessRequestJson] = deriveDecoder
  }

  case class InviteUserRequestJson(list_id: Long, email: String, access_level: String)

  object InviteUserRequestJson {
    implicit val decoder: Decoder[InviteUserRequestJson] = deriveDecoder
  }

  case class ListIdJson(listId: Long)

  object ListIdJson {
    implicit val decoder: Decoder[ListIdJson] = deriveDecoder
  }

  case class ChangePublicRequestJson(isPublic: Boolean, listId: Long)

  object ChangePublicRequestJson {
    implicit val decoder: Decoder[ChangePublicRequestJson] = deriveDecoder
  }

  case class ChangePublicResponseJson(publicListId: Option[String])

  object ChangePublicResponseJson {
    implicit val encoder: Encoder[ChangePublicResponseJson] = deriveEncoder
  }

  private case class AccessChangeRequest(email: String, listId: Long, accessLevel: String)

  private object AccessChangeRequest {
    implicit val decode: Decoder[AccessChangeRequest] = deriveDecoder
  }

  def authedRoutes(accessService: AccessService, authService: AccessService)(
      implicit L: Logger[IO],
  ): AuthedRoutes[AuthedFinnUserId, IO] =
    AuthedRoutes.of[AuthedFinnUserId, IO] {

      case request @ POST -> Root / "api" / "change-access-level" as user =>
        for {
          accessChangeRequest     <- request.req.as[AccessChangeRequest]
          invitingUserAccessLevel <- authService.getUserAccessLevel(user, accessChangeRequest.listId)
          invitedUserAccessLevel = accessChangeRequest.accessLevel match {
                                     case "READ"  => UserAccessLevel.READ
                                     case "WRITE" => UserAccessLevel.WRITE
                                     case _       => UserAccessLevel.NO_ACCESS
                                   }
          response <-
            invitingUserAccessLevel match {
              case UserAccessLevel.OWNER =>
                for {
                  userId <- accessService.getUserIdFromEmail(accessChangeRequest.email)
                  response <- userId match {
                                case Some(id) =>
                                  accessService
                                    .setUserAccessLevel(id, accessChangeRequest.listId, invitedUserAccessLevel) *> Ok()
                                case None =>
                                  logInfo(s"Failed request, email doesn't exist: ${accessChangeRequest.email}") *> Ok()
                              }
                } yield response
              case UserAccessLevel.READ | UserAccessLevel.WRITE
                  if invitedUserAccessLevel == UserAccessLevel.NO_ACCESS =>
                accessService.setUserAccessLevel(user.id, accessChangeRequest.listId, UserAccessLevel.NO_ACCESS) *> Ok()

              case _ => Forbidden()
            }
        } yield response

      case request @ POST -> Root / "api" / "access" as user =>
        for {
          accessRequestJson       <- request.req.as[AccessRequestJson]
          invitingUserAccessLevel <- authService.getUserAccessLevel(user, accessRequestJson.listId)
          invitedUserAccessLevel = accessRequestJson.userAccessLevel match {
                                     case "READ"      => UserAccessLevel.READ
                                     case "WRITE"     => UserAccessLevel.WRITE
                                     case "NO_ACCESS" => UserAccessLevel.NO_ACCESS
                                     case _           => UserAccessLevel.NO_ACCESS
                                   }
          response <- if (invitingUserAccessLevel == UserAccessLevel.OWNER) {
                        accessService
                          .setUserAccessLevel(accessRequestJson.uId, accessRequestJson.listId, invitedUserAccessLevel)
                          .flatMap(_ => Ok())
                      } else Forbidden()
        } yield response

      case request @ POST -> Root / "api" / "accept-invitation" as user =>
        for {
          listIdJson <- request.req.as[ListIdJson]
          response <-
            accessService
              .grantUserAccessLevel(user.id, listIdJson.listId)
              .flatMap(_ => Ok())
        } yield response

      case request @ POST -> Root / "api" / "invite-user" as user =>
        for {
          inviteUserRequestJson   <- request.req.as[InviteUserRequestJson]
          invitingUserAccessLevel <- authService.getUserAccessLevel(user, inviteUserRequestJson.list_id)
          invitedUserAccessLevel = inviteUserRequestJson.access_level match {
                                     case "READ"  => UserAccessLevel.READ
                                     case "WRITE" => UserAccessLevel.WRITE
                                     case _       => UserAccessLevel.NO_ACCESS
                                   }
          response <- {
            if (invitingUserAccessLevel == UserAccessLevel.OWNER) {
              accessService
                .inviteUserByEmail(inviteUserRequestJson.email, inviteUserRequestJson.list_id, invitedUserAccessLevel)
                .flatMap(_ => Ok())
            } else Forbidden()
          }
        } yield response

      case request @ DELETE -> Root / "api" / "access" as user =>
        for {
          removeAccessRequestJson <- request.req.as[ListIdJson]
          invitingUserAccessLevel <- authService.getUserAccessLevel(user, removeAccessRequestJson.listId)
          response <- if (invitingUserAccessLevel == UserAccessLevel.OWNER) {
                        accessService
                          .deleteUserAccessLevel(user.id, removeAccessRequestJson.listId)
                          .flatMap(_ => Ok())
                      } else Forbidden()
        } yield response

      case request @ POST -> Root / "api" / "public" as user =>
        for {
          changePublicRequestJson <- request.req.as[ChangePublicRequestJson]
          invitingUserAccessLevel <- authService.getUserAccessLevel(user, changePublicRequestJson.listId)
          response <- if (invitingUserAccessLevel == UserAccessLevel.OWNER) {
                        accessService
                          .setPublicAccess(changePublicRequestJson.isPublic, changePublicRequestJson.listId)
                          .flatMap(id => Ok(ChangePublicResponseJson(id.map(_.renderString))))
                      } else Forbidden()
        } yield response
    }

}
