package no.finntech.pf.domain

import cats.effect.IO
import cats.syntax.all._
import no.finntech.pf.database.FavoriteRepo
import no.finntech.pf.efflog.{EffectLogging, Logger}

trait FavoriteService {

  def addToList(listId: Long, adId: Long, userId: Long): IO[Unit]

  def removeFromList(listId: Long, adId: Long): IO[Unit]

  def getAdListsFromUser(userId: Long, userToken: Option[String]): IO[List[FavoriteList]]

  def getFavoriteList(listId: Long): IO[Option[FavoriteList]]

  def importFavoritesToAdList(listId: Long, userId: Long): IO[Option[AdList]]
}

object FavoriteService extends EffectLogging {
  def apply(
      favoriteRepo: FavoriteRepo,
      legacyAdService: LegacyAdService,
      adListService: AdListService,
  )(implicit L: Logger[IO]): FavoriteService = new FavoriteService {

    def updateName(adList: FavoriteList, userToken: Option[String]): IO[FavoriteList] =
      for {
        new_name <- legacyAdService.getRealNameForList(adList.id, userToken)

        updatedList <- new_name match {
                         case Some(name) =>
                           favoriteRepo.setListName(adList.id, name).map(_ => adList.copy(title = name))
                         case None => IO(adList)
                       }
      } yield updatedList

    override def addToList(listId: Long, adId: Long, userId: Long): IO[Unit] =
      for {
        _ <- favoriteRepo.createNewList(listId, userId)
        _ <- favoriteRepo.addToList(listId, adId)
      } yield ()

    override def removeFromList(listId: Long, adId: Long): IO[Unit] =
      favoriteRepo.removeFromList(listId, adId)
    //Suspect to race condition on deletion of ad
    /*favoriteRepo.getFavoriteList(listId).flatMap {
          case Some(list) if list.ads.isEmpty => favoriteRepo.deleteList(listId)
          case _                              => IO.unit
        }
     */
    override def getAdListsFromUser(userId: Long, userToken: Option[String]): IO[List[FavoriteList]] =
      for {
        lists <- favoriteRepo.getAdListsFromUser(userId)
        fixedLists <- lists.traverse {
                        case list if list.title == FavoriteRepo.NO_GIVEN_NAME => updateName(list, userToken)
                        case list                                             => IO(list)
                      }
      } yield fixedLists

    override def getFavoriteList(listId: Long): IO[Option[FavoriteList]] =
      favoriteRepo.getFavoriteList(listId)

    override def importFavoritesToAdList(listId: Long, userId: Long): IO[Option[AdList]] =
      favoriteRepo.getAdListsFromUser(userId).map(_.find(_.id == listId)).flatMap {
        case Some(favoriteList) =>
          adListService
            .makeListFromFavorites(favoriteList, userId)
            .flatTap(sharedId => logInfo(s"User $userId exported list $listId as shared list id $sharedId"))
            .flatMap(adListService.getAdList)
        case None =>
          logWarn(s"User $userId tried to export list $listId but it does not seem like it owns it").as(None)
      }
  }
}
