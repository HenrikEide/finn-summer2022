package no.finntech.pf.domain

import cats.effect.IO
import no.finntech.pf.database.FeedbackRepo

trait FeedbackService {
  def insertFeedback(rating: Int, comment: String): IO[Long]
}

object FeedbackService {

  def apply(feedbackRepo: FeedbackRepo): FeedbackService = new FeedbackService {
    override def insertFeedback(rating: Int, comment: String): IO[Long] =
      feedbackRepo.insertFeedback(rating, comment)
  }

}
