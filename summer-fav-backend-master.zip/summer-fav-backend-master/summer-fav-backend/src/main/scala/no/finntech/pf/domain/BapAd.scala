package no.finntech.pf.domain

final case class Ad(
    id: Long,
    title: String,
    subtitle: String,
    info: String,
    location: String,
    image: String,
    extraInfo: String,
    status: String,
    marketplace: String,
)

case class ListedAd(ad: Ad, pinned: Boolean)

final case class AdList(
    id: Long,
    title: String,
    ads: List[ListedAd],
    owner: Member,
)

final case class UserLists(
    ownedLists: List[AdList],
    readLists: List[AdList],
    writeLists: List[AdList],
)

final case class FavoriteList(
    id: Long,
    title: String,
    ads: List[Ad],
)
