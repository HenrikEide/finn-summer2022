package no.finntech.pf.database

import cats.effect.IO
import doobie.implicits._
import doobie.util.transactor.Transactor

trait ProfileRepo {
  def setProfile(userId: Long, email: String, name: String, image: String): IO[Unit]

  def deleteProfile(userId: Long): IO[Unit]

}

object ProfileRepo {
  def apply(transactor: Transactor[IO]) = new ProfileRepo {
    override def setProfile(userId: Long, email: String, name: String, image: String): IO[Unit] =
      sql""" INSERT INTO finn_user(user_id, name, email, image)
            VALUES ($userId, $name, $email, $image)
            ON CONFLICT (user_id) DO UPDATE SET name=$name, email=$email, image=$image
           """.update.run.transact(transactor).void

    override def deleteProfile(userId: Long): IO[Unit] =
      sql"""
           DELETE FROM finn_user WHERE user_id=$userId;
         """.update.run.transact(transactor).void
  }
}
