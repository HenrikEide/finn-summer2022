package no.finntech.pf.database

import cats.effect.IO
import cats.syntax.all._
import doobie.implicits._
import doobie.util.transactor.Transactor
import no.finntech.pf.domain.{Ad, AdList, ListedAd}

trait AdListRepo {

  def togglePin(adId: Long, listId: Long): IO[Unit]

  def changeListName(listId: Long, name: String): IO[Unit]

  def deleteListAndAllRelatedDbEntries(listId: Long): IO[Unit]

  def getOwnedListIds(uId: Long): IO[List[Long]]

  def getAdList(listId: Long): IO[Option[AdList]]

  def addToList(listId: Long, adId: Long): IO[Unit]

  def removeFromList(listId: Long, adId: Long): IO[Unit]

  def createNewList(userId: Long, name: String): IO[Long]

  def getListName(listId: Long): IO[Option[String]]

  def getOwner(listId: Long): IO[Option[Long]]

  def getUserName(listId: Long): IO[Option[String]] // This one should prolly be moved to ProfileRepo
}

object AdListRepo {
  def apply(transactor: Transactor[IO]): AdListRepo = new AdListRepo {

    override def getAdList(listId: Long): IO[Option[AdList]] = {
      val selectAdDataQuery = sql"""
           SELECT
              finn_full_ad.ad_id,
              finn_full_ad.title,
              finn_full_ad.subtitle,
              finn_full_ad.info,
              finn_full_ad.ad_location,
              finn_full_ad.ad_image,
              finn_full_ad.extrainfo,
              finn_full_ad.ad_status,
              finn_full_ad.marketplace,
              ads_in_shared_list.pinned
           FROM ads_in_shared_list
           INNER JOIN finn_full_ad on ads_in_shared_list.ad_id = finn_full_ad.ad_id
           WHERE shared_list_id = $listId
         """
        .query[AdListModel]
        .map(_.asListedAd)
        .to[List]

      val listNameQuery = sql"""SELECT name FROM shared_list WHERE shared_list_id=$listId""".query[String].option

      val transaction = for {
        listName <- listNameQuery
        ads      <- selectAdDataQuery
        owner    <- AccessRepo.Queries.ownerQuery(listId)
      } yield (owner, listName).mapN { case (o, l) => AdList(listId, l, ads, o) }

      transaction.transact(transactor)
    }

    override def togglePin(adId: Long, listId: Long): IO[Unit] =
      sql"""UPDATE ads_in_shared_list
           SET pinned = NOT pinned
           WHERE ad_id=$adId AND shared_list_id=$listId""".update.run
        .transact(transactor)
        .void

    override def getOwnedListIds(uId: Long): IO[List[Long]] =
      sql"""SELECT shared_list_id
            FROM shared_list
            WHERE shared_list.owner = $uId"""
        .query[Long]
        .to[List]
        .transact(transactor)

    override def addToList(listId: Long, adId: Long): IO[Unit] =
      sql"""INSERT INTO ads_in_shared_list(shared_list_id, ad_id)
            VALUES($listId, $adId)
            ON CONFLICT DO NOTHING
         """.update.run.transact(transactor).void

    override def removeFromList(listId: Long, adId: Long): IO[Unit] =
      sql"""DELETE FROM ads_in_shared_list
            WHERE shared_list_id=$listId
            AND ad_id=$adId
         """.update.run.transact(transactor).void

    override def createNewList(userId: Long, name: String): IO[Long] =
      sql"""INSERT INTO shared_list(name, public_list_id, owner)
           VALUES($name, null, $userId)
           ON CONFLICT (shared_list_id) DO UPDATE SET name=$name
         """.update.withUniqueGeneratedKeys[Long]("shared_list_id").transact(transactor)

    override def deleteListAndAllRelatedDbEntries(listId: Long): IO[Unit] =
      sql"""
           DELETE FROM access_levels WHERE list_id = $listId;
           DELETE FROM invites_finn_users WHERE list_id = $listId;
           DELETE FROM ads_in_shared_list WHERE shared_list_id = $listId;
           DELETE FROM shared_list WHERE shared_list_id = $listId;
         """.update.run
        .transact(transactor)
        .void

    override def changeListName(listId: Long, name: String): IO[Unit] =
      sql"""
           UPDATE shared_list
           SET name = $name
           WHERE shared_list_id = $listId
         """.update.run
        .transact(transactor)
        .void

    override def getListName(listId: Long): IO[Option[String]] =
      sql"""
           SELECT name FROM shared_list WHERE shared_list_id=$listId
         """.query[String].option.transact(transactor)

    override def getOwner(listId: Long): IO[Option[Long]] =
      sql"""SELECT owner FROM shared_list WHERE shared_list_id=$listId""".query[Long].option.transact(transactor)

    override def getUserName(owner: Long): IO[Option[String]] =
      sql"""
             SELECT name FROM finn_user WHERE user_id=$owner
           """.query[String].option.transact(transactor)
  }

  private case class AdListModel(
      ad_id: Long,
      title: String,
      subtitle: String,
      info: String,
      ad_location: String,
      ad_image: String,
      extraInfo: String,
      ad_status: String,
      marketplace: String,
      pinned: Boolean,
  ) {
    def asListedAd = ListedAd(asAd, pinned)

    def asAd: Ad = Ad(
      id = ad_id,
      title = title,
      subtitle = subtitle,
      info = info,
      location = ad_location,
      image = ad_image,
      extraInfo = extraInfo,
      status = ad_status,
      marketplace = marketplace,
    )
  }
}
