package no.finntech.pf.domain

sealed trait UserAccessLevel extends Product with Serializable

object UserAccessLevel {
  case object READ      extends UserAccessLevel
  case object WRITE     extends UserAccessLevel
  case object OWNER     extends UserAccessLevel
  case object NO_ACCESS extends UserAccessLevel
}
