package no.finntech.pf.domain

import cats.effect.IO
import no.finntech.pf.database.AccessRepo
import no.finntech.pf.extensions.FiaasEnv
import no.finntech.pf.extensions.auth.AuthedFinnUserId
import org.http4s.Uri
import org.http4s.implicits._

import java.util.{Base64, UUID}

trait AccessService {
  def getUserIdFromEmail(email: String): IO[Option[Long]]

  def inviteUserByEmail(email: String, list_id: Long, access_level: UserAccessLevel): IO[Unit]

  def setUserAccessLevel(uId: Long, listId: Long, userAccessLevel: UserAccessLevel): IO[Unit]

  def deleteUserAccessLevel(uId: Long, listId: Long): IO[Unit]

  def setPublicAccess(isPublic: Boolean, listId: Long): IO[Option[Uri]]

  def getPublicAccessListId(publicListId: String): IO[Option[Long]]

  def grantUserAccessLevel(uId: Long, listId: Long): IO[Unit]

  def getUserAccessLevel(userId: AuthedFinnUserId, listId: Long): IO[UserAccessLevel]
}

object AccessService {
  def apply(repo: AccessRepo, notificationService: NotificationService)(implicit fiaasEnv: FiaasEnv): AccessService =
    new AccessService {
      override def setUserAccessLevel(uId: Long, listId: Long, userAccessLevel: UserAccessLevel): IO[Unit] =
        repo.setAccessLevel(uId, listId, userAccessLevel)

      override def getUserAccessLevel(userId: AuthedFinnUserId, listId: Long): IO[UserAccessLevel] =
        repo.getAccessLevel(userId.id, listId)

      override def deleteUserAccessLevel(uId: Long, listId: Long): IO[Unit] =
        repo.removeAccessLevel(uId, listId)

      override def setPublicAccess(isPublic: Boolean, listId: Long): IO[Option[Uri]] =
        repo.getPublicAcccessForListId(listId).flatMap {
          case Some(_) if !isPublic => repo.setPublicAccess(None, listId).as(None)
          case Some(existing)       => IO.some(existing)
          case None if isPublic =>
            makePublicUrl.map(Option(_)).flatTap(publicListId => repo.setPublicAccess(publicListId, listId))
          case None => IO.none
        }

      override def getPublicAccessListId(publicListId: String): IO[Option[Long]] =
        repo.getListIdForPublicAccess(makePublicUri(publicListId))

      override def inviteUserByEmail(email: String, list_id: Long, access_level: UserAccessLevel): IO[Unit] =
        for {
          _ <- repo.addUserInvite(email, list_id, access_level)
          _ <- notificationService.inviteUser(email, list_id, access_level)
        } yield ()

      override def grantUserAccessLevel(uId: Long, listId: Long): IO[Unit] =
        for {
          email <- repo.getUserEmail(uId)
          _ <- email match {
                 case Some(email) =>
                   for {
                     accessLevel <- repo.getInvitationAccessLevel(email, listId)
                     _ <- accessLevel match {
                            case UserAccessLevel.READ | UserAccessLevel.WRITE =>
                              repo
                                .setAccessLevel(uId, listId, accessLevel)
                                .flatMap(_ => repo.deleteUserInvite(email, listId))
                            case _ => IO.unit
                          }
                   } yield ()
                 case None => IO.unit
               }
        } yield ()

      override def getUserIdFromEmail(email: String): IO[Option[Long]] =
        repo.getUserId(email)
    }

  private val makePublicKey: IO[String] = IO(UUID.randomUUID())
    .map(_.toString.getBytes)
    .map(Base64.getUrlEncoder.encode)
    .map(new String(_))

  def makePublicUri(key: String)(implicit fiaasEnv: FiaasEnv): Uri =
    fiaasEnv match {
      case FiaasEnv.Local                   => uri"http://localhost:8080/delte-lister/adList" / key
      case FiaasEnv.Dev | FiaasEnv.LocalDev => uri"https://dev.finn.no/delte-lister/adList" / key
      case FiaasEnv.Prod                    => uri"https://www.finn.no/delte-lister/adList" / key
    }
  def makePublicUrl(implicit fiaasEnv: FiaasEnv): IO[Uri] = makePublicKey.map(makePublicUri)
}
