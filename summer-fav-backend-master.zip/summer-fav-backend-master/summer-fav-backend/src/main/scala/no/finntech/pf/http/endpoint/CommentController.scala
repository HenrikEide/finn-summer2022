package no.finntech.pf.http.endpoint

import cats.effect._
import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}
import no.finntech.pf.domain.{AccessService, Comment, CommentService, UserAccessLevel}
import no.finntech.pf.extensions.auth._
import org.http4s._
import org.http4s.circe.CirceEntityCodec._
import org.http4s.dsl.io._

import java.time.LocalDateTime

object CommentController {

  private case class CommentListResponse(userId: Long, unreadComments: Int, comments: List[CommentResponse])

  private object CommentListResponse {
    implicit val encode: Encoder[CommentListResponse] = deriveEncoder
  }
  private case class CommentResponse(
      commentId: Long,
      userId: Long,
      email: String,
      name: String,
      image: String,
      listId: Long,
      adId: Long,
      text: String,
      updated: LocalDateTime,
  )

  private object CommentResponse {
    def apply(comment: Comment): CommentResponse =
      CommentResponse(
        comment.commentId,
        comment.commenter.userId,
        comment.commenter.email,
        comment.commenter.name,
        comment.commenter.image,
        comment.listId,
        comment.adId,
        comment.textContent,
        comment.updated,
      )

    implicit val encode: Encoder[CommentResponse] = deriveEncoder
  }

  case class SelectCommentsRequest(listId: Long, adId: Long)

  object SelectCommentsRequest {
    implicit val decoder: Decoder[SelectCommentsRequest] = deriveDecoder
  }

  case class InsertCommentRequest(listId: Long, adId: Long, text: String)

  object InsertCommentRequest {
    implicit val decoder: Decoder[InsertCommentRequest] = deriveDecoder
  }

  case class InsertCommentResponse(commentId: Long)

  object InsertCommentResponse {
    implicit val encode: Encoder[InsertCommentResponse] = deriveEncoder
  }

  def authedRoutes(commentService: CommentService, authService: AccessService): AuthedRoutes[AuthedFinnUserId, IO] =
    AuthedRoutes.of[AuthedFinnUserId, IO] {
      case GET -> Root / "api" / "updateCommentsOnAdInList" / LongVar(listId) / LongVar(adId) as user =>
        for {
          requestingUserAccessLevel <- authService.getUserAccessLevel(user, listId)
          response <- requestingUserAccessLevel match {
                        case UserAccessLevel.WRITE | UserAccessLevel.OWNER =>
                          for {
                            commentListModel <- commentService.selectAndUpdateCommentsOnAdInList(
                                                  user.id,
                                                  listId,
                                                  adId,
                                                )
                            response <-
                              Ok(
                                CommentListResponse(
                                  userId = user.id,
                                  unreadComments = commentListModel.unreadComments,
                                  comments = commentListModel.comments.map(d => CommentResponse(d)),
                                ),
                              )

                          } yield response
                        case UserAccessLevel.READ | UserAccessLevel.NO_ACCESS => Forbidden()

                      }

        } yield response

      case GET -> Root / "api" / "commentsOnAdInList" / LongVar(listId) / LongVar(adId) as user =>
        for {
          requestingUserAccessLevel <- authService.getUserAccessLevel(user, listId)
          response <- requestingUserAccessLevel match {
                        case UserAccessLevel.WRITE | UserAccessLevel.OWNER =>
                          for {
                            commentListModel <- commentService.selectCommentsOnAdInList(
                                                  user.id,
                                                  listId,
                                                  adId,
                                                )
                            response <-
                              Ok(
                                CommentListResponse(
                                  userId = user.id,
                                  unreadComments = commentListModel.unreadComments,
                                  comments = commentListModel.comments.map(d => CommentResponse(d)),
                                ),
                              )

                          } yield response
                        case UserAccessLevel.READ | UserAccessLevel.NO_ACCESS => Forbidden()

                      }

        } yield response

      case req @ POST -> Root / "api" / "commentsOnAdInList" as user =>
        for {
          insertCommentRequest      <- req.req.as[InsertCommentRequest]
          requestingUserAccessLevel <- authService.getUserAccessLevel(user, insertCommentRequest.listId)
          response <- requestingUserAccessLevel match {
                        case UserAccessLevel.WRITE | UserAccessLevel.OWNER =>
                          insertCommentRequest.text match {
                            case "" => BadRequest("Comment cannot be empty")
                            case _ =>
                              commentService
                                .insertComment(
                                  userId = user.id,
                                  listId = insertCommentRequest.listId,
                                  adId = insertCommentRequest.adId,
                                  text = insertCommentRequest.text,
                                )
                                .flatMap(id => Ok(InsertCommentResponse(id)))
                          }
                        case UserAccessLevel.READ | UserAccessLevel.NO_ACCESS => Forbidden()

                      }

        } yield response

    }

}
