package no.finntech.pf.kafka

import no.finntech.pf.domain.Ad
import no.finntech.pf.extensions.facade.types.FacadeProcessor
import cats.effect.IO
import cats.syntax.all._
import no.finntech.pf.database.AdRepo
import no.finntech.pf.extensions.facade.types.json.{FacadeMessage, FacadeMode, FinnCode}
import no.finntech.pf.extensions.facade.types.ParsedAd
import no.finntech.pf.extensions.facade.types.FacadeProcessResult.JsonError.ValidationError
import no.finntech.pf.extensions.kafka.KafkaGroupId
import no.finntech.pf.extensions.facade.FacadeMessageProcessor
import no.finntech.pf.extensions.kafka.KafkaConsumerBuilder
import no.finntech.pf.efflog.Logger
import no.finntech.pf.efflog.EffectLogging
import no.finntech.pf.extensions.FiaasEnv
import no.finntech.pf.kafka.FacadeAd._

import java.time.LocalDate
import no.finntech.pf.postnummeroppslag.{PostnummerLookup, Poststed}

object FacadeReader extends EffectLogging {

  def parseDate(date: LocalDate): String =
    date.getDayOfMonth.toString + "." + date.getMonthValue.toString + "." + date.getYear.toString

  def makeInfo(model: FacadeAd): String =
    model match {
      case ad: GeneralFacadeAd =>
        val date_application: Option[LocalDate] = for {
          deadline <- ad.application_deadline
          date     <- deadline.date

        } yield date

        val note_application: Option[String] = for {
          deadline <- ad.application_deadline
          note     <- deadline.note

        } yield note

        ad.price match {
          case Some(value) => formatPrice(value)
          case None =>
            date_application
              .map(d => s"Søknadsfrist: ${parseDate(d)}")
              .orElse(note_application.map(n => s"Søknadsfrist: $n"))
              .getOrElse("")
        }

      case ad: MotorAd =>
        ad.price.flatMap(_.total) match {
          case Some(value) => formatPrice(value)
          case None        => ""
        }
      case ad: RealEstateAd =>
        ad.price.flatMap(_.total) match {
          case Some(value) => formatPrice(value)
          case None =>
            val suggestedPrice = for {
              price      <- ad.price
              suggestion <- price.suggestion
              currency   <- price.currency
            } yield formatPrice(suggestion, currency)

            suggestedPrice.getOrElse("")
        }

      case ad: RentalAd =>
        ad.price.flatMap(_.monthly) match {
          case Some(value) => formatPrice(value)
          case None        => ""
        }
      case _ => ""

    }

  def formatPrice(value: Double, currencySuffix: String = "kr"): String = {
    val price = formatSpacingPrice(value.toLong.toString)
    s"$price $currencySuffix"
  }
  def formatSpacingPrice(price: String): String =
    price.reverse.grouped(3).mkString(" ").reverse

  def findLocation(model: FacadeAd): String = {

    val poststed: Option[Poststed] = for {
      location <- model.location
      postkode <- location.postalcode
      poststed <- PostnummerLookup.poststed(postkode)

    } yield poststed

    poststed.map(s => s.poststed).getOrElse("")
  }

  def makeSubtitle(model: FacadeAd, schema: String): String =
    model match {
      case ad: GeneralFacadeAd =>
        val potentialCompany = for {
          company_complex <- ad.company
          company_name    <- company_complex.name
        } yield company_name

        potentialCompany match {
          case Some(company) => company
          case None =>
            schema match {
              case s"bap-giveaway"   => "Gis bort"
              case s"bap-gift-offer" => "Gis bort"
              case s"bap-wanted"     => "Ønskes kjøpt"
              case s"bap-gift-wish"  => "Ønsker kjøpt"
              case _                 => "Til salgs"
            }
        }

      case _: MotorAd => "Til salgs"
      case ad: RealEstateAd =>
        val viewingDate: Option[String] = for {
          viewlist <- ad.viewings
          viewing  <- viewlist.headOption
          date     <- viewing.date
        } yield parseDate(date)

        viewingDate.map(d => s"Visning: $d").getOrElse("")

      case ad: RentalAd =>
        val viewingDate: Option[String] = for {
          viewlist <- ad.viewings
          viewing  <- viewlist.headOption
          date     <- viewing.date
        } yield parseDate(date)

        viewingDate.map(d => s"Visning: $d").getOrElse("")
      case _ => ""
    }

  def findSize(model: FacadeAd): String =
    model match {
      case realestate: RealEstateAd =>
        realestate.size.flatMap(p => p.primary) match {
          case Some(potentialSize) => potentialSize.toInt.toString + " kvm"
          case None                => ""
        }
      case _ => ""
    }

  def marketPlaceForSchema(schema: String): String = schema match {
    case s"bap-$_"                => "Torget"
    case s"agriculture-tools"     => "Torget"
    case s"webstore"              => "Torget"
    case s"boat-$_"               => "Båt"
    case s"car-$_"                => "Kjøretøy"
    case s"mc$_"                  => "Kjøretøy"
    case s"moped"                 => "Kjøretøy"
    case s"motorcycle"            => "Kjøretøy"
    case s"snowmobile"            => "Kjøretøy"
    case s"moped"                 => "Kjøretøy"
    case s"agriculture-tresher"   => "Kjøretøy"
    case s"agriculture-tractor"   => "Kjøretøy"
    case s"bus"                   => "Kjøretøy"
    case s"truck"                 => "Kjøretøy"
    case s"mobile-home"           => "Kjøretøy"
    case s"caravan"               => "Kjøretøy"
    case s"realestate-$_"         => "Eiendom"
    case s"travel-holiday-rental" => "Reise"
    case s"job-$_"                => "Jobb"
    case s"construction"          => "Annet"
    case s"company-for-sale"      => "Annet"
    case _                        => "Annet"
  }

  def findStatus(ad: FacadeAd, mode: FacadeMode, schema: String): String =
    mode match {
      case FacadeMode.PLAY  => if (ad.disposed.contains(true)) makeDisposedField(schema) else "Aktiv"
      case FacadeMode.PAUSE => if (ad.disposed.contains(true)) makeDisposedField(schema) else "Inaktiv"
      case FacadeMode.STOP  => "Skjult"
      case FacadeMode.EJECT => "Slettet"
    }

  def makeDisposedField(schema: String): String = schema match {
    case s"job-$_"       => "Besatt"
    case s"$_-letting$_" => "Utleid"
    case _               => "Solgt"
  }

  def emptyAd(adId: Long, status: String) = Ad(
    id = adId,
    title = "Annonsen er utilgjengelig",
    subtitle = "",
    info = "",
    location = "",
    image =
      "https://images.finncdn.no/dynamic/default/2022/7/summer-fav-backend/20/d/sum/mer/-20/22-/una/vai/lab/le-/ad_2077163874.png",
    extraInfo = "",
    status = status,
    marketplace = "",
  )

  def startKafka(db: AdRepo)(implicit k: KafkaConsumerBuilder[IO], l: Logger[IO], fiaasEnv: FiaasEnv) = {
    val processor = new FacadeProcessor.Common[IO, Ad, FacadeAd] {

      // for STOP mode
      override def setEmpty(message: FacadeMessage): IO[Unit] =
        for {
          _ <- logInfo(s"clearing data for ${message.id.id}")
          _ <- db.insertFullAd(emptyAd(message.id.id, "Skjult"))
        } yield ()

      // for EJECT mode and tombstone
      def delete(key: FinnCode): IO[Unit] =
        for {
          _ <- logInfo(s"deletes $key")
          _ <- db.insertFullAd(emptyAd(key.id, "Slettet"))
        } yield ()

      // for PLAY and PAUSE
      def insert(message: ParsedAd[Ad]): IO[Unit] =
        for {
          _ <- logInfo(s"got message ${message.originalMessage.id}")
          _ <- db.insertFullAd(message.ad)
        } yield ()

      def parse(jsonModel: FacadeAd, message: FacadeMessage): Either[ValidationError, Ad] =
        Ad(
          id = message.id.id,
          title = jsonModel.title.getOrElse(""),
          subtitle = makeSubtitle(jsonModel, message.schema.name),
          info = makeInfo(jsonModel),
          location = findLocation(jsonModel),
          image = jsonModel.images.flatMap(_.headOption) match {
            case Some(value) =>
              fiaasEnv match {
                case FiaasEnv.Prod => "https://images.finncdn.no/dynamic/default/" + value.uri
                case _             => "https://dev-images.finncdn.no/dynamic/default/" + value.uri
              }
            case None => "https://static.finncdn.no/_c/mfinn/static/images/no-image.5bf83e47.svg"
          },
          extraInfo = findSize(jsonModel),
          status = findStatus(jsonModel, message.mode, message.schema.name),
          marketplace = marketPlaceForSchema(message.schema.name),
        ).asRight
    }

    val kafkaGroupId = fiaasEnv match {
      case FiaasEnv.Local    => KafkaGroupId("summer.fav.local.fredag5b") //Update to re read facade local
      case FiaasEnv.Dev      => KafkaGroupId("summer.fav.09")
      case FiaasEnv.LocalDev => KafkaGroupId("summer.fav.02")
      case FiaasEnv.Prod     => KafkaGroupId("summer.fav.07")
    }
    FacadeMessageProcessor.startDefault[IO, Ad, FacadeAd](kafkaGroupId, processor)
  }

}
