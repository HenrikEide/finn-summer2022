package no.finntech.pf.kafka

import cats.effect.IO
import fs2.kafka.{ConsumerRecord, RecordDeserializer}
import no.finntech.pf.domain.FavoriteService
import no.finntech.pf.efflog.{EffectLogging, Logger}
import no.finntech.pf.extensions.FiaasEnv
import no.finntech.pf.extensions.kafka.{KafkaConsumerBuilder, KafkaGroupId}
import vulcan.Codec
import vulcan.generic._

object FavoriteChangeConsumer extends EffectLogging {

  // our own domain model
  private case class FavoriteChange(loginId: Long, adId: Long, action: String, folderId: Long)

  // provides proof of valid json object. implicit = proof
  private object FavoriteChange {
    implicit val avroCodec: Codec[FavoriteChange] = Codec.derive[FavoriteChange]
  }

  def startKafka(
      service: FavoriteService,
      // proof for kafka connection, logging and fiaas environment. not needed as parameters
  )(implicit consumerBuilder: KafkaConsumerBuilder[IO], l: Logger[IO], fiaasEnv: FiaasEnv) = {

    def myProcess(
        change: ConsumerRecord[String, FavoriteChange],
    ): IO[Unit] =
      change.value.action match {
        case "add" =>
          for {
            _ <- service.addToList(change.value.folderId, change.value.adId, change.value.loginId)
            _ <- logInfo(s"Adding: ${change.value}")
          } yield ()
        case "remove" =>
          for {
            _ <- service.removeFromList(change.value.folderId, change.value.adId)
            _ <- logInfo(s"Removing: ${change.value}")
          } yield ()

        case other => logError(s"Unknown action: $other")
      }

    val kafkaGroupId = fiaasEnv match {
      case FiaasEnv.Local    => KafkaGroupId("summer.fav.local.01kr") //Update to re read favorite lists lokalt
      case FiaasEnv.Dev      => KafkaGroupId("summer.fav.01")
      case FiaasEnv.LocalDev => KafkaGroupId("summer.fav.01")
      case FiaasEnv.Prod     => KafkaGroupId("summer.fav.01")
    }

    // parse kafka message (avro) to domain model
    implicit val kafkaMessageDeserializer: RecordDeserializer[IO, FavoriteChange] =
      consumerBuilder.makeAvroDeserializer[FavoriteChange]

    consumerBuilder.startWithRetryAsync[String, FavoriteChange](
      groupId = kafkaGroupId,
      topicName = "public.favorite.change",
      processRecord = myProcess,
    )
  }

}
