package no.finntech.pf.domain

import cats.effect.IO
import cats.syntax.all._
import no.finntech.pf.database.{AccessRepo, AdListRepo, CommentRepo}

trait CommentService {
  def insertComment(userId: Long, listId: Long, adId: Long, text: String): IO[Long]

  def selectAndUpdateCommentsOnAdInList(userId: Long, listId: Long, adId: Long): IO[CommentList]

  def selectCommentsOnAdInList(userId: Long, listId: Long, adId: Long): IO[CommentList]
}

object CommentService {
  def apply(commentRepo: CommentRepo, accessRepo: AccessRepo): CommentService =
    new CommentService {
      override def insertComment(userId: Long, listId: Long, adId: Long, text: String): IO[Long] =
        commentRepo.insertComment(userId = userId, listId = listId, adId = adId, text = text)

      override def selectAndUpdateCommentsOnAdInList(userId: Long, listId: Long, adId: Long): IO[CommentList] =
        for {
          invitedUsers <- accessRepo.getListMembers(listId)
          allComments <-
            invitedUsers
              .flatTraverse(member => commentRepo.selectCommentsOnAdInList(member, listId, adId))
              .map(_.sortBy(_.updated))
          _ <-
            if (allComments != Nil) commentRepo.updateMaxReadComment(userId, listId, adId, allComments) else IO.unit
          maxReadComment <- commentRepo.selectMaxReadComment(userId, listId, adId)
          unreadComments  = allComments.count(_.commentId > maxReadComment)

        } yield CommentList(userId = userId, unreadComments = unreadComments, comments = allComments)

      override def selectCommentsOnAdInList(userId: Long, listId: Long, adId: Long): IO[CommentList] =
        for {

          invitedUsers <- accessRepo.getListMembers(listId)
          allComments <-
            invitedUsers
              .flatTraverse(member => commentRepo.selectCommentsOnAdInList(member, listId, adId))
              .map(_.sortBy(_.updated))
          maxReadComment <- commentRepo.selectMaxReadComment(userId, listId, adId)
          unreadComments  = allComments.count(_.commentId > maxReadComment)

        } yield CommentList(userId = userId, unreadComments = unreadComments, comments = allComments)
    }

}
