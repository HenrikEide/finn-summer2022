package no.finntech.pf.kafka

import cats.effect.IO
import fs2.kafka.{ConsumerRecord, RecordDeserializer}
import no.finntech.pf.domain.ProfileService
import no.finntech.pf.efflog.{EffectLogging, Logger}
import no.finntech.pf.extensions.FiaasEnv
import no.finntech.pf.extensions.kafka.{KafkaConsumerBuilder, KafkaGroupId}
import vulcan.Codec
import vulcan.generic._

object ProfileChangeConsumer extends EffectLogging {

  // our own domain model
  private case class ProfileChange(
      userId: Long,
      email: String,
      firstName: Option[String],
      surname: Option[String],
      displayName: String,
  ) {

    val bestEffortNameForFinnUser: String = {
      val fullName = for {
        first <- firstName.filterNot(_.isEmpty)
        sur   <- surname.filterNot(_.isEmpty)
      } yield s"$first $sur"

      fullName.getOrElse(displayName)
    }
  }

  // provides proof of valid json object. implicit = proof
  private object ProfileChange {
    implicit val avroCodec: Codec[ProfileChange] = Codec.derive[ProfileChange]
  }

  def startKafka(
      service: ProfileService,
      // proof for kafka connection, logging and fiaas environment. not needed as parameters
  )(implicit consumerBuilder: KafkaConsumerBuilder[IO], l: Logger[IO], fiaasEnv: FiaasEnv) = {

    def myProcess(
        change: ConsumerRecord[Long, Option[ProfileChange]],
    ): IO[Unit] = change.value match {
      case Some(user) =>
        for {
          _ <- logInfo(s"Saving user ${user.userId}")
          _ <- service.setProfile(user.userId, user.email, user.bestEffortNameForFinnUser)
        } yield ()

      case None =>
        for {
          _ <- logInfo(s"Deleting user ${change.key}")
          _ <- service.deleteProfile(change.key)
        } yield ()

    }

    val kafkaGroupId = fiaasEnv match {
      case FiaasEnv.Local    => KafkaGroupId("summer.fav.local.0111") //Update to re set profile data
      case FiaasEnv.Dev      => KafkaGroupId("summer.fav.01")
      case FiaasEnv.LocalDev => KafkaGroupId("summer.fav.01")
      case FiaasEnv.Prod     => KafkaGroupId("summer.fav.01")
    }

    // parse kafka message (avro) to domain model
    implicit val kafkaMessageDeserializer: RecordDeserializer[IO, Option[ProfileChange]] =
      consumerBuilder.makeAvroNullableDeserializer[ProfileChange]

    consumerBuilder.startWithRetryAsync[Long, Option[ProfileChange]](
      groupId = kafkaGroupId,
      topicName = "public.profile.changed",
      processRecord = myProcess,
    )
  }

}
