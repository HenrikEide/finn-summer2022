package no.finntech.pf.http.endpoint

import cats.effect.IO
import io.circe.Decoder
import io.circe.generic.semiauto.deriveDecoder
import no.finntech.pf.domain.FeedbackService
import org.http4s._
import org.http4s.circe.CirceEntityCodec._
import org.http4s.dsl.io._
import no.finntech.pf.extensions.auth.AuthedFinnUserId

object FeedbackController {

  case class FeedbackRequestJson(rating: Int, comment: String)

  object FeedbackRequestJson {
    implicit val decoder: Decoder[FeedbackRequestJson] = deriveDecoder
  }

  def authedRoutes(feedbackService: FeedbackService): AuthedRoutes[AuthedFinnUserId, IO] =
    AuthedRoutes.of[AuthedFinnUserId, IO] { case req @ POST -> Root / "api" / "feedback" as user =>
      for {
        feedbackRequestJson <- req.req.as[FeedbackRequestJson]
        response <- feedbackService
                      .insertFeedback(feedbackRequestJson.rating, feedbackRequestJson.comment)
                      .flatMap(id => Ok(id))
      } yield response
    }
}
