package no.finntech.pf.database

import cats.effect.IO
import doobie.implicits._
import doobie.postgres.implicits._
import doobie.util.transactor.Transactor
import no.finntech.pf.domain.{Comment, Member}

import java.time.{Instant, LocalDateTime, ZoneId, ZoneOffset}

trait CommentRepo {

  def selectCommentsOnAdInList(member: Member, listId: Long, adId: Long): IO[List[Comment]]

  def insertComment(userId: Long, listId: Long, adId: Long, text: String): IO[Long]

  def selectMaxReadComment(userId: Long, listId: Long, adId: Long): IO[Long]

  def updateMaxReadComment(userId: Long, listId: Long, adId: Long, allComments: List[Comment]): IO[Unit]

}

object CommentRepo {
  def apply(transactor: Transactor[IO]): CommentRepo = new CommentRepo {

    override def selectMaxReadComment(userId: Long, listId: Long, adId: Long): IO[Long] =
      sql"""
           SELECT max_read_comment_id
           FROM max_read_comment
           WHERE user_id = $userId
           AND list_id = $listId
           AND ad_id = $adId
         """
        .query[Long]
        .option
        .map(_.getOrElse(-1.toLong))
        .transact(transactor)

    override def updateMaxReadComment(userId: Long, listId: Long, adId: Long, allComments: List[Comment]): IO[Unit] = {
      val maxCommentId = allComments.maxBy(c => c.commentId).commentId
      sql"""
       INSERT INTO max_read_comment(
          user_id,
          list_id,
          ad_id,
          max_read_comment_id
       ) VALUES (
          $userId,
          $listId,
          $adId,
          $maxCommentId
          ) ON CONFLICT(user_id,list_id,ad_id) DO UPDATE SET
          user_id =$userId,
          list_id =$listId,
          ad_id =$adId,
          max_read_comment_id =$maxCommentId
     """.update.run.transact(transactor).void
    }

    override def selectCommentsOnAdInList(member: Member, listId: Long, adId: Long): IO[List[Comment]] = {

      val commentsQuery = sql"""
           SELECT ac.comment_id, ac.user_id, ac.list_id, ac.ad_id, ac.text_content,ac.updated
           FROM ad_comments as ac
           WHERE user_id = ${member.userId}
           AND list_id = $listId
           AND ad_id = $adId
           ORDER BY
                   ac.updated ASC
         """
        .query[CommentModel]
        .map(model =>
          Comment(
            commentId = model.comment_id,
            listId = model.list_id,
            adId = model.ad_id,
            textContent = model.text_content,
            updated = LocalDateTime.ofInstant(model.updated, ZoneId.of("Europe/Oslo")),
            commenter = member,
          ),
        )
        .to[List]

      val transaction = for {
        comments <- commentsQuery
      } yield comments

      transaction.transact(transactor)
    }

    override def insertComment(userId: Long, listId: Long, adId: Long, text: String): IO[Long] =
      sql"""
           INSERT INTO ad_comments(
              user_id,
              list_id,
              ad_id,
              text_content
           ) VALUES (
              $userId,
              $listId,
              $adId,
              $text
              )
         """.update
        .withUniqueGeneratedKeys[Long]("comment_id")
        .transact(transactor)

  }

  private case class CommentModel(
      comment_id: Long,
      user_id: Long,
      list_id: Long,
      ad_id: Long,
      text_content: String,
      updated: Instant,
  )

}
