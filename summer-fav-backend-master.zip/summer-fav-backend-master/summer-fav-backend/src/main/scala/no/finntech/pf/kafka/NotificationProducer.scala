package no.finntech.pf.kafka

import cats.effect.{IO, Resource}
import fs2.kafka.{KafkaSerializer, ProducerRecord, ProducerRecords, Serializer}
import io.confluent.kafka.serializers.KafkaAvroSerializer
import no.finntech.notification.avro._
import no.finntech.pf.database.AdListRepo
import no.finntech.pf.efflog.{EffectLogging, Logger}
import no.finntech.pf.extensions.FiaasEnv
import no.finntech.pf.extensions.kafka.KafkaProducerBuilder

import java.time.Instant

trait NotificationProducer {
  def notify(userId: Long, ownerName: String, listId: Long, listName: String): IO[Unit]
}
object NotificationProducer extends EffectLogging {
  val notificationTopic = "public.data.notification.personal"

  def apply(listRepo: AdListRepo)(
      implicit producerBuilder: KafkaProducerBuilder[IO],
      l: Logger[IO],
      fiaasEnv: FiaasEnv,
  ): Resource[IO, NotificationProducer] =
    Resource.eval(producerBuilder.avroSettings.schemaRegistryClient).flatMap { schemaClient =>
      val avroSerializer = new KafkaAvroSerializer(schemaClient)

      val targetPath = fiaasEnv match {
        case FiaasEnv.Prod => "https://finn.no/delte-lister/acceptingInvite/"
        case _             => "https://dev.finn.no/delte-lister/acceptingInvite/"
      }

      val javaSerializer: KafkaSerializer[PersonalNotificationMessage] =
        new KafkaSerializer[PersonalNotificationMessage] {
          override def serialize(topic: String, data: PersonalNotificationMessage): Array[Byte] =
            avroSerializer.serialize(notificationTopic, data)
        }

      implicit val serializer: Serializer[IO, PersonalNotificationMessage] =
        Serializer.delegate[IO, PersonalNotificationMessage](javaSerializer)

      producerBuilder.makeProducerExistingTopic[Option[Int], PersonalNotificationMessage](notificationTopic).map {
        producer =>
          new NotificationProducer {

            override def notify(userId: Long, ownerName: String, listId: Long, listName: String): IO[Unit] =
              listRepo.getAdList(listId).flatMap {
                case Some(adList) =>
                  val imageUrl = adList.ads.headOption.map(_.ad.image) match {
                    case Some(url) => url
                    case None      => DEFAULT_IMAGE
                  }
                  val model           = makeMessage(userId, ownerName, listId, listName, imageUrl, targetPath)
                  val record          = ProducerRecord(notificationTopic, None, model)
                  val producerRecords = ProducerRecords.one(record)
                  producer.produce(producerRecords).flatten.void *> logInfo(s"Sent notification to user $userId")
                case None => logWarn(s"List $listId was not found in DB")
              }

          }
      }
    }

  val DEFAULT_IMAGE = "https://static.finncdn.no/_c/mfinn/static/images/no-image.5bf83e47.svg"

  def makeMessage(
      userId: Long,
      ownerName: String,
      listId: Long,
      listName: String,
      imageUrl: String,
      targetUrl: String,
  ): PersonalNotificationMessage =
    PersonalNotificationMessage
      .newBuilder()
      .setUserId(userId)
      .setTrackingBuilder(PersonalMessageTracking.newBuilder().setId("myFavorites_user_invite"))
      .setImageBuilder(
        PersonalMessageImage
          .newBuilder()
          .setSource(PersonalMessageImageSource.URL)
          .setUrl(imageUrl),
      )
      .setNotificationCenterPersonalMessageBuilder( // TODO: Send actual data
        NotificationCenterPersonalMessage
          .newBuilder()
          .setTimestamp(Instant.now())
          .setTemplate("DEFAULT")
          .setContent(s"Du har blitt invitert til '$listName'")
          .setHeading(s"$ownerName ønsker å dele en liste med deg!")
          .setTargetUrl(targetUrl + listId)
          .setActionButtonBuilder(
            PersonalMessageActionButton
              .newBuilder()
              .setText("Aksepter invitasjon")
              .setUrl(targetUrl + listId),
          ),
      )
      .build()
}
