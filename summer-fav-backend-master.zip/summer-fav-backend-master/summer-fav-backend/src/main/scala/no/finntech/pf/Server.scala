package no.finntech.pf

import cats.effect.{IO, Resource}
import cats.implicits._
import no.finntech.pf.database._
import no.finntech.pf.domain._
import no.finntech.pf.extensions.FiaasEnv
import no.finntech.pf.extensions.app.PfHttpPostresKafkaApp
import no.finntech.pf.extensions.auth.FinnJwtMiddleware
import no.finntech.pf.extensions.http.PfHttpServer
import no.finntech.pf.extensions.postgres.DbConfig
import org.http4s.server.middleware.Logger.httpRoutes
import no.finntech.pf.kafka.{FacadeReader, FavoriteChangeConsumer, NotificationProducer, ProfileChangeConsumer}
import no.finntech.pf.http.endpoint.{
  AccessController,
  AdListController,
  CommentController,
  FavoriteController,
  FeedbackController,
}

object Server extends PfHttpPostresKafkaApp {

  override def server(implicit globalResources: Server.GlobalResources): Resource[IO, PfHttpServer[IO]] = {
    val loggerMw = httpRoutes[IO](logHeaders = true, logBody = true, logAction = Some((s: String) => logInfo(s)))(_)

    for {
      //Database
      _           <- postgresConnectFromGlobal.runLiquibaseFolder("databaseMigrations").resource
      transactor  <- postgresConnectFromGlobal.createTransactor()
      adDatabase   = AdRepo(transactor)
      accessRepo   = AccessRepo(transactor)
      listRepo     = AdListRepo(transactor)
      profileRepo  = ProfileRepo(transactor)
      commentRepo  = CommentRepo(transactor)
      feedbackRepo = FeedbackRepo(transactor)
      favoriteRepo = FavoriteRepo(transactor)

      // Producer kafka
      notificationProducer <- NotificationProducer(listRepo)

      //Services
      notificationService = NotificationService(accessRepo, listRepo, notificationProducer)
      legacyAdService    <- LegacyAdService()
      adListService       = AdListService(listRepo, accessRepo)
      favoriteService     = FavoriteService(favoriteRepo, legacyAdService, adListService)
      profileService      = ProfileService(profileRepo)
      accessService       = AccessService(accessRepo, notificationService)
      commentService      = CommentService(commentRepo, accessRepo)
      feedbackService     = FeedbackService(feedbackRepo)

      //Kafka
      _ <- FacadeReader.startKafka(adDatabase).resource
      _ <- FavoriteChangeConsumer.startKafka(favoriteService).resource
      _ <- ProfileChangeConsumer.startKafka(profileService).resource

      //Authorized Routes
      adListAuthRoutes   = AdListController.authedRoutes(adListService, accessService)
      accessAuthRoutes   = AccessController.authedRoutes(accessService, accessService)
      commentAuthRoutes  = CommentController.authedRoutes(commentService, accessService)
      feedbackAuthRoutes = FeedbackController.authedRoutes(feedbackService)
      favoriteAuthRoutes = FavoriteController.authedRoutes(favoriteService)
      middleware         = FinnJwtMiddleware.default

      //Routes
      adListRoutes   = middleware(adListAuthRoutes)
      favoriteRoutes = middleware(favoriteAuthRoutes)
      accessRoutes   = middleware(accessAuthRoutes)
      commentRoutes  = middleware(commentAuthRoutes)
      feedbackRoutes = middleware(feedbackAuthRoutes)
      adListPublic   = AdListController.publicRoutes(adListService, accessService)
      allRoutes      = adListPublic <+> adListRoutes <+> accessRoutes <+> commentRoutes <+> feedbackRoutes <+> favoriteRoutes
    } yield PfHttpServer[IO].withApp(allRoutes).withMiddleware(loggerMw)
  }

  override def dbConfigForEnv(implicit env: FiaasEnv): IO[DbConfig] = DatabaseSetup.create

  override def dbName: String = DatabaseSetup.dbName
}
