package no.finntech.pf.database

import cats.effect.IO
import doobie.implicits._
import doobie.util.transactor.Transactor
import no.finntech.pf.domain.Ad

trait AdRepo {
  def insertFullAd(ad: Ad): IO[Unit]
}

object AdRepo {
  def apply(transactor: Transactor[IO]): AdRepo = new AdRepo {
    override def insertFullAd(ad: Ad): IO[Unit] =
      sql"""
           INSERT INTO finn_full_ad(
              ad_id,
              title,
              subtitle,
              info,
              ad_location,
              ad_image,
              extraInfo,
              ad_status,
              marketplace
           ) VALUES (
              ${ad.id},
              ${ad.title},
              ${ad.subtitle},
              ${ad.info},
              ${ad.location},
              ${ad.image},
              ${ad.extraInfo},
              ${ad.status},           
              ${ad.marketplace}           
              ) ON CONFLICT(ad_id) DO UPDATE SET
              title =${ad.title},
              subtitle =${ad.subtitle},
              info =${ad.info},
              ad_location =${ad.location},
              ad_image = ${ad.image},
              extraInfo =${ad.extraInfo},
              ad_status =${ad.status},
              marketplace =${ad.marketplace}
         """.update.run.transact(transactor).void
  }

  private case class FavoriteDatabase(
      id: Long,
      title: String,
      subtitle: String,
      info: String,
      ad_location: String,
      ad_image: String,
      extraInfo: String,
      ad_status: String,
  )
}
