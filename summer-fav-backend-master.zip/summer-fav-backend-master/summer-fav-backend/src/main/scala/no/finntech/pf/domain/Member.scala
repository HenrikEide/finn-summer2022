package no.finntech.pf.domain

final case class Member(userId: Long, name: String, email: String, accessLevel: UserAccessLevel, image: String)
