package no.finntech.pf.domain

import cats.effect.IO
import cats.effect.kernel.Resource
import io.circe.Decoder
import io.circe.generic.semiauto.deriveDecoder
import no.finntech.pf.efflog.{EffectLogging, Logger}
import no.finntech.pf.extensions.FiaasEnv
import no.finntech.pf.extensions.http.HttpClientBuilder
import org.http4s.circe.CirceEntityCodec._
import org.http4s.implicits.http4sLiteralsSyntax
import org.http4s.{Header, Method, Request}
import org.typelevel.ci.CIStringSyntax

trait LegacyAdService {
  def getRealNameForList(listId: Long, userToken: Option[String]): IO[Option[String]]
}

object LegacyAdService extends EffectLogging {

  def favoriteUrl(implicit fiaasEnv: FiaasEnv) = fiaasEnv match {
    case FiaasEnv.Local | FiaasEnv.LocalDev => uri"http://favorite-api.svc.dev.finn.no/favorites"
    case FiaasEnv.Dev | FiaasEnv.Prod       => uri"http://favorite-api/favorites"
  }

  case class AdListResponse(name: String)

  object AdListResponse {
    implicit val decoder: Decoder[AdListResponse] = deriveDecoder
  }

  def apply()(
      implicit httpClientBuilder: HttpClientBuilder[IO],
      l: Logger[IO],
      fiaasEnv: FiaasEnv,
  ): Resource[IO, LegacyAdService] =
    httpClientBuilder.create().map { client =>
      new LegacyAdService {

        override def getRealNameForList(listId: Long, userToken: Option[String]): IO[Option[String]] =
          userToken match {
            case Some(token) =>
              val request = Request[IO]()
                .withMethod(Method.GET)
                .withUri(favoriteUrl / listId)
                .withHeaders(podiumHeader(token))

              for {
                apiResult <- client.expect[AdListResponse](request).attempt
                realName <- apiResult match {
                              case Left(a) =>
                                logWarn(s"Could not fetch real list name for list id $listId", a) *> IO.none
                              case Right(a) =>
                                logInfo(s"Fetched real name for list $listId from legacy system") *> IO.some(a.name)
                            }
              } yield realName
            case None => IO.none
          }

      }
    }

  private def podiumHeader(userToken: String) = Header.Raw(ci"podium-finn-token", userToken)
}
