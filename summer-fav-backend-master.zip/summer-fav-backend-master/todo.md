# Todo

* [x] Endpoint: setUserAccessLevel
* [x] Endpoint: delete userAccess db entry
* [x] Endpoint: toggle public
* [x] Endpoint: remove NO_ACCESS

  takes uId, listId, accessLevel as json
  