import sbt._

object Artifacts {

  val extensionsVersion = "2.3.6"

  lazy val allDependencies: Seq[ModuleID] = Seq(
    "no.finntech.pf.extensions" %% "app-http-kafka-db"   % extensionsVersion,
    "no.finntech.pf.extensions" %% "fs2-facade"          % extensionsVersion,
    "no.finntech.pf.extensions" %% "auth"                % extensionsVersion,
    "com.github.fd4s"           %% "vulcan-generic"      % "1.7.1",
    "no.finntech.profile"        % "profile-client"      % "6.3",
    "no.finntech.pf"            %% "postnummeroppslag"   % "1.1.8",
    "no.finntech.notification"   % "notification-schema" % "3.4.0",
  )
}
