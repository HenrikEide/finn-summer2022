import { IComment, ICommentList } from '../typings/IComment';
import axios from './axiosInstance';

export const getComments = async (body): Promise<ICommentList> => {
    const { listId, adId } = body;
    return axios
        .get('/api/comments/', { params: { listId: listId, adId: adId } })
        .then((res) => res.data);
};

export const getAndUpdateComments = async (body): Promise<ICommentList> => {
    const { listId, adId } = body;
    return axios
        .get('/api/updateComments/', { params: { listId: listId, adId: adId } })
        .then((res) => res.data);
};

export const postComment = async ({ listId, adId, text }): Promise<number> => {
    const data = { listId: listId, adId: adId, text: text };

    return axios.post('/api/comments/', data).then((res) => res.data);
};
