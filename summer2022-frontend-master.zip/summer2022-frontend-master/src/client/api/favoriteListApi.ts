import axios from './axiosInstance';
import { IAdLists } from '../typings/IAdList';

export const getFavoriteLists = async (): Promise<IAdLists> => {
    return axios.get('/api/favorite-lists').then((res) => res.data);
};

export const importFavoriteList = async (body): Promise<any> => {
    return axios
        .post(`/api/export-as-shared-list`, body)
        .then((res) => res.data);
};
