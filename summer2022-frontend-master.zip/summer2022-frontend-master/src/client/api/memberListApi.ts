import axios from './axiosInstance';
import { IMemberList } from '../typings/IMember';

export const getMemberList = async (listId): Promise<IMemberList> => {
    return axios.get(`api/list-members/${listId}`).then((res) => res.data);
};
