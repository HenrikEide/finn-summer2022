import axios from './axiosInstance';

export const postFeedback = async (rating, comment) => {
    return axios.post('/api/feedback', {
        rating,
        comment,
    });
};
