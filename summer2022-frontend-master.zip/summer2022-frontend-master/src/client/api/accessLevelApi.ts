import axios from './axiosInstance';

export const changeAccessLevel = async (email, listId, accessLevel) => {
    return axios.post('/api/change-access-level', {
        email,
        listId,
        accessLevel,
    });
};

export const acceptListInvite = (listId) => {
    return axios.post('/api/accept-invitation', { listId });
};

export const postInviteUser = async ({ listId, email, accessLevel }) => {
    return axios.post(`/api/invite-user/`, {
        email,
        list_id: listId,
        access_level: accessLevel,
    });
};

export const setListPublic = ({ isPublic, listId }) => {
    return axios
        .post('/api/toggle-list-public', { isPublic, listId })
        .then((res) => res.data);
};
