import axios from './axiosInstance';
import { IAdList, IAdLists } from '../typings/IAdList';

export const getAdLists = async (): Promise<IAdLists> => {
    return axios.get('/api/lists').then((res) => res.data);
};

export const getAdList = async (listId): Promise<IAdList> => {
    return axios.get(`/api/list/${listId}`).then((res) => res.data);
};

export const postAdList = async (body): Promise<any> => {
    return axios.post(`/api/list`, body).then((res) => res.data);
};

export const togglePinned = async (body): Promise<any> => {
    return axios.patch(`/api/pin`, body);
};

export const deleteAdFromList = async (listId, adId): Promise<any> => {
    return axios
        .delete(`/api/deleteAdFromList/${listId}/${adId}`)
        .then((res) => res);
};

export const deleteAdList = async (listId): Promise<any> => {
    return axios.delete(`/api/list/${listId}`);
};

export const putChangeListName = async (body): Promise<any> => {
    return axios.put(`/api/list/change-name`, body);
};
