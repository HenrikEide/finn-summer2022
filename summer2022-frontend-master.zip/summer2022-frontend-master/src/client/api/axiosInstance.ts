import axios from 'axios';

const axiosInstance = axios.create({
    baseURL: '/delte-lister',
    timeout: 4000,
    headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
    },
});

export default axiosInstance;
