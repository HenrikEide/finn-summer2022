import React, { useEffect, useMemo, useRef, useState } from 'react';
import { IAdLists } from '../typings/IAdList';
import { getAdLists } from '../api/adListApi';
import BreadCrumbs from '../components/LandingPage/BreadCrumbs';
import AdLists from '../components/LandingPage/AdLists';
import LandingPageInfo from '../components/LandingPage/LandingPageInfo';
import { LandingPageSearch } from '../components/LandingPage/LandingPageSearch';
import { NewListContainer } from '../components/LandingPage/NewList/NewListContainer';
import { applyAdListsSearch } from '../utils/filters';
import FavoriteListsExpandable from '../components/LandingPage/FavoriteListsExpandable';
import { getFavoriteLists } from '../api/favoriteListApi';
import StatusRibbon from '../components/LandingPage/StatusRibbon';
import EmptyListsNotis from '../components/LandingPage/EmptyListsNotis';
import { FeedbackCard } from '../components/AdCard/FeedbackCard';

const LandingPage = () => {
    const [adLists, setAdLists] = useState<IAdLists | null>(null);
    const [favoriteLists, setFavoriteLists] = useState<IAdLists | null>(null);
    const [change, setChange] = useState(false);
    const [openModal, setOpenModal] = useState(false);
    const [searchFilter, setSearchFilter] = useState('');
    const emptyLists = adLists?.length === 0;
    const feedbackRef = useRef(null);

    const toggleChange = () => setChange(!change);
    useEffect(() => {
        retrieveAdList();
        retrieveFavoriteList();
    }, [change]);

    const retrieveFavoriteList = async () => {
        const data: IAdLists = await getFavoriteLists();

        setFavoriteLists(data);
    };
    const retrieveAdList = async () => {
        const data: IAdLists = await getAdLists();
        setAdLists(data);
    };

    const applyFilters = (searchFilter: string, adLists: IAdLists) => {
        if (!adLists) return adLists;
        adLists = adLists.reverse();
        const search_result = applyAdListsSearch(searchFilter, adLists);
        return search_result;
    };

    const filteredFavoriteLists = useMemo(
        () => applyFilters(searchFilter, favoriteLists),
        [searchFilter, favoriteLists],
    );
    const filteredAdLists = useMemo(
        () => applyFilters(searchFilter, adLists),
        [searchFilter, adLists],
    );

    const scrollToFeedback = () => {
        feedbackRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    return (
        <div>
            <BreadCrumbs />
            <div className="flex flex-col md:flex-row md:space-x-112">
                <LandingPageInfo />
                <LandingPageSearch
                    searchFilter={searchFilter}
                    setSearchFilter={setSearchFilter}
                />
            </div>
            <StatusRibbon scrollToFeedback={scrollToFeedback} />
            <NewListContainer
                openModal={openModal}
                setOpenModal={setOpenModal}
                toggleChange={toggleChange}
            />
            <EmptyListsNotis emptyLists={emptyLists} />
            <div className="d-flex flex-column space-y-48 mb-40 mt-64">
                <AdLists
                    adLists={filteredAdLists}
                    toggleChange={toggleChange}
                />
            </div>
            <FavoriteListsExpandable
                adLists={filteredFavoriteLists}
                toggleChange={toggleChange}
                defaultExpanded={filteredAdLists?.length === 0}
            />
            <div
                ref={feedbackRef}
                className="mb-80 md:p-16 flex justify-center"
            >
                <FeedbackCard classNames="w-full md:w-1/2" />
            </div>
        </div>
    );
};

export default LandingPage;
