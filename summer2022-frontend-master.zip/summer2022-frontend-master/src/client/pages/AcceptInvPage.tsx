import React, { useState } from 'react';
import { acceptListInvite } from '../api/accessLevelApi';
import { Redirect, useParams } from 'react-router-dom';

const AcceptInvPage = () => {
    const { listId } = useParams<{ listId: string }>();
    const [redirect, setRedirect] = useState(false);

    acceptListInvite(listId).then(() => setRedirect(true));

    return redirect ? (
        <Redirect to={`/adList/${listId}`} />
    ) : (
        <h1>Sender deg til listen...</h1>
    );
};

export default AcceptInvPage;
