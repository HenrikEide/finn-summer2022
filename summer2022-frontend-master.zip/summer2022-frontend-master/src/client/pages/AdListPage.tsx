import React, { useEffect, useMemo, useState } from 'react';
import { IAdList } from '../typings/IAdList';
import { useParams, Link } from 'react-router-dom';
import {
    Affix,
    Breadcrumbs,
    Button,
    Select,
    TextField,
} from '@fabric-ds/react';
import { IconGrid16, IconList16 } from '@fabric-ds/icons/react';
import { AdList } from '../components/AdList/AdList';
import { getAdList } from '../api/adListApi';
import { AdListImage } from '../components/AdList/AdListImage';
import { AdListOptions } from '../components/AdList/AdListOptions';
import { PinnedAdList } from '@/client/components/AdList/PinnedAdList';
import { applyFilters } from '../utils/filters';
import { EmptyAdList } from '../components/AdList/EmptyAdList';

const AdListPage = () => {
    const [adList, setAdList] = useState<IAdList | null>(null);
    const [showGrid, setShowGrid] = useState(true);
    const { listId } = useParams<{ listId: string }>();
    const [change, setChange] = useState(false);
    const [searchFilter, setSearchFilter] = useState('');
    const [marketFilter, setMarketFilter] = useState('Alle');
    const [sortFilter, setSortFilter] = useState('sistLagtTil');

    const toggleChange = () => setChange(!change);

    const handleFilters = (setState, value) => {
        setState(value);
    };

    const retrieveList = async () => {
        const ads = await getAdList(listId);
        setAdList(ads);
    };

    const filteredAdList = useMemo<IAdList>(
        () => applyFilters(searchFilter, marketFilter, sortFilter, adList),
        [searchFilter, marketFilter, sortFilter, adList],
    );

    const shouldShowAdList = filteredAdList?.ads.length;

    useEffect(() => {
        retrieveList();
    }, [change]);

    //Ready to add if list-view is implemented
    const gridToListToggle = (
        <div className="flex justify-end items-end">
            <Button
                style={{ height: '48px' }}
                className="align-baseline"
                utility
                onClick={() => setShowGrid(!showGrid)}
            >
                {showGrid ? <IconList16 /> : <IconGrid16 />}
            </Button>
        </div>
    );

    const pinnedAds = {
        ...filteredAdList,
        ads: filteredAdList ? filteredAdList.ads.filter((v) => v.pinned) : null,
    };
    const unPinnedAds = {
        ...filteredAdList,
        ads: filteredAdList
            ? filteredAdList.ads.filter((v) => !v.pinned)
            : null,
    };

    return (
        <>
            <AdListImage adList={adList} />
            <Breadcrumbs>
                <a href={'/min-finn'}>Min FINN</a>
                <Link to="/">Delte lister</Link>
                <p>{adList?.title}</p>
            </Breadcrumbs>
            <div className="flex gap-16 md:grid grid-cols-4 mt-20">
                <TextField
                    onChange={(e) =>
                        handleFilters(setSearchFilter, e.target.value)
                    }
                    label="Søk i listen"
                    type="search"
                >
                    <Affix prefix search />
                </TextField>

                <Select
                    value={sortFilter}
                    onChange={(e) =>
                        handleFilters(setSortFilter, e.target.value)
                    }
                    label="Sortér etter"
                >
                    <option value="sistLagtTil">Sist lagt til</option>
                    <option value="status">Status</option>
                </Select>

                <Select
                    value={marketFilter}
                    onChange={(e) =>
                        handleFilters(setMarketFilter, e.target.value)
                    }
                    label="Filtrer på markedsplass"
                >
                    <option value={'Alle'}>Alle</option>
                    <option value={'Torget'}>Torget</option>
                    <option value={'Eiendom'}>Eiendom</option>
                    <option value={'Jobb'}>Jobb</option>
                    <option value={'Reise'}>Reise</option>
                    <option value={'Kjøretøy'}>Kjøretøy</option>
                    <option value={'Båt'}>Båt</option>
                    <option value={'Annet'}>Annet</option>
                </Select>
                <AdListOptions adList={adList} toggleChange={toggleChange} />
            </div>
            {shouldShowAdList ? (
                <>
                    <PinnedAdList
                        adList={pinnedAds}
                        toggleChange={toggleChange}
                    />
                    <AdList adList={unPinnedAds} toggleChange={toggleChange} />
                </>
            ) : (
                <EmptyAdList />
            )}
        </>
    );
};

export default AdListPage;
