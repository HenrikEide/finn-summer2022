import Fuse from 'fuse.js';
import { AdStatusOrder, IAdList, IAdLists } from '../typings/IAdList';

export function applyAdListSearch(searchFilter: string, adList: IAdList) {
    const fuzzyThreshold = 0.3;
    if (searchFilter.length < 1) {
        return adList;
    } else {
        // search ads based on the keys given
        const fuse = new Fuse(adList.ads, {
            includeScore: true,
            threshold: fuzzyThreshold,
            keys: ['title'],
        });
        const result = fuse.search(searchFilter);
        return {
            ...adList,
            ads: result.map((fuse_result) => fuse_result.item),
        };
    }
}

export function applyAdListsSearch(searchFilter: string, adLists: IAdLists) {
    const fuzzyThreshold = 0.3;
    if (searchFilter.length < 1) {
        return adLists;
    } else {
        // searchs ads based on the keys given
        const fuse = new Fuse(adLists, {
            includeScore: true,
            threshold: fuzzyThreshold,
            keys: ['title'],
        });
        const result = fuse.search(searchFilter);
        return result.map((fuse_result) => fuse_result.item);
    }
}

export const applyAdListSort = (sortFilter: string, adList: IAdList) => {
    if (sortFilter === 'sistLagtTil') return adList;
    const order = AdStatusOrder;

    return {
        ...adList,
        ads: [...adList.ads].sort((x, y) => order[x.status] - order[y.status]),
    };
};

export const applyMarketFilter = (marketFilter: string, adList: IAdList) => {
    if (marketFilter === 'Alle') return adList;
    return {
        ...adList,
        ads: adList.ads.filter((ad) => ad.marketplace === marketFilter),
    };
};

export const applyFilters = (
    searchFilter: string,
    marketFilter: string,
    sortFilter: string,
    adList: IAdList,
) => {
    if (!adList) return adList;

    adList = applyMarketFilter(marketFilter, adList);
    adList = applyAdListSearch(searchFilter, adList);
    adList = applyAdListSort(sortFilter, adList);

    return adList;
};
