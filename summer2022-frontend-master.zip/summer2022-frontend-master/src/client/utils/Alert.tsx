import React from 'react';
import { Alert as FabricAlert } from '@fabric-ds/react';

const Alert = ({
    show,
    setShow,
    type,
    children,
    className = 'fixed top-24 left-0 right-0 z-30',
    duration = 5000,
}) => {
    const myTimeout = show ? setTimeout(() => setShow(false), duration) : null;
    return show ? (
        <FabricAlert
            show={true}
            type={type}
            children={children}
            className={className}
        />
    ) : null;
};
export default Alert;
