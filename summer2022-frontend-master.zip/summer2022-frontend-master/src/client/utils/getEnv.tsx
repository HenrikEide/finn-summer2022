export default function getEnv(): Env {
    return window.location.origin === 'https://www.finn.no'
        ? Env.Prod
        : Env.Dev;
}

enum Env {
    Dev = 'https://dev.',
    Prod = 'https://',
}
