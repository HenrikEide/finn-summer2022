export default function findStatusColor(theStatus) {
    if (theStatus == 'Aktiv') {
        return 'bg-green-100';
    } else if (theStatus == 'Solgt') {
        return 'bg-yellow-100';
    } else if (theStatus == 'Frist utløpt') {
        return 'bg-bluegray-300';
    } else return 'bg-red-200';
}
