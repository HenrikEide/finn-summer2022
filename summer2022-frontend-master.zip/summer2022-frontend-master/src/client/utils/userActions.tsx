export function userCanPerformActions(accessLevel){
    return (accessLevel === 'WRITE') || (accessLevel === 'OWNER');
}
export function userIsCollaborator(accessLevel){
    return (accessLevel === 'WRITE') || (accessLevel === 'READ');
}
export function userIsListOwner(accessLevel){
    return accessLevel === 'OWNER';
}
