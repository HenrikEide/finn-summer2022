import { Box, Button, Modal, Select } from '@fabric-ds/react';
import {
    IconDots16,
    IconRatingEmpty16,
    IconRatingFull16,
    IconShare16,
} from '@fabric-ds/icons/react';
import React from 'react';

const HeadingComponent = (
    <div className="flex place-content-center items-end bg-white-100">
        <h1>Dette er Delte lister</h1>
        <img
            className="h-64 mb-20 ml-20"
            src="https://images.finncdn.no/dynamic/default/2022/7/summer2022-frontend/26/s/sum/mer/-la/unc/h-i/nfo/-he/art/s_415773337.png"
        ></img>
    </div>
);

export const LaunchInfoModal = ({ infoModal, setInfoModal }) => {
    const toggleModal = () => setInfoModal(!infoModal);

    return (
        <>
            <Modal
                open={infoModal}
                onDismiss={toggleModal}
                footer={
                    <Button primary onClick={toggleModal}>
                        Lukk
                    </Button>
                }
            >
                {HeadingComponent}
                <div className="flex flex-col gap-y-24 mt-20 pb-10 z-index">
                    <h4 className="text-center">
                        Delte lister er en ny løsning som gjør det lettere for
                        deg å dele lister og samarbeide med andre FINN brukere.
                        Vi håper at du har lyst til å prøve ut den nye løsningen
                        vår!
                    </h4>
                    <h4 className="text-center">Dette er nytt:</h4>
                    <div
                        className="flex items-center bg-aqua-50 rounded-8"
                        style={{
                            boxShadow:
                                '0px 1px 6px rgba(70, 70, 70, 0.16), 0px 1px 1px rgba(70, 70, 70, 0.24)',
                        }}
                    >
                        <Box className="flex place-items-center grid grid-cols-3">
                            <img
                                src="https://images.finncdn.no/dynamic/default/2022/7/summer2022-frontend/28/n/lau/nch/-in/fo-/sel/ect/ion_926045812.png"
                                alt="Illustrasjonsbilde av filtrering på markedsplass"
                                className="col-span-1 w-144 "
                            />
                            <p className="col-span-2 self-center">
                                Filtrer på markedsplasser for å få en enklere
                                oversikt i listene dine.
                            </p>
                        </Box>
                    </div>
                    <div
                        className="flex bg-green-50 rounded-8"
                        style={{
                            boxShadow:
                                '0px 1px 6px rgba(70, 70, 70, 0.16), 0px 1px 1px rgba(70, 70, 70, 0.24)',
                        }}
                    >
                        <Box className="flex place-items-center grid grid-cols-3 gap-4">
                            <img
                                src="https://images.finncdn.no/dynamic/default/2022/7/summer2022-frontend/28/e/lau/nch/-in/fo-/sha/re_528590801.png"
                                alt="Illustrasjonsbilde av deleknapp"
                                className="flex items-center col-span-1 w-144"
                            />
                            <p className="col-span-2">
                                Inviter andre til å samarbeide på dine lister.
                                De vil da motta en invitasjon inne på
                                “varslinger”.
                            </p>
                        </Box>
                    </div>

                    <div
                        className="flex bg-red-100 rounded-8"
                        style={{
                            boxShadow:
                                '0px 1px 6px rgba(70, 70, 70, 0.16), 0px 1px 1px rgba(70, 70, 70, 0.24)',
                        }}
                    >
                        <Box className="flex place-items-center grid grid-cols-3 gap-4 w-full">
                            <img
                                src="https://images.finncdn.no/dynamic/default/2022/7/summer2022-frontend/28/s/lau/nch/-in/fo-/dot/s_1329083037.png"
                                alt="Illustrasjonsbilde av menyknapp"
                                className="flex items-center w-48 col-span-1"
                            />
                            <p className="col-span-2">
                                Kommenter eller slett en annonse inne på listen
                                din.
                            </p>
                        </Box>
                    </div>
                    <div
                        className="flex bg-yellow-100 rounded-8"
                        style={{
                            boxShadow:
                                '0px 1px 6px rgba(70, 70, 70, 0.16), 0px 1px 1px rgba(70, 70, 70, 0.24)',
                        }}
                    >
                        <Box className="flex grid grid-cols-3 gap-4 w-full">
                            <div className="flex col-span-1 gap-16 justify-center">
                                <IconRatingEmpty16
                                    style={{
                                        color: 'var(--f-blue-600)',
                                        height: '35px',
                                        width: '35px',
                                    }}
                                />
                                <IconRatingFull16
                                    style={{
                                        color: 'var(--f-blue-600)',
                                        height: '35px',
                                        width: '35px',
                                    }}
                                />
                            </div>
                            <p className="col-span-2 self-center">
                                Fest dine favorittannonser til toppen av listen
                                din.
                            </p>
                        </Box>
                    </div>
                </div>
            </Modal>
        </>
    );
};
