import { IAdLists } from '@/client/typings/IAdList';
import React, { useState } from 'react';
import AdListPreview from './AdListPreview';

interface Props {
    adLists: IAdLists;
    toggleChange: () => void;
}
const AdLists = (props: Props) => {
    const { adLists, toggleChange } = props;
    return (
        <>
            {adLists ? (
                adLists.map((adList) => (
                    <AdListPreview
                        toggleChange={toggleChange}
                        adList={adList}
                    />
                ))
            ) : (
                <h1>Loading</h1>
            )}
        </>
    );
};

export default AdLists;
