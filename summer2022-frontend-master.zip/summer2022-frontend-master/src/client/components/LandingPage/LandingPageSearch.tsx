import { Affix, TextField } from '@fabric-ds/react';
import React from 'react';

export const LandingPageSearch = ({ searchFilter, setSearchFilter }) => (
    <TextField
        value={searchFilter}
        label="Søk etter lister"
        type="search"
        id="landingPageSearch"
        onChange={(event) => setSearchFilter(event.target.value)}
    >
        <Affix suffix search />
    </TextField>
);
