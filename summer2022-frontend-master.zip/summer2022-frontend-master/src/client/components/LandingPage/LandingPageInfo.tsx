import { Button } from '@fabric-ds/react';
import React, { useState } from 'react';
import { LaunchInfoModal } from './LaunchInfoModal';

const LandingPageInfo = () => {
    const [infoModal, setInfoModal] = useState(false);
    const toggleModal = () => setInfoModal(!infoModal);

    return (
        <div className="mt-14">
            <h1>Delte lister</h1>
            <p className="text-14">
                Delte lister er et eksperimentelt konsept utarbeidet av årets sommerstudenter i FINN.
                Målet med eksperimentet er å gjøre det lettere for deg å samarbeide med venner og
                familie om lister. Trykk på “Delte lister” på en annonse for å legge den til i en delt liste.
            </p>
            <p className="text-14">
                <Button link className="font-bold" onClick={toggleModal}>
                    Les mer om Delte lister
                </Button>
            </p>
            <LaunchInfoModal
                infoModal={infoModal}
                setInfoModal={setInfoModal}
            ></LaunchInfoModal>
        </div>
    );
};

export default LandingPageInfo;
