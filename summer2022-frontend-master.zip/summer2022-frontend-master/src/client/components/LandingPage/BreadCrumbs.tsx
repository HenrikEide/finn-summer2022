import { Breadcrumbs } from '@fabric-ds/react';
import React from 'react';
import { Link } from 'react-router-dom';

const BreadCrumbs = () => (
    <Breadcrumbs className="mt-32">
        <a href={'/min-finn'}>Min FINN</a>
        <Link to="/">Delte lister</Link>
    </Breadcrumbs>
);

export default BreadCrumbs;
