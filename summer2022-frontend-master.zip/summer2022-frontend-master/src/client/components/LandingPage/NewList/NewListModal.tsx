import React, { FormEvent, useState } from 'react';
import { Modal, TextField, Button } from '@fabric-ds/react';
import { postAdList } from '@/client/api/adListApi';
import { IPostTitleFail, IPostTitleSuccess } from '@/client/typings/IPostTitle';

export const NewListModal = ({
    openModal,
    setOpenModal,
    show,
    setShow,
    toggleChange,
}) => {
    const toggleModal = () => {
        setOpenModal(!openModal);
        setListTitle('');
        setErrorMsg('');
        toggleChange();
    };

    const [blurred, setBlurred] = useState(false);
    const [submitted, setSubmitted] = useState(false);
    const [listTitle, setListTitle] = useState('');
    const invalid = listTitle.length < 1 || listTitle.length > 50;
    const showInvalid = (blurred || submitted) && invalid;
    const [errorMsg, setErrorMsg] = useState('');
    const updateTextfield = (listTitle) => {
        setListTitle(listTitle);
    };

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();
        setSubmitted(true);
        if (invalid) return;
        postList();
    };
    const postList = async () => {
        const result: IPostTitleFail | IPostTitleSuccess = await postAdList({
            name: listTitle,
        });
        if (result.title) {
            setErrorMsg(result.title);
        } else {
            setShow(!show);
            toggleModal();
        }
    };

    return (
        <div>
            <Modal
                open={openModal}
                onDismiss={toggleModal}
                right={false}
                title="Ny liste"
            >
                <form onSubmit={handleSubmit}>
                    <TextField
                        label="Gi listen et navn"
                        helpText={`${listTitle.length}/50 tegn - Må fylles ut`}
                        invalid={showInvalid}
                        value={listTitle}
                        onBlur={() => setBlurred(true)}
                        onChange={(e) => updateTextfield(e.target.value)}
                        type="text"
                        minLength={1}
                        maxLength={50}
                    />
                    <p className="mt-24 text-red-600">{errorMsg}</p>

                    <div className="flex justify-between mt-24">
                        <Button link onClick={toggleModal}>
                            Avbryt
                        </Button>
                        <Button primary type="submit">
                            Lagre liste
                        </Button>
                    </div>
                </form>
            </Modal>
        </div>
    );
};
