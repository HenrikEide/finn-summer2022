import Alert from '@/client/utils/Alert';
import { Button } from '@fabric-ds/react';
import React, { useState } from 'react';
import { NewListModal } from './NewListModal';

interface Props {
    openModal;
    setOpenModal;
    toggleChange;
}
export const NewListContainer = (props: Props) => {
    const { openModal, setOpenModal, toggleChange } = props;
    const [show, setShow] = useState(false);
    return (
        <div className="mt-32">
            <Alert
                show={show}
                setShow={setShow}
                type="positive"
                className="fixed top-24 left-0 right-0 z-30"
            >
                <p className="text-sm">Listen ble opprettet</p>
            </Alert>
            <Button
                className="px-16"
                onClick={() => {
                    setOpenModal(!openModal);
                }}
            >
                + Lag delt liste
            </Button>
            <NewListModal
                openModal={openModal}
                setOpenModal={setOpenModal}
                toggleChange={toggleChange}
                show={show}
                setShow={setShow}
            />
        </div>
    );
};
