import { IAdLists } from '@/client/typings/IAdList';
import { Box, Expandable } from '@fabric-ds/react';
import React, { useState } from 'react';
import FavoriteLists from './FavoriteLists';

interface Props {
    adLists: IAdLists;
    toggleChange: () => void;
    defaultExpanded: boolean;
}

const FavoriteExpandableTitle = () => {
    return (
        <Box className="w-full" bordered>
            <h1>Vis mine favorittlister</h1>
        </Box>
    );
};
const FavoriteListsExpandable = (props: Props) => {
    const { adLists, toggleChange, defaultExpanded } = props;
    if (!adLists) return null;
    const [expanded, setExpanded] = useState(defaultExpanded);
    return (
        <Expandable
            className="mb-64 bg-blue-100"
            box
            title={'Del dine lister fra "Favoritter"'}
            expanded={expanded}
            onChange={(e) => setExpanded(e)}
            buttonClass="expanded-favorites"
        >
            <div>
                <p className="text-14 text-gray-500">
                    Når du deler en liste fra dine Favoritter til Delte lister
                    får du muligheten til å samarbeide med andre.
                    <br /> Endringene som skjer inne på Delte lister vil ikke ha
                    en påvirkning på listene inne på dine Favoritter.
                </p>
            </div>
            <div className="d-flex flex-column space-y-48 mt-48">
                <FavoriteLists adLists={adLists} toggleChange={toggleChange} />
            </div>
        </Expandable>
    );
};

export default FavoriteListsExpandable;
