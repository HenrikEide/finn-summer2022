import { IAdList } from '@/client/typings/IAdList';
import { Button } from '@fabric-ds/react';
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FavoriteCard } from '../AdCard/FavoriteCard/FavoriteCard';
import { IconShare16 } from '@fabric-ds/icons/react';
import { importFavoriteList } from '@/client/api/favoriteListApi';
import Alert from '@/client/utils/Alert';
import FavoriteCards from '../AdCard/FavoriteCard/FavoriteCards';

// props from parent component
interface Props {
    adList: IAdList;
    toggleChange: () => void;
}

const FavoriteListPreview = (props: Props) => {
    // Shows the last three ads in an AdList
    const { adList, toggleChange } = props;

    const [showShareAlert, setShowShareAlert] = useState(false);
    const shareAlert = () => setShowShareAlert(true);

    const shareFavoriteList = (listId) => {
        importFavoriteList({ listId: listId }).then(() => {
            shareAlert();
            toggleChange();
        });
    };

    return (
        <div className="p-16">
            <div className="flex flex-row mb-6 justify-between items-start">
                <div className="flex flex-row">
                    <a
                        className="flex items-center gap-x-8"
                        href={`/favorittliste?favListId=${adList.id}`}
                    >
                        <h3 className="text-xl font-bold text-gray-700">
                            {adList.title}{' '}
                        </h3>
                        <span className="text-gray-500 text-12">
                            ({adList?.ads.length} annonser)
                        </span>
                    </a>
                </div>

                <Button
                    className="flex p-8 gap-8 items-center"
                    link
                    onClick={() => shareFavoriteList(adList.id)}
                >
                    Del liste <IconShare16 />
                </Button>
            </div>
            <div className="space-y-32 md:space-y-0 md:grid grid-cols-3 gap-16">
                <FavoriteCards adList={adList} toggleChange={toggleChange} />
            </div>
            <Alert
                show={showShareAlert}
                setShow={setShowShareAlert}
                type="positive"
            >
                <p className="text-sm">Listen ble delt!</p>
            </Alert>
        </div>
    );
};

export default FavoriteListPreview;
