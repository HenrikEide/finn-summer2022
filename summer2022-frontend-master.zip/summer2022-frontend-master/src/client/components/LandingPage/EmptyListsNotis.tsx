import React from 'react';

interface Props {
    emptyLists: boolean;
}
const EmptyListsNotis = (props: Props) => {
    const { emptyLists } = props;
    if (!emptyLists) return null;
    else
        return (
            <div className="flex flex-col items-center mb-80">
                <img
                    className="w-1/4 object-cover"
                    src={
                        'https://images.finncdn.no/dynamic/default/2022/8/summer-fav-backend/02/5/sum/mer/-20/22-/Peo/ple/85_1563808684.png'
                    }
                    alt="People on their phone"
                />
                <p>
                    Ops! Du deler ingen lister. Del en liste fra
                    <strong>“Favoritter”</strong> eller lag en helt ny liste.
                </p>
            </div>
        );
};

export default EmptyListsNotis;
