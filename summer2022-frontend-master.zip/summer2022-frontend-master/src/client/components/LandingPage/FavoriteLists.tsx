import { IAdLists } from '@/client/typings/IAdList';
import React, { useState } from 'react';
import AdListPreview from './AdListPreview';
import FavoriteListPreview from './FavoriteListPreview';

interface Props {
    adLists: IAdLists;
    toggleChange: () => void;
}
const FavoriteLists = (props: Props) => {
    const { adLists, toggleChange } = props;
    return (
        <>
            {adLists ? (
                adLists.map((adList) => (
                    <FavoriteListPreview
                        toggleChange={toggleChange}
                        adList={adList}
                    />
                ))
            ) : (
                <h1>Loading</h1>
            )}
        </>
    );
};

export default FavoriteLists;
