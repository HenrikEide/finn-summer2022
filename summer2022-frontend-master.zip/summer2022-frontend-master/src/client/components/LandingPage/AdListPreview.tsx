import { IAdList } from '@/client/typings/IAdList';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getMemberList } from '@/client/api/memberListApi';
import { AdCard } from '../AdCard/AdCard';
import { IconEdit24 } from '@fabric-ds/icons/react';
import { Button } from '@fabric-ds/react';
import { EditListModal } from '../EditListModal/EditListModal';
import Alert from '@/client/utils/Alert';
import AdCards from '../AdCard/AdCards';
import {
    userIsListOwner,
    userIsCollaborator,
} from '@/client/utils/userActions';

// props from parent component
interface Props {
    adList: IAdList;
    toggleChange: () => void;
}

const AdListPreview = (props: Props) => {
    // Shows the last three ads in an AdList
    const { adList, toggleChange } = props;

    const [sharedWithOthers, setSharedWithOthers] = useState(false);
    const [openEditListModal, setOpenEditListModal] = useState(false);
    const [showDeleteAlert, setShowDeleteAlert] = useState(false);

    const deleteAlert = () => setShowDeleteAlert(true);

    const toggleEditListModal = () => setOpenEditListModal(!openEditListModal);

    const EditListButton = () => (
        <span className="self-start">
            <Button
                className="flex border-0 inline py-2 px-4 ml-6"
                onClick={() => toggleEditListModal()}
            >
                <IconEdit24 className="text-gray-700" />
            </Button>
        </span>
    );

    const getPreviewTitle = () => {
        let title = adList.title;
        if (sharedWithOthers) {
            return title + ' - Du deler listen';
        }
        if (userIsCollaborator(adList.accessLevel)) {
            return title + ' - Delt med deg';
        }
        return title;
    };

    useEffect(() => {
        if (userIsListOwner(adList.accessLevel)) {
            getMemberList(adList.id).then((res) =>
                setSharedWithOthers(res.listMembers?.length > 1),
            );
        }
    }, []);

    return (
        <div>
            <div className="flex flex-row mb-6 justify-between items-start">
                <div className="flex flex-row">
                    <Link to={() => `/adList/${adList.id}`}>
                        <h3 className="text-xl font-bold text-gray-700">
                            {getPreviewTitle()}
                        </h3>
                    </Link>
                    {userIsListOwner(adList.accessLevel) && <EditListButton />}
                </div>

                <Link
                    to={() => `/adList/${adList.id}`}
                    className="self-end font-medium"
                >
                    Vis alle ({adList?.ads.length} annonser)
                </Link>
            </div>
            <div className="space-y-32 md:space-y-0 md:grid grid-cols-3 gap-16">
                <AdCards adList={adList} toggleChange={toggleChange} />
            </div>
            <EditListModal
                toggleChange={toggleChange}
                adListTitle={adList.title}
                listId={adList.id}
                openModal={openEditListModal}
                setOpenModal={setOpenEditListModal}
                deleteAlert={deleteAlert}
            />
            <Alert
                show={showDeleteAlert}
                setShow={setShowDeleteAlert}
                type="positive"
            >
                <p className="text-sm">Listen ble slettet</p>
            </Alert>
        </div>
    );
};

export default AdListPreview;
