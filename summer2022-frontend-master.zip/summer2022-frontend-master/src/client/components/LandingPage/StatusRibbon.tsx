import { Button } from '@fabric-ds/react';
import React from 'react';

interface Props {
    scrollToFeedback: () => void;
}
const StatusRibbon = (props: Props) => {
    const { scrollToFeedback } = props;
    return (
        <div className="mt-6">
            <span className="text-12 bg-yellow-100 rounded py-4 px-8">
                Eksperimentet varer frem til nyttår og er kun tilgjengelig på web. For at vi skal kunne vurdere resultatet av eksperimentet,{' '}
                <Button link onClick={scrollToFeedback}>
                    husk å gi tilbakemelding!
                </Button>
            </span>
        </div>
    );
};

export default StatusRibbon;
