import React from 'react';

export const DropdownWriteOption = () => {
    return (
        <>
            <option value="WRITE" selected>
                Kan redigere
            </option>
            <option value="READ">Kan kun se</option>
        </>
    );
};
