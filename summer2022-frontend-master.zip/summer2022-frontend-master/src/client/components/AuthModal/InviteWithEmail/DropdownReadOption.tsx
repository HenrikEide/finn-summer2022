import React from 'react';

export const DropdownReadOption = () => {
    return (
        <>
            <option value="WRITE">Kan redigere</option>
            <option value="READ" selected>
                Kan kun se
            </option>
        </>
    );
};
