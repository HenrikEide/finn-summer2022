import { Button, Modal } from '@fabric-ds/react';
import { changeAccessLevel } from '@/client/api/accessLevelApi';
import React, { useState } from 'react';
import Alert from '@/client/utils/Alert';

export const KickMemberModal = ({ open, setOpen, listId, name, email }) => {
    const toggleModal = () => setOpen(!open);
    const [show, setShow] = useState(false);
    const KickBtn = (
        <Button
            negative
            className="max-w-full w-full"
            onClick={() => {
                setShow(true);
                changeAccessLevel(email, listId, 'NO_ACCESS').finally(
                    () =>
                        (window.location.href = `/delte-lister/adList/${listId}`),
                );
            }}
        >
            Ja, fjern {name}
        </Button>
    );
    const KeepBtn = (
        <Button
            onClick={toggleModal}
            className="max-w-full w-full mt-10"
            secondary
        >
            Nei, ikke enda
        </Button>
    );

    return (
        <>
            <Alert
                show={show}
                setShow={setShow}
                type="positive"
                className="fixed top-24 left-0 right-0 z-30"
            >
                <p className="text-sm">{name} er fjernet fra listen</p>
            </Alert>
            <Modal
                id="leave-list-modal"
                open={open}
                onDismiss={toggleModal}
                right
                style={{
                    //@ts-ignore
                    '--f-modal-max-height': '24rem',
                    '--f-modal-height': '100%',
                }}
                title={`Vil du fjerne ${name} fra listen?`}
                footer={
                    <div>
                        {KickBtn}
                        {KeepBtn}
                    </div>
                }
            >
                <div className="mt-10 pr-40">
                    <p>
                        Hvis du fjerner brukeren fra listen så mister de tilgang
                        til å se/redigere listen. Du kan legge brukeren til
                        igjen ved å invitere dem på ny og be dem akseptere
                        invitasjonen.
                    </p>
                </div>
            </Modal>
        </>
    );
};
