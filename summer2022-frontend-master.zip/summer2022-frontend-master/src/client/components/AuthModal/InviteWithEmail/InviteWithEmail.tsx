import { postInviteUser } from '@/client/api/accessLevelApi';
import { IMemberList } from '@/client/typings/IMember';
import Alert from '@/client/utils/Alert';
import { Button, Select, TextField } from '@fabric-ds/react';
import React, { FormEvent, useState } from 'react';
import { ListMember } from './ListMember';

export const EmailFooter = (loading) => {
    return loading.loading ? (
        <Button
            form="send-invitation-by-email-form"
            type="submit"
            className="max-w-full w-full mt-44"
            primary
            loading
        >
            Sender invitasjonen
        </Button>
    ) : (
        <Button
            form="send-invitation-by-email-form"
            type="submit"
            className="max-w-full w-full mt-44"
            primary
        >
            Send invitasjonen
        </Button>
    );
};

export const InviteWithEmail = ({
    membersList,
    listId,
    toggleAuthModal,
}: {
    membersList: IMemberList;
    listId: number;
    toggleAuthModal;
}) => {
    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();

        if (!invitation.email.length || !invitation.email.includes('@')) {
            setinvalid(true);
            return;
        }
        if (invalid) return;
        postInviteUser(invitation);
        setShow(true);

        setInvitation({
            ...invitation,
            email: '',
        });
    };

    const [show, setShow] = useState(false);
    const [invitation, setInvitation] = useState({
        listId,
        email: '',
        accessLevel: 'WRITE',
    });

    const [invalid, setinvalid] = useState(false);

    const handleChange = (e) => {
        setinvalid(!e.target.validity.valid);
        setInvitation({ ...invitation, [e.target.name]: e.target.value });
    };

    return (
        <>
            <Alert
                show={show}
                setShow={setShow}
                type="positive"
                className="fixed top-24 left-0 right-0 z-30"
            >
                <p className="text-sm">Brukeren er invitert</p>
            </Alert>
            <form
                id="send-invitation-by-email-form"
                onSubmit={handleSubmit}
                onChange={(e) => handleChange(e)}
            >
                <div className="flex flex-col justify-between">
                    <h2 className="h4 mb-16">Inviter til listen</h2>
                    <div
                        id="share-with-email-parent-div"
                        className="flex flex-row items-stretch w-full max-w-full"
                    >
                        <div style={{ flexGrow: 1 }}>
                            <TextField
                                placeholder="Epost adresse brukt til FINN konto...."
                                name="email"
                                id="share-with-email-textfield"
                                className="max-w-full w-full"
                                value={invitation.email}
                                invalid={invalid}
                                error={false}
                                helpText={invalid ? 'Fyll ut gyldig epost' : ''}
                            />
                        </div>
                        <Select name="accessLevel" id="access_level">
                            <option selected value="WRITE">
                                Kan redigere
                            </option>
                            <option value="READ">Kan kun se</option>
                        </Select>
                    </div>

                    <h2 className="h4 mt-24 mb-16">
                        Personer du deler listen med
                    </h2>
                    {membersList?.listMembers.map((member) => (
                        <ListMember
                            key={member.userId}
                            member={member}
                            listId={listId}
                            toggleAuthModal={toggleAuthModal}
                        />
                    ))}
                </div>
            </form>
        </>
    );
};
