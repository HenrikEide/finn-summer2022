import { IMember } from '@/client/typings/IMember';
import { Button, Pill } from '@fabric-ds/react';
import { IconBin16 } from '@fabric-ds/icons/react';
import React from 'react';
import { Dropdown } from './Dropdown';
import { KickMemberModal } from 'src/client/components/AuthModal/InviteWithEmail/KickMemberModal';
import {userIsCollaborator, userIsListOwner} from "@/client/utils/userActions";

interface Props {
    member: IMember;
    listId: number;
    toggleAuthModal: Function;
}
export const ListMember = (props: Props) => {
    const { image, name, email, accessLevel } = props.member;
    const listId = props.listId;
    const [openKickMemberModal, setOpenKickMemberModal] = React.useState(false);
    const toggleKickMemberModal = () =>
        setOpenKickMemberModal(!openKickMemberModal);
    return (
        <div className="flex items-center justify-between mb-16 mx-0">
            <div className="flex justify-start items-center">
                <img src={image} className="w-40 h-40 mr-16 rounded-full"></img>
                <div className="flex flex-col ml-4 self-start">
                    <strong>{name}</strong>
                    <p className="m-0 text-gray-400">{email}</p>
                </div>
            </div>
            <div className="flex justify-between">
                <Dropdown
                    accessLevel={accessLevel}
                    listId={listId}
                    email={email}
                />
                {userIsCollaborator(accessLevel) && (
                    <div className="sef-end">
                        <Button pill onClick={toggleKickMemberModal}>
                            <IconBin16 />
                        </Button>
                        <KickMemberModal
                            open={openKickMemberModal}
                            setOpen={setOpenKickMemberModal}
                            listId={listId}
                            name={name}
                            email={email}
                        ></KickMemberModal>
                    </div>
                )}
            </div>
        </div>
    );
};
