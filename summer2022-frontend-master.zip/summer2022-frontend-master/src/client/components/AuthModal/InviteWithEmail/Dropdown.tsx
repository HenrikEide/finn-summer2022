import React, { useState } from 'react';
import { Select } from '@fabric-ds/react';
import { changeAccessLevel } from '@/client/api/accessLevelApi';
import { DropdownReadOption } from './DropdownReadOption';
import { DropdownWriteOption } from './DropdownWriteOption';

const renderSelect = (accessLevel) => {
    switch (accessLevel) {
        case 'READ':
            return <DropdownReadOption />;
        case 'WRITE':
            return <DropdownWriteOption />;
    }
};

const handleChange = (setAuth, auth, listId) => (e) => {
    if (e.currentTarget) {
        const selectedAccessLevel =
            e.currentTarget.children[
                e.currentTarget.selectedIndex
            ].getAttribute('value');

        setAuth((prevState) => ({
            ...prevState,
            accessLevel: selectedAccessLevel,
        }));

        changeAccessLevel(auth.email, listId, selectedAccessLevel);
    }
};

export const Dropdown = ({ accessLevel, listId, email }) => {
    const [auth, setAuth] = useState({
        email: email,
        accessLevel: accessLevel,
    });

    return (
        <div>
            {accessLevel === 'OWNER' ? (
                <p>Eier</p>
            ) : (
                <Select
                    onChange={handleChange(setAuth, auth, listId)}
                    name="access_level"
                >
                    {renderSelect(accessLevel)}
                </Select>
            )}
        </div>
    );
};
