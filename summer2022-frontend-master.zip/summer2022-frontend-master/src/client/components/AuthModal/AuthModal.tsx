import React, { useEffect, useState } from 'react';
import { Modal, Tab, Tabs, TabPanel } from '@fabric-ds/react';
import {
    InviteWithEmail,
    EmailFooter,
} from './InviteWithEmail/InviteWithEmail';
import { InviteWithLink, LinkFooter } from './InviteWithLink/InviteWithLink';
import { IMemberList } from '@/client/typings/IMember';
import { getMemberList } from '@/client/api/memberListApi';

export const AuthModal = ({
    openModal,
    setOpenModal,
    listId,
    adListTitle,
    toggleChange,
}) => {
    const toggleModal = () => setOpenModal(!openModal);
    const [currentTab, setCurrentTab] = useState('shareWithLink');
    const [isPublic, setPublic] = useState<boolean>();
    const [loading, setLoading] = useState(false);
    const [shareUrl, setShareUrl] = useState<string>();
    const [membersList, setMembersList] = useState<IMemberList | null>(null);

    const isCurrentlyEmailTab = currentTab == 'shareWithFinnUser'; // If this is false it means that the other tab (shareWithLink) is currently selected

    useEffect(() => {
        const fetchMembersList = async () => {
            const members = await getMemberList(listId);
            setMembersList(members);
        };
        fetchMembersList();
    }, []);

    useEffect(() => {
        setPublic(membersList?.publicUrl !== null);
        if (membersList?.publicUrl) setShareUrl(membersList?.publicUrl);
    }, [membersList?.publicUrl]);

    useEffect(() => {
        toggleChange();
    }, [openModal]);

    return (
        <div>
            <Modal
                open={openModal}
                onDismiss={toggleModal}
                right
                footer={
                    isCurrentlyEmailTab ? (
                        <EmailFooter loading={loading} />
                    ) : (
                        isPublic && <LinkFooter shareUrl={shareUrl} />
                    )
                }
                className="text-center"
                title={`Del '${adListTitle}' med venner og familie`}
                style={{
                    //@ts-ignore
                    '--f-modal-max-height': '60%',
                    '--f-modal-height': '100%',
                }}
            >
                <div className="m-10 text-left">
                    <Tabs onChange={(e) => setCurrentTab(e)}>
                        <Tab
                            label="Del liste med lenke "
                            name="shareWithLink"
                            isActive
                        />
                        <Tab
                            label="Inviter FINN bruker"
                            name="shareWithFinnUser"
                        />
                    </Tabs>

                    <TabPanel name="shareWithLink">
                        <InviteWithLink
                            publicState={isPublic}
                            setPublic={setPublic}
                            listId={listId}
                            setShareUrl={setShareUrl}
                        />
                    </TabPanel>
                    <TabPanel name="shareWithFinnUser">
                        <InviteWithEmail
                            membersList={membersList}
                            listId={listId}
                            toggleAuthModal={toggleModal}
                        />
                    </TabPanel>
                    <br></br>
                </div>
            </Modal>
        </div>
    );
};
