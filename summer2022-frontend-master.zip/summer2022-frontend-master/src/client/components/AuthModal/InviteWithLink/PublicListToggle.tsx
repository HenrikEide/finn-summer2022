import { setListPublic } from '@/client/api/accessLevelApi';
import Alert from '@/client/utils/Alert';
import { Switch } from '@fabric-ds/react';
import React, { Dispatch, SetStateAction, useState } from 'react';

interface Props {
    publicState: boolean;
    setPublic: Dispatch<SetStateAction<boolean>>;
    listId: number;
    setShareUrl: Dispatch<SetStateAction<string>>;
}

export const PublicListToggle = (props: Props) => {
    const { publicState, setPublic, listId, setShareUrl } = props;
    const [show, setShow] = useState(false);
    const handleToggle = async () => {
        setPublic(!publicState);
        setShow(true);
        const data = await setListPublic({
            isPublic: !publicState,
            listId: listId,
        });
        setShareUrl(data.publicListId);
    };
    return (
        <div className="flex justify-between mt-40">
            <Alert
                show={show}
                setShow={setShow}
                type="positive"
                className="fixed top-24 left-0 right-0 z-30"
            >
                <p className="text-sm">
                    Listen er satt til {publicState ? 'offentlig' : 'privat'}
                </p>
            </Alert>
            <div>
                <h2 className="text-16">
                    Gjør listen offentlig og generer lenke
                </h2>
                <p className="w-4/5">
                    Mens denne bryteren er på kan de med lenken se listen. Om du
                    tar den av og på igjen så genereres en ny lenke, og gamle
                    lenker mister tilgang til listen.
                </p>
            </div>
            <Switch
                value={publicState}
                onClick={handleToggle}
                aria-label="Toggle list public"
            />
        </div>
    );
};
