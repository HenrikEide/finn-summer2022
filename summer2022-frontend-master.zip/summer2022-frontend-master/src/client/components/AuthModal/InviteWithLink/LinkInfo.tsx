import React from 'react';

export const LinkInfo = () => {
    return (
        <div className="mb-16">
            <h2 className="text-16">Alle med lenken kan kun se listen</h2>
            <p className="w-4/5">
                Alle som har denne lenken kan kun se listen. Ønsker du at
                brukere skal kunne redigere og kommentere listen din kan du
                invitere dem med epost.
            </p>
        </div>
    );
};
