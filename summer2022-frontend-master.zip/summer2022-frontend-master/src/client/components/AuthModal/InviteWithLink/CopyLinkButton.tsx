import Alert from '@/client/utils/Alert';
import { Button } from '@fabric-ds/react';
import React, { useState } from 'react';
import { copyToClipboard } from './DisplayLinkBox';

interface Props {
    shareUrl?: string;
}

export const CopyLinkButton = (props: Props) => {
    const [show, setShow] = useState(false);
    const handleCopy = () => {
        copyToClipboard(props.shareUrl);
        setShow(true);
    };
    return (
        <div className="flex justify-center">
            <Alert
                show={show}
                setShow={setShow}
                type="positive"
                className="fixed top-24 left-0 right-0 z-30"
            >
                <p className="text-sm">Linken ble kopiert</p>
            </Alert>
            <Button className="max-w-full w-full" primary onClick={handleCopy}>
                <div>
                    <p className="mb-0">Kopier lenke</p>
                </div>
            </Button>
        </div>
    );
};
