import React, { Dispatch, SetStateAction, useState } from 'react';
import { CopyLinkButton } from './CopyLinkButton';
import { DisplayLinkBox } from './DisplayLinkBox';
import { LinkInfo } from './LinkInfo';
import { PublicListToggle } from './PublicListToggle';

interface FooterProps {
    shareUrl?: string;
}

export const LinkFooter = (props: FooterProps) => (
    <div className="flex flex-col items-stretch w-full max-w-full">
        <DisplayLinkBox shareUrl={props.shareUrl} />
        <CopyLinkButton shareUrl={props.shareUrl} />
    </div>
);

interface InviteWithLinkProps {
    publicState: boolean;
    setPublic: Dispatch<SetStateAction<boolean>>;
    listId: number;
    setShareUrl: Dispatch<SetStateAction<string>>;
}

export const InviteWithLink = (props: InviteWithLinkProps) => (
    <>
        <LinkInfo />
        <PublicListToggle {...props} />
    </>
);
