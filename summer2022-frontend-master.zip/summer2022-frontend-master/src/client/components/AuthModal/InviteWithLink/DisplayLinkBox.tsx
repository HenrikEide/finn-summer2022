import { Box, Clickable } from '@fabric-ds/react';
import React from 'react';

export const copyToClipboard = (shareUrl?: string) => {
    navigator.clipboard.writeText(shareUrl);
};

interface Props {
    shareUrl?: string;
}

export const DisplayLinkBox = (props: Props) => {
    return (
        <div className="mb-40">
            <p className="font-bold text-left">Kopier lenke</p>
            <Box bordered clickable>
                <Clickable
                    onClick={() => copyToClipboard(props.shareUrl)}
                    className="font-bold text-gray-700 hover:no-underline"
                >
                    <p
                        className="text-blue-600 font-normal m-0 whitespace-nowrap overflow-hidden overflow-ellipsis"
                        style={{ width: '450px' }}
                    >
                        {props.shareUrl}
                    </p>
                </Clickable>
            </Box>
        </div>
    );
};
