import React, { FormEvent, useState } from 'react';
import { Modal, Expandable, Button, TextField } from '@fabric-ds/react';

import { deleteAdList, putChangeListName } from '@/client/api/adListApi';
import { DeleteListTitle, EditNameTitle } from './EditListExpandableTitles';
import Alert from '@/client/utils/Alert';

export const EditListModal = ({
    toggleChange,
    openModal,
    setOpenModal,
    adListTitle,
    listId,
    deleteAlert,
}) => {
    const handleDelete = (listId) => {
        deleteAdList(listId).then(() => {
            deleteAlert();
            toggleModal();
            toggleChange();
        });
    };

    const [blurred, setBlurred] = useState(false)
    const [submitted, setSubmitted] = useState(false)
    const [listTitle, setListTitle] = useState('');
    const [openEdit, setOpenEdit] = useState(false);
    const [openDelete, setOpenDelete] = useState(false);
    const [showAlert, setShowAlert] = useState(false);
    const [newNameForm, setNewNameForm] = useState({
        listId,
        newName: '',
    });

    const toggleModal = () => setOpenModal(!openModal);

    const updateTextfield = (listTitle) => {
        setListTitle(listTitle);
    };

    const handleSubmitNewName = (e: FormEvent) => {
        e.preventDefault();
        setSubmitted(true)
        if (invalid) return;
        putChangeListName(newNameForm).then(() => {
            toggleModal();
            toggleChange();
        });
        setShowAlert(true);
    };

    const handleChange = (e) => {
        setNewNameForm({ ...newNameForm, newName: e.target.value });
    };

    const invalid = listTitle.length < 1 || listTitle.length > 50;
    const showInvalid = (blurred || submitted) && invalid

    return (
        <div>
            <Modal
                open={openModal}
                onDismiss={toggleModal}
                right
                className=""
                title={`Rediger listen '${adListTitle}'`}
                children={
                    <>
                        <Expandable
                            buttonClass="edit-list-expandable"
                            className="m-12"
                            expanded={openEdit}
                            onChange={setOpenEdit}
                            title={<EditNameTitle />}
                            info
                            box
                            animated
                        >
                            <form
                                onChange={(e) => handleChange(e)}
                                onSubmit={handleSubmitNewName}
                            >
                                <div className="flex flex-col justify-between">
                                    <h2 className="h5 mb-8">
                                        Gi listen et navn
                                    </h2>
                                    <div
                                        id="change-name-parent-div"
                                        className="flex flex-row items-stretch w-full max-w-full"
                                    >
                                        <TextField
                                            placeholder={adListTitle}
                                            id="change-name-textfield"
                                            name="new-list-name"
                                            invalid={showInvalid}
                                            onBlur={() => setBlurred(true)}
                                            className="max-w-full w-full"
                                            type="text"
                                            onChange={(e) =>
                                                updateTextfield(e.target.value)
                                            }
                                            autoFocus
                                            helpText={`${listTitle.length}/50 tegn - Må fylles ut`}
                                            value={listTitle}
                                        />
                                        <Button
                                            className="h-48 ml-10"
                                            type="submit"
                                            primary
                                        >
                                            Lagre
                                        </Button>
                                    </div>
                                </div>
                            </form>
                        </Expandable>
                        <Expandable
                            className="m-12"
                            buttonClass="edit-list-expandable"
                            expanded={openDelete}
                            onChange={setOpenDelete}
                            animated
                            title={<DeleteListTitle />}
                            info
                            box
                        >
                            <h2 className="h4">
                                Ønsker du å slette hele listen?
                            </h2>
                            <p>
                                Alle annonsene og kommentarene du har lagret i
                                denne listen vil da bli borte, og du kan ikke
                                angre valget ditt.
                            </p>
                            <Button
                                className="mt-10 max-w-full w-full"
                                negative
                                type="submit"
                                onClick={() => handleDelete(listId)}
                            >
                                Ja, slett listen
                            </Button>
                        </Expandable>
                    </>
                }
            ></Modal>
            <Alert show={showAlert} setShow={setShowAlert} type="positive">
                <p className="text-sm">
                    Navnet på listen har blitt endret til <b>{listTitle}</b>
                </p>
            </Alert>
        </div>
    );
};
