import React from 'react';
import { IconBin24, IconEdit24 } from '@fabric-ds/icons/react';

export const DeleteListTitle = () => (
    <div className="flex flex-row">
        <IconBin24 />
        <p className="ml-12 mb-0">Slett listen</p>
    </div>
);

export const EditNameTitle = () => (
    <div className="flex flex-row">
        <IconEdit24 />
        <p className="ml-12 mb-0">Endre navn på listen</p>
    </div>
);
