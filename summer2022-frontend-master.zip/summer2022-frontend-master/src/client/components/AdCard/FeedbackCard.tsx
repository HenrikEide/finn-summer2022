import { postFeedback } from '@/client/api/feedbackApi';
import { Button, TextArea } from '@fabric-ds/react';
import React, { FormEvent, useState } from 'react';

import Smiley from './Smiley';

// 1 = 'sad', 2 = 'neutral', 3 = 'good', 4 = 'happy'
export type Rating = 1 | 2 | 3 | 4;

interface Props {
    rating: number;
    setSubmitted: (submitted: boolean) => void;
}

const Form = (props: Props) => {
    const [comment, setComment] = useState('');

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();
        sendFeedback(props.rating, comment);
        props.setSubmitted(true);
    };

    const sendFeedback = async (rating: number, comment: string) => {
        const res = await postFeedback(rating, comment);
    };

    return (
        <form
            id="send-feedback-form"
            className="flex flex-col place-items-center"
            onSubmit={handleSubmit}
        >
            <TextArea
                label="Har du noen tilbakemeldinger til oss? (valgfritt)"
                value={comment}
                onChange={(e) => setComment(e.target.value)}
            />
            <p className="text-12 mb-12 mt-8">
                Vi bruker din tilbakemelding til å forbedre sidene våre.
            </p>
            <Button secondary className="mb-12" type="submit">
                Send inn
            </Button>
        </form>
    );
};

interface FeedbackCardProps {
    classNames: string;
}

export const FeedbackCard = (props: FeedbackCardProps) => {
    const { classNames = '' } = props;
    const [rating, setRating] = useState<Rating>();
    const onClick = (rating: Rating) => setRating(rating);

    const [submitted, setSubmitted] = useState(false);

    return (
        <div
            className={`flex flex-col place-items-center bg-green-100 rounded-8 ${classNames}`}
        >
            <img
                className="h-80 mt-24 mb-20"
                src="https://images.finncdn.no/dynamic/default/2022/7/summer2022-frontend/27/k/sum/mer/-fe/edb/ack_1751963728.png"
            />
            <h3>Hjelp oss å bli bedre!</h3>
            <h5>Hva synes du om Delte lister?</h5>
            {submitted ? (
                <p className="mt-10 mb-12">
                    {'Takk for din tilbakemelding :)'}
                </p>
            ) : (
                <>
                    <div className="flex flex-row gap-10 mt-10 mb-12">
                        <Smiley
                            smiley={1}
                            onClick={onClick}
                            active={rating === 1}
                        />
                        <Smiley
                            smiley={2}
                            onClick={onClick}
                            active={rating === 2}
                        />
                        <Smiley
                            smiley={3}
                            onClick={onClick}
                            active={rating === 3}
                        />
                        <Smiley
                            smiley={4}
                            onClick={onClick}
                            active={rating === 4}
                        />
                    </div>
                    {rating && (
                        <Form rating={rating} setSubmitted={setSubmitted} />
                    )}
                </>
            )}
        </div>
    );
};
