import {Button} from '@fabric-ds/react';
import {IconRatingEmpty16, IconRatingFull16} from '@fabric-ds/icons/react';
import React from 'react';
import {togglePinned} from '@/client/api/adListApi';

export const PinnedStar = ({ ad, listId, toggleChange}) => {
    const togglePin = () =>
        togglePinned({"listId": listId, "adId": ad.id}).then(() => toggleChange())

    const label = ad.pinned?"Trykk for å fjerne pin av annonsen til toppen av lista":"Trykk for å pinne annonsen til toppen av lista"
    const title = ad.pinned?"Fjern pin av annonsen til toppen av lista":"Pin annonsen til toppen av lista"

    return <Button onClick={togglePin} pill className="absolute top-0 right-0 z-10" aria-label={label} title={title}>
        {ad.pinned?
            <IconRatingFull16 className="absolute w-24 h-24 text-blue-600" /> :
            <IconRatingFull16 className="absolute w-24 h-24 text-gray-500" />}
        <IconRatingEmpty16 className="absolute w-24 h-24 text-white" />
    </Button>
};

export default PinnedStar;
