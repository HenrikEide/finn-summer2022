import findStatusColor from '@/client/utils/findStatusColor';
import React, { useEffect, useState } from 'react';
import AdModal from './AdModal/AdModal';
import AdImage from './AdImage';
import OpenModalBtn from './AdModal/OpenModalBtn';
import AdPartialContent from './AdPartialContent';
import { ICommentList } from '@/client/typings/IComment';
import { getAndUpdateComments, getComments } from '@/client/api/commentApi';
import PinnedStar from '@/client/components/AdCard/PinnedStar';
import { Card } from '@fabric-ds/react';
import { userCanPerformActions } from '@/client/utils/userActions';

export const AdCard = ({ ad, adList, toggleChange, shouldShowActions }) => {
    const [openModal, setOpenModal] = useState(false);
    const [commentList, setCommentList] = useState<ICommentList>();

    const toggleModal = () => setOpenModal(!openModal);

    const retrieveComments = async (listId, adId) => {
        const data = openModal
            ? await getAndUpdateComments({ listId, adId })
            : await getComments({ listId, adId });
        setCommentList(data);
    };

    useEffect(() => {
        if (userCanPerformActions(adList.accessLevel)) {
            retrieveComments(adList.id, ad.id);
        }
    }, [openModal]);

    const shouldHaveShadow = ad.info.length !== 0;

    return (
        <>
            <Card className="bg-white item-card">
                <div
                    className="h-full grid"
                    style={{
                        gridTemplateRows: 'auto 1fr auto',
                        gridTemplateColumns: '1fr',
                        gridTemplateAreas: `'header' 'main' 'footer'`,
                    }}
                >
                    <div style={{ gridArea: 'header' }}>
                        <div aria-owns={ad.title}></div>
                        <div className="relative">
                            <AdImage
                                adImage={ad.image}
                                shouldHaveShadow={shouldHaveShadow}
                            />
                        </div>
                        <p className="absolute left-8 text-white text-16 top-112">
                            {ad.info}
                        </p>

                        {shouldShowActions && (
                            <PinnedStar
                                ad={ad}
                                listId={adList.id}
                                toggleChange={toggleChange}
                                key={`${adList.id}-${ad.id}`}
                            />
                        )}
                    </div>
                    <div
                        className="p-12 flex flex-col justify-between"
                        style={{ gridArea: 'main' }}
                    >
                        <div>
                            <AdPartialContent ad={ad} />
                        </div>
                        <div
                            style={{ gridArea: 'footer' }}
                            className="flex justify-between"
                        >
                            <p
                                className={
                                    'inline-block mt-12 text-grey-700 text-12 rounded-4 px-8 py-4 ' +
                                    findStatusColor(ad.status)
                                }
                            >
                                {ad.status}
                            </p>
                            {shouldShowActions && (
                                <OpenModalBtn
                                    unreadComments={commentList?.unreadComments}
                                    toggleModal={toggleModal}
                                />
                            )}
                        </div>
                    </div>
                    <AdModal
                        openModal={openModal}
                        setOpenModal={setOpenModal}
                        ad={ad}
                        adList={adList}
                        commentList={commentList}
                        retrieveComments={retrieveComments}
                        toggleChange={toggleChange}
                        showDeleteTab={userCanPerformActions(
                            adList.accessLevel,
                        )}
                    />
                </div>
            </Card>
        </>
    );
};
