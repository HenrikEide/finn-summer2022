import React from 'react';
import {
    IconSmileySad32,
    IconSmileyNeutral32,
    IconSmileyGood32,
    IconSmileyHappy32,
} from '@fabric-ds/icons/react';
import { Button } from '@fabric-ds/react';
import { Rating } from './FeedbackCard';

interface Props {
    smiley: Rating;
    active: boolean;
    onClick: (mood: number) => void;
}

const Smiley = (props: Props) => {
    const { smiley, active, onClick } = props;

    const handleClick = () => {
        if (active) onClick(undefined);
        else onClick(smiley);
    };

    const color = active ? 'var(--f-blue-600)' : undefined;

    const style = {
        color: color,
        height: '45px',
        width: '45px',
    };

    const getSmiley = () => {
        switch (props.smiley) {
            case 1:
                return <IconSmileySad32 style={style} />;
            case 2:
                return <IconSmileyNeutral32 style={style} />;
            case 3:
                return <IconSmileyGood32 style={style} />;
            case 4:
                return <IconSmileyHappy32 style={style} />;
            default:
                'No value found';
        }
    };

    return (
        <Button pill onClick={handleClick}>
            {getSmiley()}
        </Button>
    );
};

export default Smiley;
