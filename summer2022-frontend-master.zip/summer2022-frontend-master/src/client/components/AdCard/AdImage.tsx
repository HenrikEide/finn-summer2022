import React from 'react';

interface Props {
    adImage;
    shouldHaveShadow;
}
const AdImage = (props: Props) => {
    const { adImage, shouldHaveShadow } = props;

    const shadow = () => {
        if (shouldHaveShadow) {
            return {
                background:
                    'linear-gradient(180deg, rgba(255, 255, 255, 0) 0%, #474445 100%)',
            };
        }
    };

    return (
        <>
            <div
                className="absolute inset-x-0 bottom-0 h-44"
                style={{
                    ...shadow(),
                }}
            ></div>
            <img
                className="h-144 w-full object-cover"
                src={`${adImage}`}
                alt="bilde av annonse"
            />
        </>
    );
};

export default AdImage;
