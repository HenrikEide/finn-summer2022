import { ADS_TO_SHOW } from '@/client/typings/Constants';
import { IAdList } from '@/client/typings/IAdList';
import React from 'react';
import { AdCard } from './AdCard';
import EmptyCard from './EmptyCard';

interface Props {
    adList: IAdList;
    toggleChange: () => void;
}
const AdCards = (props: Props) => {
    const { adList, toggleChange } = props;

    if (adList.ads?.length === 0) {
        return <EmptyCard href={`/delte-lister/adList/${adList.id}`} />;
    }
    return (
        <>
            {adList.ads?.slice(0, ADS_TO_SHOW).map((ad) => (
                <AdCard
                    key={ad.id}
                    ad={ad}
                    adList={adList}
                    toggleChange={toggleChange}
                    shouldShowActions={false}
                />
            ))}
        </>
    );
};

export default AdCards;
