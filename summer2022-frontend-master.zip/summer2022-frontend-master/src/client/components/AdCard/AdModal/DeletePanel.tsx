import { Button } from '@fabric-ds/react';
import React, { useEffect, useState } from 'react';
import { deleteAdFromList } from '@/client/api/adListApi';
import Alert from '@/client/utils/Alert';
import DeleteAlert from './DeleteAlert';

interface Props {
    listTitle: string;
    adId: number;
    listId: number;
    toggleChange;
    toggleModal;
    toggleDeleted;
}

const DeletePanel = (props: Props) => {
    const {
        listTitle,
        adId,
        listId,
        toggleChange,
        toggleModal,
        toggleDeleted,
    } = props;

    const deleteAdWithSideEffects = () => {
        toggleDeleted();
        deleteAdFromList(listId, adId).then((res) => {
            toggleModal();
            toggleChange();
        });
    };

    return (
        <div className="p-14 flex flex-col items-center">
            <h3 className="mb-32">Slett annonse fra {listTitle}</h3>
            <img
                src="https://images.finncdn.no/dynamic/default/2022/7/summer-fav-backend/21/x/sum/mer/-20/22-/thi/ngb/ox_2082681472.png"
                alt="ThingBox"
                width={160}
            />
            <Button
                onClick={() => deleteAdWithSideEffects()}
                className="mt-32"
                negative
            >
                Ja, slett annonsen
            </Button>
        </div>
    );
};

export default DeletePanel;
