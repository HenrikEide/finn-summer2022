import { Tab, Tabs } from '@fabric-ds/react';
import React from 'react';

export const TitleComponent = ({
    selectedTab,
    setSelectedTab,
    showDeleteTab,
}) => {
    return (
        <Tabs active={selectedTab} onChange={(e) => setSelectedTab(e)}>
            <Tab label="Skriv kommentar " name="comment" />
            {showDeleteTab ? (
                <Tab label="Slett annonse" name="delete" />
            ) : (
                <></>
            )}
        </Tabs>
    );
};
