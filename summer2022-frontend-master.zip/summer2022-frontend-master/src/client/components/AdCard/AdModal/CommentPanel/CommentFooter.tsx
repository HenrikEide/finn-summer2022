import { Button, TextField } from '@fabric-ds/react';
import React, { useRef } from 'react';
import { FormEvent, useState } from 'react';
import { IconSend24 } from '@fabric-ds/icons/react';

interface Props {
    adId: number;
    listId: number;
    postComment: ({ listId, adId, text }) => void;
    retrieveComments: (listId, adId) => void;
}
export const CommentFooter = (props: Props) => {
    const { adId, listId, postComment, retrieveComments } = props;
    const [text, setText] = useState('');
    const [submitted, setSubmitted] = useState(false);
    const invalid = text.length < 1;
    const showInvalid = submitted && invalid;
    const errorMsg = showInvalid ? 'Du kan ikke skrive en tom kommentar' : null;

    const bottomRef = useRef(null);

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();
        setSubmitted(true);
        if (invalid) return;
        sendComment(text);
        setSubmitted(false);
        bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    const sendComment = async (text: string) => {
        setText('');
        const res = await postComment({
            listId,
            adId,
            text: text,
        });
        retrieveComments(listId, adId);
    };

    return (
        <form
            className="w-full"
            id="send-comment-form"
            onSubmit={handleSubmit}
            ref={bottomRef}
        >
            <TextField
                className="relative"
                aria-label="kommentarfelt"
                placeholder="Skriv inn kommentar..."
                invalid={showInvalid}
                value={text}
                onChange={(e) => setText(e.target.value)}
            >
                <Button
                    pill
                    type="submit"
                    className="absolute top-0 bottom-0 right-0"
                >
                    <IconSend24 />
                </Button>
            </TextField>
            <p className="text-red-600">{errorMsg}</p>
        </form>
    );
};
