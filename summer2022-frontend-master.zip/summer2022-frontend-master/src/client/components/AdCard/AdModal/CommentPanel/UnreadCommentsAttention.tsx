import React from 'react';

const UnreadCommentsAttention = ({ unreadComments }) => {
    return unreadComments > 0 ? (
        <span
            className="absolute text-xs"
            style={{
                background: '#D91F0A',
                fontSize: '12px',
                color: '#ffffff',
                lineHeight: '12px',
                borderRadius: '200px',
                width: '16px',
                height: '16px',
                textAlign: 'center',
                padding: '2px',
                top: '-6px',
                right: '-6px',
            }}
        >
            {unreadComments}
        </span>
    ) : null;
};

export default UnreadCommentsAttention;
