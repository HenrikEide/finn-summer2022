import { ICommentList } from '@/client/typings/IComment';
import React, { useEffect, useRef } from 'react';
import Comment from './Comment';

interface Props {
    commentList: ICommentList;
}
const CommentList = (props: Props) => {
    const bottomRef = useRef(null);
    const { commentList } = props;

    const getBottomRef = (index, orgArray) => {
        if (index === orgArray.length - 1) {
            return bottomRef;
        }
    };
    useEffect(() => {
        bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [commentList]);

    return (
        <>
            <h3>{`Kommentarer (${
                commentList ? commentList.comments.length : 0
            })`}</h3>
            {commentList?.comments.map((c, index, orgArray) => {
                const arrayLength = orgArray.length - 1;
                return (
                    <Comment
                        ref={getBottomRef(index, orgArray)}
                        key={c.commentId}
                        comment={c}
                        isSender={c.userId === commentList.userId}
                    />
                );
            })}
        </>
    );
};

export default CommentList;
