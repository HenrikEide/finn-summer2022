import { getComments, postComment } from '@/client/api/commentApi';
import { IComment, ICommentList } from '@/client/typings/IComment';
import { Affix, Button, TextField } from '@fabric-ds/react';
import React, { FormEvent, useEffect, useState } from 'react';
import CommentList from './CommentList';
import { IconSend24 } from '@fabric-ds/icons/react';

interface Props {
    listId: number;
    adId: number;
    commentList: ICommentList;
    retrieveComments: (listId: number, adId: number) => void;
}
const CommentPanel = (props: Props) => {
    const { listId, adId, commentList, retrieveComments } = props;

    return (
        <div>
            <CommentList commentList={commentList} />
        </div>
    );
};

export default CommentPanel;
