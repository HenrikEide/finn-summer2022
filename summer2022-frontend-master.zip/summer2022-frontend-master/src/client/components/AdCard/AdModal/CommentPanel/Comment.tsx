import { IComment } from '@/client/typings/IComment';
import { Box, TextArea } from '@fabric-ds/react';
import React from 'react';
import moment from 'moment';

interface Props {
    comment: IComment;
    isSender: boolean;
}

const Comment = (props: Props, ref) => {
    const { comment, isSender } = props;
    const {
        commentId,
        userId,
        email,
        name,
        image,
        listId,
        adId,
        text,
        updated,
    } = comment;
    const dateToShow = moment(Date.parse(updated)).format('DD.MM HH:mm');
    const sender = isSender ? 'flex justify-end' : 'flex';

    return (
        <div ref={ref}>
            <p className="w-full text-center my-16 text-gray-500">
                {dateToShow}
            </p>
            <div className={sender}>
                <div
                    className="relative p-16 mt-16 break-words bg-aqua-50 max-w-3/4 rounded-8"
                    style={{ width: 'fit-content' }}
                >
                    <img
                        src={image}
                        className="rounder-full mr-8"
                        width={34}
                        height={35}
                        alt="profilbilde"
                    ></img>
                    <div>
                        <p>{text}</p>

                        <span>{email}</span>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default React.forwardRef(Comment);
