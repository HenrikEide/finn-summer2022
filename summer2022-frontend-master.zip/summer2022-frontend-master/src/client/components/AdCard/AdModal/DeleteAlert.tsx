import Alert from '@/client/utils/Alert';
import { Button } from '@fabric-ds/react';
import React from 'react';

interface Props {
    show;
    setShow;
    listTitle;
}
const DeleteAlert = (props: Props) => {
    const { show, setShow, listTitle } = props;
    return (
        <Alert
            show={show}
            setShow={setShow}
            type="positive"
            className="fixed top-24 left-0 right-0 z-30"
        >
            <p className="text-sm">
                Annonse fjernet fra <b>{listTitle}</b>
            </p>
        </Alert>
    );
};

export default DeleteAlert;
