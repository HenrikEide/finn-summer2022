import React, { FormEvent, useEffect, useState } from 'react';
import { Modal, TabPanel } from '@fabric-ds/react';
import DeletePanel from './DeletePanel';
import { IAd, IAdList } from '@/client/typings/IAdList';
import DeleteAlert from './DeleteAlert';
import CommentPanel from './CommentPanel/CommentPanel';
import { ICommentList } from '@/client/typings/IComment';
import { postComment } from '@/client/api/commentApi';
import { CommentFooter } from './CommentPanel/CommentFooter';
import { TitleComponent } from './TitleComponent';

const DeleteFooter = () => {
    return <></>;
};

const AdModal = ({
    openModal,
    setOpenModal,
    ad,
    adList,
    commentList,
    retrieveComments,
    toggleChange,
    showDeleteTab,
}: {
    openModal: boolean;
    setOpenModal: (openModal: boolean) => void;
    ad: IAd;
    adList: IAdList;
    commentList: ICommentList;
    retrieveComments: (listId: number, adId: number) => void;
    toggleChange: () => void;
    showDeleteTab: boolean;
}) => {
    const toggleModal = () => {
        setOpenModal(!openModal);
    };

    const [deleted, setDeleted] = useState(false);
    const [selectedTab, setSelectedTab] = useState('comment');

    const toggleDeleted = () => {
        setDeleted(true);
    };

    return (
        <>
            <Modal
                className="z-20"
                open={openModal}
                aria-label={`Handlinger for "${ad.title}"`}
                onDismiss={toggleModal}
                right
                footer={
                    selectedTab === 'comment' ? (
                        <CommentFooter
                            adId={ad.id}
                            listId={adList.id}
                            postComment={postComment}
                            retrieveComments={retrieveComments}
                        />
                    ) : (
                        <DeleteFooter />
                    )
                }
                title={
                    <TitleComponent
                        selectedTab={selectedTab}
                        setSelectedTab={setSelectedTab}
                        showDeleteTab={showDeleteTab}
                    />
                }
                style={{
                    //@ts-ignore
                    '--f-modal-max-height': '60%',
                    '--f-modal-height': '100%',
                }}
            >
                <TabPanel name="comment">
                    <CommentPanel
                        commentList={commentList}
                        retrieveComments={retrieveComments}
                        adId={ad.id}
                        listId={adList.id}
                    />
                </TabPanel>
                {showDeleteTab ? (
                    <TabPanel name="delete">
                        <DeletePanel
                            listTitle={adList.title}
                            adId={ad.id}
                            listId={adList.id}
                            toggleChange={toggleChange}
                            toggleModal={toggleModal}
                            toggleDeleted={toggleDeleted}
                        />
                    </TabPanel>
                ) : (
                    <></>
                )}
            </Modal>
            <DeleteAlert
                show={deleted}
                setShow={setDeleted}
                listTitle={adList.title}
            />
        </>
    );
};

export default AdModal;
