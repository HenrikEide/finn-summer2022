import { Button } from '@fabric-ds/react';
import React from 'react';
import { IconDots16 } from '@fabric-ds/icons/react';
import UnreadCommentsAttention from './CommentPanel/UnreadCommentsAttention';

const OpenModalBtn = ({ toggleModal, unreadComments }) => {
    return (
        <Button
            className="z-0 relative"
            style={{
                color: 'inherit',
                background: '#FFFFFF',
                boxShadow:
                    '0px 1px 6px rgba(70, 70, 70, 0.16), 0px 1px 1px rgba(70, 70, 70, 0.24)',
                borderRadius: '8px',
            }}
            onClick={() => toggleModal()}
            secondary
        >
            <UnreadCommentsAttention unreadComments={unreadComments} />
            <IconDots16 />
        </Button>
    );
};

export default OpenModalBtn;
