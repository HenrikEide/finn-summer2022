import { IAd } from '@/client/typings/IAdList';
import getEnv from '@/client/utils/getEnv';
import { Clickable } from '@fabric-ds/react';
import React from 'react';

interface Props {
    ad: IAd;
}
const AdPartialContent = (props: Props) => {
    const { ad } = props;
    const baseHref = getEnv() + 'finn.no/';
    return (
        <>
            <p
                className="font-bold my-0"
                style={{
                    height: '44px',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'initial',
                    display: '-webkit-box',
                    WebkitLineClamp: '2',
                    WebkitBoxOrient: 'vertical',
                }}
                id={ad.title}
            >
                <Clickable
                    href={ad.id > 0 ? `${baseHref}${ad.id}` : ''}
                    target=""
                    title={ad.title}
                    className="text-current hover:no-underline focus:no-underline"
                >
                    {ad.title}
                </Clickable>
            </p>

            <p className="absolute gray-700 right-8 text-12">{ad.extraInfo}</p>

            <p className="text-14 gray-700 mb-0">{ad.subtitle}</p>
            <p className="text-14 gray-700 mb-0">{ad.location}</p>
        </>
    );
};

export default AdPartialContent;
