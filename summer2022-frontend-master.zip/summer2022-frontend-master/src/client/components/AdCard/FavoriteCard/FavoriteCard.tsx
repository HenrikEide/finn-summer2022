import findStatusColor from '@/client/utils/findStatusColor';
import React, { useEffect, useState } from 'react';
import AdImage from '../AdImage';
import AdPartialContent from '../AdPartialContent';
import { ICommentList } from '@/client/typings/IComment';
import { getAndUpdateComments, getComments } from '@/client/api/commentApi';
import PinnedStar from '@/client/components/AdCard/PinnedStar';
import { Card } from '@fabric-ds/react';

export const FavoriteCard = ({ ad, adList, toggleChange }) => {
    const shouldHaveShadow = ad.info.length !== 0;

    return (
        <>
            <Card className="bg-white item-card">
                <div
                    className="h-full grid"
                    style={{
                        gridTemplateRows: 'auto 1fr auto',
                        gridTemplateColumns: '1fr',
                        gridTemplateAreas: `'header' 'main' 'footer'`,
                    }}
                >
                    <div style={{ gridArea: 'header' }}>
                        <div aria-owns={ad.title}></div>
                        <div className="relative">
                            <AdImage
                                adImage={ad.image}
                                shouldHaveShadow={shouldHaveShadow}
                            />
                        </div>
                        <p className="absolute left-8 text-white text-16 top-112">
                            {ad.info}
                        </p>
                    </div>
                    <div
                        className="p-12 flex flex-col justify-between"
                        style={{ gridArea: 'main' }}
                    >
                        <div>
                            <AdPartialContent ad={ad} />
                        </div>
                        <div
                            style={{ gridArea: 'footer' }}
                            className="flex justify-between"
                        >
                            <p
                                className={
                                    'inline-block mt-12 text-grey-700 text-12 rounded-4 px-8 py-4 ' +
                                    findStatusColor(ad.status)
                                }
                            >
                                {ad.status}
                            </p>
                        </div>
                    </div>
                </div>
            </Card>
        </>
    );
};
