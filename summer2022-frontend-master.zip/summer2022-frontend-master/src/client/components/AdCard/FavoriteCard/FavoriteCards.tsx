import { ADS_TO_SHOW } from '@/client/typings/Constants';
import { IAdList } from '@/client/typings/IAdList';
import React from 'react';
import EmptyCard from '../EmptyCard';
import { FavoriteCard } from './FavoriteCard';

interface Props {
    adList: IAdList;
    toggleChange: () => void;
}
const FavoriteCards = (props: Props) => {
    const { adList, toggleChange } = props;
    if (adList.ads?.length === 0) {
        return <EmptyCard href={`/favorittliste?favListId=${adList.id}`} />;
    } else
        return (
            <>
                {adList.ads
                    ?.filter((_, index) => index < ADS_TO_SHOW)
                    .map((ad) => (
                        <FavoriteCard
                            key={ad.id}
                            ad={ad}
                            adList={adList}
                            toggleChange={toggleChange}
                        />
                    ))}
            </>
        );
};

export default FavoriteCards;
