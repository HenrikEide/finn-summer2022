import { Card, Clickable } from '@fabric-ds/react';
import React from 'react';

const EmptyCard = ({ href }) => {
    return (
        <Card className="bg-white item-card flex">
            <Clickable
                href={href}
                target=""
                title={'Empty list'}
                className="text-current hover:no-underline focus:no-underline"
            >
                {''}
            </Clickable>
            <img
                className="h-1/3 w-1/3 rounded-8 object-cover m-auto"
                src={
                    'https://images.finncdn.no/dynamic/default/2022/8/summer-fav-backend/01/t/sum/mer/-20/22-/emp/tyl/ist_624065744.png'
                }
                alt="mangler bilde til annonse"
            />
        </Card>
    );
};

export default EmptyCard;
{
    /*src={`${'https://static.finncdn.no/_c/mfinn/static/images/no-image.5bf83e47.svg'}`}*/
}
