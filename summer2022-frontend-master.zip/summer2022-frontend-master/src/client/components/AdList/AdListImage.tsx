import React from 'react';
import {userIsListOwner} from "@/client/utils/userActions";

export const AdListImage = ({ adList }) => {
    const ad = adList ? adList?.ads[adList.ads.length - 1] : null;

    const imgUrl = ad?.image ? ad.image : null;

    if(!imgUrl) return null;

    const title = adList?.title;
    const shared = userIsListOwner(adList.accessLevel) ? null : `(${adList.listOwner} deler listen med deg)`;

    return (
        <div className="relative mb-16">
            <div
                className="absolute inset-x-0 bottom-0 h-56"
                style={{
                    background:
                        'linear-gradient(180deg, rgba(255, 255, 255, 0) 0%, #474445 100%)',
                    borderRadius: '0px 0px 8px 8px',
                }}
            ></div>
            <img
                style={{ height: '273px' }}
                className="w-full object-cover mb-6"
                src={imgUrl}
                alt="Description"
            />
            <div className="absolute left-8 text-white flex bottom-8 items-end">
                <h1 className="mb-0 mr-4 text-34">{title}</h1>
                <caption className="mb-4 text-14">{shared}</caption>
            </div>
        </div>
    );
};
