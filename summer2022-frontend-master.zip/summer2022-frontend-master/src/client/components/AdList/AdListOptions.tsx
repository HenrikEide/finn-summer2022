import React, { useState } from 'react';
import { Button } from '@fabric-ds/react';
import { IAdList } from 'src/client/typings/IAdList';
import { IconShare16, IconEdit16 } from '@fabric-ds/icons/react';
import { LeaveModal } from 'src/client/components/AdList/LeaveAdListModal';
import {
    userIsListOwner,
    userIsCollaborator,
} from '@/client/utils/userActions';
import { AuthModal } from '../AuthModal/AuthModal';

interface Props {
    adList: IAdList;
    toggleChange: () => void;
}

export const AdListOptions = (props: Props) => {
    const { adList, toggleChange } = props;
    if (!adList) return null;
    const [openAuthModal, setOpenAuthModal] = useState(false);
    const [openLeaveModal, setOpenLeaveModal] = useState(false);

    const toggleLeaveModal = () => setOpenLeaveModal(!openLeaveModal);
    const toggleAuthModal = () => setOpenAuthModal(!openAuthModal);

    if (userIsListOwner(adList.accessLevel))
        return (
            <div className="flex items-end relative justify-end mr-4">
                <Button
                    onClick={() => toggleAuthModal()}
                    primary
                    className="flex"
                >
                    <p className="mb-0 mr-8">Del liste</p>
                    <IconShare16 className="mt-4" />
                </Button>
                <AuthModal
                    adListTitle={adList.title}
                    listId={adList.id}
                    openModal={openAuthModal}
                    setOpenModal={setOpenAuthModal}
                    toggleChange={toggleChange}
                />
            </div>
        );
    if (userIsCollaborator(adList.accessLevel))
        return (
            <div className="flex items-end relative justify-end mr-4">
                <Button
                    onClick={toggleLeaveModal}
                    link
                    className="flex text-red-600"
                >
                    <p className="mb-0 mr-8">Forlat liste</p>
                </Button>
                <LeaveModal
                    open={openLeaveModal}
                    setOpen={setOpenLeaveModal}
                    adList={adList}
                />
            </div>
        );
    return <></>;
};
