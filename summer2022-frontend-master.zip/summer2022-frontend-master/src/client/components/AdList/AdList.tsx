import React from 'react';
import { IAdList } from '@/client/typings/IAdList';
import { AdCard } from '../AdCard/AdCard';
import { FeedbackCard } from '../AdCard/FeedbackCard';
import { userCanPerformActions } from '@/client/utils/userActions';

interface Props {
    adList: IAdList;
    toggleChange: () => void;
}
export const AdList = (props: Props) => {
    const { adList, toggleChange } = props;
    return (
        <div className="space-y-32 md:space-y-0 md:grid grid-cols-3 gap-16 mb-40">
            <FeedbackCard classNames="" />
            {adList.ads.map((ad) => {
                return (
                    <AdCard
                        ad={ad}
                        adList={adList}
                        toggleChange={toggleChange}
                        shouldShowActions={userCanPerformActions(
                            adList.accessLevel,
                        )}
                    />
                );
            })}
        </div>
    );
};
