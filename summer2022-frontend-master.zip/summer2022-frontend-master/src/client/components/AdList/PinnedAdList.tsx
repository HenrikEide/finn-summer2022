import React, { useState } from 'react';
import { IAdList } from '@/client/typings/IAdList';
import { AdCard } from '../AdCard/AdCard';
import { Button } from '@fabric-ds/react';
import { IconRatingFull16 } from '@fabric-ds/icons/react';
import spliceIntoChunks from '@/client/utils/spliceIntoChunks';
import {userCanPerformActions} from "@/client/utils/userActions";

interface Props {
    adList: IAdList;
    toggleChange: () => void;
}
export const PinnedAdList = (props: Props) => {
    const { adList, toggleChange } = props;
    if (!adList) return <div></div>;

    const header = (
        <div className="flex px-10 pt-14">
            <h3>Toppvalg i {adList.title}</h3>
            <IconRatingFull16 className="text-blue-600 mt-8 ml-4" />
        </div>
    );

    const bodyClass = 'bg-aqua-50 rounded-8 mb-32 mt-32 px-12';

    const showActions = userCanPerformActions(adList.accessLevel);

    if (!adList.ads.length)
        return (
            <div className={bodyClass}>
                {header}
                {showActions ? (
                    <p className="px-10 pb-14">
                        For å feste dine “Favoritter” til toppen trykker du på
                        den lille stjernen som finnes i høyre hjørne på hver
                        annonse.
                    </p>
                ) : null}
            </div>
        );

    const [currentPage, setCurrentPage] = useState(0);

    const adPages = spliceIntoChunks(
        adList.ads.map((ad) => (
            <AdCard
                ad={ad}
                adList={adList}
                toggleChange={toggleChange}
                shouldShowActions={userCanPerformActions(adList.accessLevel)}
            />
        )),
        3,
    );
    const pageCount = adPages.length;

    const goToPage = (pageId) => () =>
        setCurrentPage((pageId + pageCount) % pageCount);

    const pageButtons = Array.from({ length: pageCount }, (x, i) =>
        i == currentPage ? (
            <Button
                className="bg-gray-700 text-white"
                pill
                onClick={goToPage(i)}
            >
                {i + 1}
            </Button>
        ) : (
            <Button className="text-blue-600" pill onClick={goToPage(i)}>
                {i + 1}
            </Button>
        ),
    );

    const prevButton = (
        <Button pill onClick={goToPage(currentPage - 1)}>
            {currentPage == 0 ? '<<' : '<'}
        </Button>
    );
    const nextButton = (
        <Button pill onClick={goToPage(currentPage + 1)}>
            {currentPage == pageCount - 1 ? '>>' : '>'}
        </Button>
    );

    const calculateCurrentPages = (index) => {
        if (index < 1) return pageButtons.slice(0, 3);
        else if (index > pageCount - 2) return pageButtons.slice(-3);
        else return pageButtons.slice(index - 1, index + 2);
    };

    return (
        <div className={bodyClass}>
            {header}
            <div className="space-y-32 md:space-y-0 md:grid grid-cols-3 gap-16">
                {adPages[currentPage]}
            </div>
            <div className="flex justify-center p-8">
                {[
                    prevButton,
                    ...calculateCurrentPages(currentPage),
                    nextButton,
                ]}
            </div>
        </div>
    );
};
