import { Button, Modal } from '@fabric-ds/react';
import { changeAccessLevel } from '@/client/api/accessLevelApi';
import React, { useEffect, useState } from 'react';
import Alert from '@/client/utils/Alert';

export const LeaveModal = ({ open, setOpen, adList }) => {
    const toggleModal = () => setOpen(!open);
    const [show, setShow] = useState(false);
    const LeaveBtn = (
        <Button
            negative
            className="max-w-full w-full"
            onClick={() => {
                setShow(true);
                changeAccessLevel('leave', adList.id, 'NO_ACCESS').finally(
                    () => (window.location.href = '/delte-lister'),
                );
            }}
        >
            Ja, jeg vil forlate listen
        </Button>
    );
    const StayBtn = (
        <Button
            onClick={toggleModal}
            className="max-w-full w-full mt-10"
            secondary
        >
            Nei, jeg vil beholde listen
        </Button>
    );

    return (
        <>
            <Alert
                show={show}
                setShow={setShow}
                type="positive"
                className="fixed top-24 left-0 right-0 z-30"
            >
                <p className="text-sm">Du har forlatt listen</p>
            </Alert>
            <Modal
                id="leave-list-modal"
                open={open}
                onDismiss={toggleModal}
                right
                title={`Er du sikker på at du vil forlate '${adList?.title}'?`}
                footer={
                    <div>
                        {LeaveBtn}
                        {StayBtn}
                    </div>
                }
            >
                <div className="mt-10 pb-40 pr-40">
                    <p>
                        Hvis du forlater listen, har du ikke mulighet til å
                        finne tilbake til annonsene i listen. Du kan ikke angre
                        denne handlingen.
                    </p>
                </div>
            </Modal>
        </>
    );
};
