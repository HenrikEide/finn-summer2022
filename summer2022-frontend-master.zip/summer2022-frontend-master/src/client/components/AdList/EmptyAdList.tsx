import React from 'react';

export const EmptyAdList = () => {
    return (
        <div className="grid justify-items-center p-56">
            <h3>Finner du noe du liker?</h3>
            <p>
                Trykk på Delte lister knappen for å legge til annonsen i listen
                din!
            </p>
            <img
                src="https://images.finncdn.no/dynamic/default/2022/8/summer-fav-backend/02/1/sum/mer/-20/22-/Peo/ple/31_1730817763.png"
                alt="Illustrajon av dame som gir tommel opp"
                className="mt-20"
            />
        </div>
    );
};
