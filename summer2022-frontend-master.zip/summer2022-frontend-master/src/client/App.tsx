import React from 'react';
import LandingPage from './pages/LandingPage';

import { Route, Switch, BrowserRouter } from 'react-router-dom';
import AdListPage from './pages/AdListPage';
import AcceptInvPage from './pages/AcceptInvPage';

const App = () => {
    return (
        <BrowserRouter basename="/delte-lister">
            <Switch>
                <Route path="/acceptingInvite/:listId">
                    <AcceptInvPage />
                </Route>
                <Route path="/adList/:listId">
                    <AdListPage />
                </Route>
                <Route path="/">
                    <LandingPage></LandingPage>
                </Route>
            </Switch>
        </BrowserRouter>
    );
};

export default App;
