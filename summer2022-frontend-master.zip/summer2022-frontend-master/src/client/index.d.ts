declare module '@fabric-ds/icons/react';
