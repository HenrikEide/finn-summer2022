export interface IAdList {
    id: number;
    title: string;
    ads: Array<IAd>;
    isOwner: boolean;
    accessLevel: string;
    listOwner: string;
}

export interface IAd {
    id: number;
    title: string;
    description: string;
    subtitle: string;
    info: string;
    location: string;
    image: string;
    extraInfo: String;
    status: string;
    marketplace: string;
    pinned: boolean;
}

export interface IAdLists extends Array<IAdList> {}

export enum AdStatusOrder {
    'Aktiv',
    'Inaktiv',
    'Skjult',
    'Slettet',
}
