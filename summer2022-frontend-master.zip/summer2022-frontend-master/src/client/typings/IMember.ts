export interface IMemberList {
    listMembers: Array<IMember>;
    publicUrl: string | null;
}

export interface IMember {
    userId: number;
    name: string;
    email: string;
    accessLevel: string;
    image: string;
}
