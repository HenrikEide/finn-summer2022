export interface IComment {
    commentId: number;
    userId: number;
    email: string;
    name: string;
    image: string;
    listId: number;
    adId: number;
    text: string;
    updated: string;
}

export interface ICommentList {
    userId: number;
    unreadComments: number;
    comments: IComment[];
}
