export interface IPostTitleFail {
    'custom-details': null;
    title: string;
    type: 'duplicate';
}

export interface IPostTitleSuccess {
    folderid: number;
    title: undefined;
}
