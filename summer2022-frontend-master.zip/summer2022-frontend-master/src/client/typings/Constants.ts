export const ADS_TO_SHOW = 3;
