import prometheus from 'prom-client';
import serveStatic from 'serve-static';
import Layout from '@podium/layout';
import ExpressLayout from '@finn-no/express-layout';
import fiaasLogger from '@finn-no/fiaas-logger';
import Eik from '@eik/node-client';
import bodyParser from 'body-parser';
import config from './config/index.js';
import adListClient from './clients/adListClient.js';
import commentClient from './clients/commentClient.js';
import favoriteListClient from './clients/favoriteListClient.js';

const rootPath = '/delte-lister';

async function createServer({
    name = config.get('name'),
    port = config.get('port'),
    development = config.get('development'),
    logger = fiaasLogger,
    metrics = config.get('metrics'),
    shutdownGracePeriod = config.get('shutdownGracePeriod'),
    devToolPort,
} = {}) {
    const layout = new Layout({
        name,
        pathname: rootPath,
        development,
        logger,
    });

    const headerPodlet = layout.client.register({
        name: 'header',
        uri: config.get('podlets').header,
    });

    const footerPodlet = layout.client.register({
        name: 'footer',
        uri: config.get('podlets').footer,
    });

    const server = new ExpressLayout(layout, {
        port,
        metrics,
        prometheus,
        devToolPort,
        grace: shutdownGracePeriod,
        eik: true,
        troika: false,
        fabric: true,
    });
    const { app } = server;

    app.use(bodyParser.urlencoded({ extended: true }));
    app.use(bodyParser.json());
    const adListApiClient = adListClient(logger);
    const commentApiClient = commentClient(logger);
    const favoriteListApiClient = favoriteListClient(logger);

    const eik = new Eik({ development, base: '/static' });
    await eik.load();

    if (development) app.use('/static', serveStatic('./dist/'));

    layout.css(eik.file('/styles.css'));
    layout.js({ ...eik.file('/index.js'), type: 'module' });

    const handlePage = async (req, res) => {
        const incoming = res.locals.podium;
        const podlets = await Promise.all([
            headerPodlet.fetch(incoming),
            footerPodlet.fetch(incoming),
        ]);
        const [header, footer] = podlets;

        incoming.podlets = podlets;

        incoming.view = {
            title: 'Delte lister | FINN.no',
            trackJs: config.useTrackJs,
            applicationName: config.name,
        };

        res.podiumSend(`
            ${header}
            <main id="root" class="page-container">
            </main>
            ${footer}
        `);
    };

    app.get(
        `${layout.pathname()}/api/favorite-lists/`,
        favoriteListApiClient.getFavoriteLists,
    );

    app.post(
        `${layout.pathname()}/api/export-as-shared-list`,
        favoriteListApiClient.postFavoriteList,
    );

    app.delete(
        `${layout.pathname()}/api/deleteAdFromList/:listId/:adId`,
        adListApiClient.deleteAdFromList,
    );

    app.post(
        `${layout.pathname()}/api/change-access-level`,
        adListApiClient.postAccessChange,
    );

    app.post(
        `${layout.pathname()}/api/toggle-list-public`,
        adListApiClient.postTogglePublic,
    );

    app.post(
        `${layout.pathname()}/api/invite-user`,
        adListApiClient.postAccessRequest,
    );

    app.delete(
        `${layout.pathname()}/api/list/:listId`,
        adListApiClient.deleteAdList,
    );

    app.get(`${layout.pathname()}/api/comments/`, commentApiClient.getComments);
    app.get(
        `${layout.pathname()}/api/updateComments/`,
        commentApiClient.getAndUpdateComments,
    );

    app.post(
        `${layout.pathname()}/api/comments/`,
        commentApiClient.postComment,
    );

    app.post(`${layout.pathname()}/api/list`, adListApiClient.postAdList);
    app.get(`${layout.pathname()}/api/lists`, adListApiClient.getAdLists);
    app.get(`${layout.pathname()}/api/list/:listId`, adListApiClient.getAdList);

    app.get(
        `${layout.pathname()}/api/list-members/:listId`,
        adListApiClient.getMembersList,
    );

    app.get(
        [
            layout.pathname(),
            `${layout.pathname()}/adList`,
            `${layout.pathname()}/adList/:listId`,
            `${layout.pathname()}/acceptingInvite/:listId`,
        ],
        handlePage,
    );

    app.post(
        `${layout.pathname()}/api/accept-invitation`,
        adListApiClient.postInviteAccepted,
    );

    app.post(`${layout.pathname()}/api/feedback`, adListApiClient.postFeedback);

    app.put(
        `${layout.pathname()}/api/list/change-name`,
        adListApiClient.putChangeListName,
    );

    app.patch(`${layout.pathname()}/api/pin`, adListApiClient.togglePinned);

    return server;
}

export default createServer;
