import axios from 'axios';
import config from '../config/index.js';
import { apiErrorMessage } from './common.js';

const apiBase = config.get('sharedFavApi');

const axiosInstance = axios.create({
    baseURL: apiBase,
    timeout: 4000,
});

const postCommentRequest = (logger) => async (req, res) => {
    const finntoken = res.locals.finnToken;
    const headers = {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${finntoken}`,
    };
    const promise = axiosInstance.post(
        '/api/commentsOnAdInList',
        JSON.stringify(req.body),
        {
            headers,
        },
    );

    try {
        const response = await promise;
        const result = response.data;
        if (response.status === 200) {
            res.send(result);
            return;
        }
        logger.warn(apiErrorMessage(response, result));
        res.sendStatus(response.status);
    } catch (err) {
        logger.warn(`Backend API request failed, ${err}`);
        res.sendStatus(500);
    }
};

const getCommentsRequest = (logger) => async (req, res) => {
    const { query } = req;

    const finntoken = res.locals.finnToken;
    const headers = {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${finntoken}`,
    };
    const promise = axiosInstance.get(
        `/api/commentsOnAdInList/${query.listId}/${query.adId}`,
        {
            headers,
        },
    );
    try {
        const response = await promise;
        const result = response.data;
        if (response.status === 200) {
            res.send(result);
            return;
        }
        logger.warn(apiErrorMessage(response, result));
        res.sendStatus(response.status);
    } catch (err) {
        logger.warn(`Backend API request failed, ${err}`);
        res.sendStatus(500);
    }
};

const getAndUpdateCommentsRequest = (logger) => async (req, res) => {
    const { query } = req;
    const finntoken = res.locals.finnToken;
    const headers = {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${finntoken}`,
    };
    const promise = axiosInstance.get(
        `/api/updateCommentsOnAdInList/${query.listId}/${query.adId}`,
        {
            headers,
        },
    );
    try {
        const response = await promise;
        const result = response.data;
        if (response.status === 200) {
            res.send(result);
            return;
        }
        logger.warn(apiErrorMessage(response, result));
        res.sendStatus(response.status);
    } catch (err) {
        logger.warn(`Backend API request failed, ${err}`);
        res.sendStatus(500);
    }
};

const commentClient = (logger) => ({
    getComments: getCommentsRequest(logger),
    postComment: postCommentRequest(logger),
    getAndUpdateComments: getAndUpdateCommentsRequest(logger),
});

export default commentClient;
