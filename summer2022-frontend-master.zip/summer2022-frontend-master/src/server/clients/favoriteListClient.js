import axios from 'axios';
import config from '../config/index.js';
import {
    initiatePromiseHandlerWithResult,
    initiatePromiseHandlerWithStatus,
    apiErrorMessage,
} from './common.js';

const apiBase = config.get('sharedFavApi');

const axiosInstance = axios.create({
    baseURL: apiBase,
    timeout: 4000,
});

const postFavoriteList = (logger) => async (req, res) => {
    const finntoken = res.locals.finnToken;
    const headers = {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${finntoken}`,
    };
    const promise = axiosInstance.post(
        'api/export-as-shared-list',
        JSON.stringify(req.body),
        {
            headers,
        },
    );

    try {
        const response = await promise;
        const result = response.data;
        if (response.status === 200) {
            res.send(result);
            return;
        }
        logger.warn(apiErrorMessage(response, result));
        res.sendStatus(response.status);
    } catch (err) {
        logger.warn(`Backend API request failed, ${err}`);
        res.sendStatus(500);
    }
};

const getFavoriteLists = (logger) => async (req, res) => {
    const finntoken = res.locals.finnToken;
    const headers = {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${finntoken}`,
    };

    const promise = axiosInstance.get('api/favorite-lists', {
        headers,
    });

    try {
        const response = await promise;
        const result = response.data;
        if (response.status === 200) {
            res.send(result);
            return;
        }
        logger.warn(apiErrorMessage(response, result));
        res.sendStatus(response.status);
    } catch (err) {
        logger.warn(`Backend API request failed, ${err}`);
        res.send(500);
    }
};

const favoriteListClient = (logger) => ({
    getFavoriteLists: getFavoriteLists(logger),
    postFavoriteList: postFavoriteList(logger),
});

export default favoriteListClient;
