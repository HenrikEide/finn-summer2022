import axios from 'axios';
import config from '../config/index.js';
import {
    initiatePromiseHandlerWithResult,
    initiatePromiseHandlerWithStatus,
    apiErrorMessage,
} from './common.js';

const apiBase = config.get('sharedFavApi');

const axiosInstance = axios.create({
    baseURL: apiBase,
    timeout: 4000,
});

const postAdList = (logger) => async (req, res) => {
    const finntoken = res.locals.finnToken;
    const headers = {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${finntoken}`,
    };

    const promise = axiosInstance.post('api/list', JSON.stringify(req.body), {
        headers,
    });

    try {
        const response = await promise;
        const result = response.data;
        if (response.status === 200) {
            res.send(result);
            return;
        }
        logger.warn(apiErrorMessage(response, result));
        res.sendStatus(response.status);
    } catch (err) {
        logger.warn(`Backend API request failed, ${err}`);
        res.send(err.response.data);
    }
};

const getAdLists = (promiseHandler) => async (req, res) => {
    const finntoken = res.locals.finnToken;
    const headers = {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${finntoken}`,
    };

    const promise = axiosInstance.get(`api/lists`, {
        headers,
    });

    await promiseHandler({ promise, res });
};

const getAdList = (promiseHandler) => async (req, res) => {
    const {
        params: { listId },
    } = req;
    const finntoken = res.locals.finnToken;
    const headers = {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${finntoken}`,
    };
    const promise = axiosInstance.get(`api/list/${listId}`, {
        headers,
    });

    await promiseHandler({ promise, res });
};

const postAccessChange = (logger) => async (req, res) => {
    const finntoken = res.locals.finnToken;
    const headers = {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${finntoken}`,
    };
    axiosInstance
        .post('api/change-access-level', req.body, {
            headers,
        })
        .catch((err) => logger.warn(`Backend API request failed, ${err}`));
};

const postAccessRequest = (promiseHandler) => async (req, res) => {
    const finntoken = res.locals.finnToken;
    const headers = {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${finntoken}`,
    };

    const promise = axiosInstance.post(
        'api/invite-user',
        JSON.stringify(req.body),
        {
            headers,
        },
    );
    await promiseHandler({ promise, res });
};

const postInviteAccepted = (promiseHandler) => async (req, res) => {
    const finntoken = res.locals.finnToken;
    const headers = {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${finntoken}`,
    };
    const promise = axiosInstance.post(
        'api/accept-invitation',
        JSON.stringify(req.body),
        {
            headers,
        },
    );
    await promiseHandler({ promise, res });
};

const deleteAdList = (promiseHandler) => async (req, res) => {
    const finntoken = res.locals.finnToken;
    const {
        params: { listId },
    } = req;
    const headers = {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${finntoken}`,
    };

    const promise = axiosInstance.delete(`api/list/${listId}`, {
        headers,
    });
    await promiseHandler({ promise, res });
};

const getMembersList = (promiseHandler) => async (req, res) => {
    const {
        params: { listId },
    } = req;

    const finntoken = res.locals.finnToken;

    const headers = {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${finntoken}`,
    };

    const promise = axiosInstance.get(`api/list-members/${listId}`, {
        headers,
    });
    await promiseHandler({ promise, res });
};
const deleteAdFromList = (logger) => async (req, res) => {
    const {
        params: { listId, adId },
    } = req;

    const finntoken = res.locals.finnToken;
    const headers = {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${finntoken}`,
    };

    const promise = axiosInstance.delete(
        `api/deleteAdFromList/${listId}/${adId}`,
        {
            headers,
        },
    );

    try {
        const response = await promise;
        const result = response.data;
        if (response.status === 200) {
            res.send(result);
            return;
        }
        logger.warn(apiErrorMessage(response, result));
        res.sendStatus(response.status);
    } catch (err) {
        logger.warn(`Backend API request failed, ${err}`);
        res.sendStatus(500);
    }
};

const putChangeListName = (promiseHandler) => async (req, res) => {
    const finntoken = res.locals.finnToken;
    const headers = {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${finntoken}`,
    };
    const promise = axiosInstance.put(
        'api/list/change-name',
        JSON.stringify(req.body),
        {
            headers,
        },
    );
    await promiseHandler({ promise, res });
};

const patchAdListPin = (promiseHandler) => async (req, res) => {
    const finntoken = res.locals.finnToken;
    const headers = {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${finntoken}`,
    };
    const promise = axiosInstance.patch('api/pin', JSON.stringify(req.body), {
        headers,
    });
    await promiseHandler({ promise, res });
};

const postFeedback = (promiseHandler) => async (req, res) => {
    const finntoken = res.locals.finnToken;
    const headers = {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${finntoken}`,
    };

    const promise = axiosInstance.post(
        'api/feedback',
        JSON.stringify(req.body),
        {
            headers,
        },
    );
    await promiseHandler({ promise, res });
};

const postTogglePublic = (logger) => (req, res) => {
    const finntoken = res.locals.finnToken;
    const headers = {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${finntoken}`,
    };

    axiosInstance
        .post('api/public', JSON.stringify(req.body), {
            headers,
        })
        .then((response) => {
            res.status(200).send(response.data);
        })
        .catch((error) =>
            logger.warn(
                `Failed to change public state: ${JSON.stringify(error)}`,
            ),
        );
};

const adListClient = (logger) => {
    const handlePromiseWithStatus = initiatePromiseHandlerWithStatus(logger);
    const handlePromiseWithResult = initiatePromiseHandlerWithResult(logger);

    const getAdListsRequest = getAdLists(handlePromiseWithResult);
    const getAdListRequest = getAdList(handlePromiseWithResult);
    const getMembersListRequest = getMembersList(handlePromiseWithResult);
    const deleteAdListRequest = deleteAdList(handlePromiseWithStatus);
    return {
        getAdLists: getAdListsRequest,
        postAdList: postAdList(logger),
        getAdList: getAdListRequest,
        postAccessRequest: postAccessRequest(handlePromiseWithStatus),
        postAccessChange: postAccessChange(logger),
        getMembersList: getMembersListRequest,
        deleteAdFromList: deleteAdFromList(logger),
        postInviteAccepted: postInviteAccepted(handlePromiseWithStatus),
        putChangeListName: putChangeListName(handlePromiseWithStatus),
        togglePinned: patchAdListPin(handlePromiseWithStatus),
        deleteAdList: deleteAdListRequest,
        postFeedback: postFeedback(handlePromiseWithStatus),
        postTogglePublic: postTogglePublic(logger),
    };
};

export default adListClient;
