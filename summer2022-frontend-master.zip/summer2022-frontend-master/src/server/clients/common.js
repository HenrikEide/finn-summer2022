export const apiErrorMessage = (response, error) => {
    const defaultMessage = `Backend API request failed, service ${response.url} responded with status code ${response.statusCode}`;
    const subError = error
        ? `, and subErrorCode ${error.subErrorCode} with message "${error.reason}"`
        : '';
    return defaultMessage + subError;
};

/* Takes a logger and returns a function, which takes a promise and a response
 *  The returned function handles logging if the response errors or if
 *  the AJAX call crashes. It sends the response, if the response is ok or not
 */
export const initiatePromiseHandlerWithStatus =
    (logger) =>
    async ({ promise, res }) => {
        try {
            const response = await promise;
            if (!response.status === 200) {
                logger.info(JSON.stringify(response));
                const error = response.data;
                logger.warn(apiErrorMessage(response, error));
            }
            res.sendStatus(response.status);
        } catch (err) {
            logger.warn(`Backend API request failed, ${err}`);
            res.sendStatus(500);
        }
    };

/* Takes a logger and returns a function, which takes a promise and a response
 *  The returned function handles logging if the response errors or if
 *  the AJAX call crashes. If the response is ok, it sends the json of the
 *  response, or else it returns the status of the failed response.
 */

export const initiatePromiseHandlerWithResult =
    (logger) =>
    async ({ promise, res }) => {
        try {
            const response = await promise;
            const result = response.data;

            if (response.status === 200) {
                res.send(result);
                return;
            }

            logger.warn(apiErrorMessage(response, result));
            res.sendStatus(response.status);
        } catch (err) {
            logger.warn(`Backend API request failed, ${err}`);
            res.sendStatus(500);
        }
    };
