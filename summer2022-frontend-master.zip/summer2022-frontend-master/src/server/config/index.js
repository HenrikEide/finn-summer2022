import { dirname, join } from 'path';
import { fileURLToPath } from 'url';
import { readFileSync } from 'fs';
import convict from 'convict';
import convictFormatWithValidator from 'convict-format-with-validator';

const dir = dirname(fileURLToPath(import.meta.url));
const pack = JSON.parse(readFileSync(join(dir, '../../../package.json')));

convict.addFormats(convictFormatWithValidator);

const config = convict({
    name: {
        doc: 'Name of the application',
        default: pack.name,
        format: String,
    },
    env: {
        doc: 'Application environments',
        default: 'local',
        format: ['local', 'dev', 'prod'],
        env: 'FIAAS_ENVIRONMENT',
        arg: 'env',
    },
    shutdownGracePeriod: {
        doc: 'Grace period to allow connections to finish before shutdown',
        default: 5000,
        format: 'nat',
    },
    metrics: {
        default: true,
        format: Boolean,
    },
    port: {
        format: 'port',
        default: 8080,
        env: 'PORT',
        arg: 'port',
    },
    useTrackJs: {
        default: false,
        format: Boolean,
    },
    podlets: {
        header: { format: 'url', default: 'http://header/manifest.json' },
        footer: { format: 'url', default: 'http://footer/manifest.json' },
    },
    sharedFavApi: {
        doc: 'Api endpoint for shared favorites',
        format: 'url',
        default: 'http://summer-fav-backend/',
    },
    logLevel: {
        format: ['TRACE', 'DEBUG', 'INFO', 'WARN', 'ERROR', 'FATAL'],
        default: 'INFO',
        env: 'LOG_LEVEL',
        arg: 'log-level',
    },
    development: {
        default: false,
        format: Boolean,
    },
});

const env = config.get('env');
config.loadFile(`${dir}/config.${env}.json`);
config.validate();

export default config;
