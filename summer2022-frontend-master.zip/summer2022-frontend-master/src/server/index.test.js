import { test } from 'tap';
import request from 'supertest';
import server from './server.js';

test('server is healthy', async () => {
    const { app } = await server({
        logger: null,
        development: false,
        metrics: false,
        grace: 0,
    });
    await request(app).get('/_/health').expect(204);
});

test('server is ready', async () => {
    const { app } = await server({
        logger: null,
        development: false,
        metrics: false,
        grace: 0,
    });
    await request(app).get('/_/ready').expect(204);
});
