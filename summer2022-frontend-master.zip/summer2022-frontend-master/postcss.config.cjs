/* eslint-disable import/no-extraneous-dependencies */
const importMapPlugin = require('@eik/postcss-plugin');
const importPlugin = require('postcss-import');
const cssnano = require('cssnano');

module.exports = () => ({
    plugins: [
        importMapPlugin(),
        importPlugin({
            // Ensure import mapping is done on CSS imported by other CSS
            plugins: [importMapPlugin],
            // Workaround webpack style css imports
            resolve: id => id.replace(/^~/, ''),
        }),
        cssnano({ preset: 'default' }),
    ],
});
