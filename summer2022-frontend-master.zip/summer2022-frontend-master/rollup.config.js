import { nodeResolve } from '@rollup/plugin-node-resolve';
import { terser } from 'rollup-plugin-terser';
import commonjs from '@rollup/plugin-commonjs';
import eik from '@eik/rollup-plugin';
import babel from '@rollup/plugin-babel';
import typescript from '@rollup/plugin-typescript';
import json from '@rollup/plugin-json';
import replace from '@rollup/plugin-replace';

export default {
    input: './src/client/index.tsx',
    plugins: [
        eik(),
        json(),
        nodeResolve({
            browser: true,
            extensions: ['.js', '.jsx', '.ts', '.tsx'],
        }),
        commonjs({ include: /node_modules/ }),
        terser({ format: { comments: false } }),
        babel({
            babelHelpers: 'runtime',
            exclude: 'node_modules/**',
        }),
        replace({
            'process.env.NODE_ENV': JSON.stringify('production'),
            preventAssignment: true,
        }),
        typescript(),
    ],
    output: [{ sourcemap: true, format: 'esm', file: 'dist/index.js' }],
};
