# That frontend app

We ready for prod

# Setup
- Clone project -> `npm install`
### MacOS:
- From root `cd /etc`
    - Open file "hosts"
    - Add new line `127.0.0.1       local.finn.no`
- Back in project folder:
- `npm run dev` or `npm start`
