
/**
 * This layout is set up with semantic release to make sure Travis will publish to Eik
 * and update the version automatically for every new commit on the main branch.
 *
 * Docs here: https://gist.github.schibsted.io/richard-walker/2b0cc1027aa6b503b0a5e740739bbcf7#file-guide-md
 */

 module.exports = {
    plugins: [
        '@eik/semantic-release',
        ['@semantic-release/git', { assets: ['eik.json'] }],
    ],
    branches: ['master'],
};