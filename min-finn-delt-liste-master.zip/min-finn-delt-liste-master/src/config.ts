import logger from "@finn-no/fiaas-logger";
import convict from "convict";
import convictFormatWithValidator from "convict-format-with-validator";

convict.addFormats(convictFormatWithValidator);

const conf = convict({
  env: {
    doc: "Application environments",
    format: ["local", "dev", "prod"],
    default: "local",
    env: "FIAAS_ENVIRONMENT",
    arg: "env",
  },
  logLevel: {
    format: ["TRACE", "DEBUG", "INFO", "WARN", "ERROR", "FATAL"],
    default: "INFO",
    env: "LOG_LEVEL",
    arg: "log-level",
  },
  development: {
    doc: "whether or not the module should run in development mode",
    default: false,
    env: "DEVELOPMENT",
    format: Boolean,
  },
  shutdownGracePeriod: {
    doc: "Grace period to allow connections to finish before shutdown",
    default: 5000,
    format: "nat",
  },
  port: {
    doc: "Port number for the http endpoints",
    default: 3000,
    format: "port",
  },
  api: {
    jobService: {
      baseUrl: {
        format: "url",
        default: "http://api-job/job",
      },
      timeout: {
        format: "nat",
        default: 1000,
      },
    },
  },
  loginTokenCookieName: {
    format: String,
    default: "__flt_dev",
  },
  unleashUrl: {
    format: "url",
    default: "http://unleash/api",
  },
});

const env = conf.get("env");
conf.loadFile(`${__dirname}/../config/config.${env}.json`);
conf.validate();
logger.info(`Read config for environment ${env}, config is ${conf.toString()}`);

export type Config = {
  env: string;
  logLevel: string;
  development: boolean;
  shutdownGracePeriod: number;
  port: number;
  api: {
    jobService: {
      baseUrl: string;
      timeout: number;
    };
  };
  loginTokenCookieName: string;
  unleashUrl: string;
};

export default function readConfig(): Config {
  return conf.getProperties() as Config;
}
