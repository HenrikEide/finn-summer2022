import createServer from './app';
import config from './config';
import logger from '@finn-no/fiaas-logger';

createServer(config()).then((server) =>
    server.start().then(() => logger.info('Server started!')),
);
