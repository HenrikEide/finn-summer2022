import Podlet from "@podium/podlet";
import ExpressPodlet from "@finn-no/express-podlet";
import express from "express";
import logger from "@finn-no/fiaas-logger";
import prometheus from "prom-client";
import { Config } from "./config";
import { Request, Response } from "express";
import { Context, initialize as initializeUnleash } from "unleash-client";
import { authenticatePodlet } from "@finn-no/login-middleware";
import Eik from "@eik/node-client";
import content from "./content";
import jwt from "jwt-simple";

const getUserId = (finnToken: string) => {
  if (finnToken) {
    const { loginId } = jwt.decode(finnToken, "", true);
    return String(loginId);
  }
  return undefined;
};
const getUnleashContext = (res: Response, req: Request): Context => ({
  sessionId: String(req.query.sessionId),
  userId: getUserId(res.locals.podium.context.finnToken),
});

export default async function createServer(
  config: Config
): Promise<ExpressPodlet> {
  logger.setLogLevel(config.logLevel);

  const unleash = initializeUnleash({
    url: config.unleashUrl,
    appName: "min-finn-delt-liste",
  });

  const podlet = new Podlet({
    name: "min-finn-delt-liste-podlet",
    version: process.env.VERSION || `${Date.now()}`,
    pathname: "/",
    development: config.development,
    logger,
    fallback: "/fallback",
  });

  const expressPodlet = new ExpressPodlet(podlet, {
    eik: true,
    prometheus,
    port: config.port,
  });

  const eik = new Eik({ development: config.development, base: "/static" });
  await eik.load();

  podlet.css(eik.file("/styles.css"));

  if (config.development) {
    const { app } = expressPodlet;
    app.use("/static", express.static("./dist/"));
  }

  expressPodlet.app.get(
    podlet.content(),
    authenticatePodlet({ logger }),
    (req: Request, res: Response) => {
      const isEnabled = unleash.isEnabled(
        "mfinn.summer.shared-lists",
        getUnleashContext(res, req)
      );
      if (isEnabled) {
        content()(req, res);
      } else {
        res.podiumSend("");
      }
    }
  );

  expressPodlet.app.get(podlet.fallback(), (req: Request, res: Response) =>
    res.podiumSend("")
  );

  return expressPodlet;
}
