import icons from "./generated-icons";

export type MenuItem = {
  title: string;
  text: string;
  href: string;
  icon: string;
  controller?: string;
  external?: boolean;
};

export default function menuItem(item: MenuItem): string {
  return `
    <div id="delte-lister" class="grid__unit">
      <a class="link link--dark panel panel--bright" 
         href="${item.href}" 
         ${item.controller ? `data-controller="${item.controller}"` : ""}
         ${item.external ? 'target="_blank"' : ""}>
         <div class="flex-align u-pa8">
         <div style="width: 100%">
         <div class="flex-align">
            <span class="menu-item-icon u-mr16">${item.icon}</span>
            <div class="summer-tooltip-wrapper">
              <h3>${item.title}</h3>
              <div class="summer-tooltip mb-16">
                  <p class="summer-tooltip-text">Nyhet!</p>
              </div>
            </div>
            </div>
            <div class="menu-item-text u-pt8">${item.text}</div>
              </div>
              <div>${icons.chevronRight}</div>
          </div>
      </a>
    </div>
  `;
}
