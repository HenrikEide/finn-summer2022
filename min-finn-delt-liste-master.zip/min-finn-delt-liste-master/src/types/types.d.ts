declare module "@finn-no/express-unleash-middleware";
declare module "@eik/node-client";
