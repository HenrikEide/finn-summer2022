import { NextFunction, Request, Response } from 'express';
import { IdentityUtilProps } from '@finn-no/login-middleware/lib/identity-util';

declare module '@finn-no/login-middleware' {
    type MiddlewarePromise = (
        req: Request,
        res: Response,
        next: NextFunction,
    ) => Promise<void>;
    function authenticatePodlet(config: IdentityUtilProps): MiddlewarePromise;
}
