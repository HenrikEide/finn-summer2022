type ContentPromise = (
    req: PodiumRequest,
    res: PodiumResponse,
) => Promise<Express.Response>;
