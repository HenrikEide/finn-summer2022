import { Request, Response } from "express";
import icons from "./generated-icons";
import menuItem from "./menuItem";

export default function content(): ContentPromise {
  return (async (req: Request, res: Response) => {
    const displayMode = req.query.displayMode;
    if (displayMode === "button") {
      return res.podiumSend(
        button({
          text: "Delte lister",
          href: "/delte-lister",
        })
      );
    } else {
      return res.podiumSend(
        menuItem({
          title: "Delte lister",
          text: "Del dine lister og samarbeid med andre",
          href: `/delte-lister`,
          icon: icons.sharedList,
        })
      );
    }
  }) as ContentPromise;
}

function button(config: { text: string; href: string }): string {
  return `<a href="${config.href}" class="button button--has-icon">
        ${icons.externalLink}&nbsp;${config.text}
    </a>`;
}
