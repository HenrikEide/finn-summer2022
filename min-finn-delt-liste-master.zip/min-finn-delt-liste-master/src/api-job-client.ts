import fetch, { Response } from 'node-fetch';
import Agent from 'agentkeepalive';
import logger from '@finn-no/fiaas-logger';

export type HasHiredAd = {
    hasHiredAd: boolean;
};

export default class ApiJobClient {
    private readonly baseUrl: string;
    private readonly timeout: number;
    private readonly agent: Agent;

    constructor(baseUrl: string, timeout: number) {
        this.baseUrl = baseUrl;
        this.timeout = timeout;
        this.agent = new Agent({ keepAlive: true });
    }

    handleError(response: Response) {
        return response
            .json()
            .then((json) => {
                throw new Error(
                    `Response status:  ${
                        response.status
                    } Response body: ${JSON.stringify(json)}`,
                );
            })
            .catch(() => {
                throw new Error('Response status: ' + response.status);
            });
    }

    hasHiredAccessControlAd(loginId: number): Promise<boolean> {
        return fetch(`${this.baseUrl}/access/list-ads?loginId=${loginId}`, {
            timeout: this.timeout,
            agent: this.agent,
        })
            .then((response) => {
                if (response.ok) {
                    return response;
                } else {
                    return this.handleError(response);
                }
            })
            .then((response) => response.json())
            .then((json) => {
                return Boolean(json.length);
            })
            .catch((err) => {
                logger.error(
                    `Error encountered while checking if user ${loginId} has access to any ads in hired.`,
                    err,
                );
                return false;
            });
    }

    hasHiredAd(loginId: number): Promise<boolean> {
        return fetch(`${this.baseUrl}/products/hired/hasHiredAd/${loginId}`, {
            timeout: this.timeout,
            agent: this.agent,
        })
            .then((response) => {
                if (response.ok) {
                    return response;
                } else {
                    return this.handleError(response);
                }
            })
            .then((response) => response.json())
            .then((json) => {
                return !!json.hasHiredAd;
            })
            .catch((err) => {
                logger.error(
                    `Error encountered while checking if user ${loginId} has any hired ads.`,
                    err,
                );
                return false;
            });
    }
}
