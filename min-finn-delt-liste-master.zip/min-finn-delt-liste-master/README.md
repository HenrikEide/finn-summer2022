# min-finn-delt-liste-podlet

Podlet that displays a "Delte lister".
