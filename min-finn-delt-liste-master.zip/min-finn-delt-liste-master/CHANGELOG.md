(2022-7-5) Version [1.0.2](https://assets.finn.no/pkg/min-finn-delt-liste/1.0.2) of Eik package [min-finn-delt-liste](https://assets.finn.no/pkg/min-finn-delt-liste) published to [https://assets.finn.no](https://assets.finn.no)

(2022-7-5) Version [1.0.1](https://assets.finn.no/pkg/min-finn-delt-liste/1.0.1) of Eik package [min-finn-delt-liste](https://assets.finn.no/pkg/min-finn-delt-liste) published to [https://assets.finn.no](https://assets.finn.no)

(2022-7-5) Version [1.0.0](https://assets.finn.no/pkg/min-finn-delt-liste/1.0.0) of Eik package [min-finn-delt-liste](https://assets.finn.no/pkg/min-finn-delt-liste) published to [https://assets.finn.no](https://assets.finn.no)
