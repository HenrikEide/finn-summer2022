#!/bin/sh

export TRAVIS_DOCKER_CONTEXT_DIR=""
export FIAAS_DEPLOY_YML_FILENAME="fiaas.yml"

fiaas_deploy min-finn-delt-liste-podlet || exit 3
