module.exports = {
  plugins: [
    "@eik/semantic-release",
    "@semantic-release/changelog",
    ["@semantic-release/git", { assets: ["eik.json", "CHANGELOG.md"] }],
  ],
  branches: ["master"],
};
